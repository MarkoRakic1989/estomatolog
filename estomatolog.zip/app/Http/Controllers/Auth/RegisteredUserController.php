<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\Salon;
use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;
use Inertia\Response;

class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     */
    public function create(): Response
    {
        return Inertia::render('Auth/Register');
    }

    /**
     * Handle an incoming registration request.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        $host = $request->getHost();
        $salonSlug = explode('.', $host)[0];
        $salon = Salon::where('slug', $salonSlug)->firstOrFail();
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255',
            'password' => 'required|string|confirmed|min:8',
        ]);

        // 1) Pokušaj učitati postojećeg korisnika
        $user = User::where('email', $request->email)->first();

        if ($user) {
            // 2) Ako postoji, provjeri lozinku
            if (! Hash::check($request->password, $user->password)) {
                throw ValidationException::withMessages([
                    'email' => ['E-mail je već registrovan, ali lozinka se ne poklapa. Ako si zaboravio/la lozinku, koristi reset.'],
                ]);
            }
        } else {
            // 3) Nije postojao → kreiraj novi
            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'password' => Hash::make($request->password),
            ]);
            event(new Registered($user));
        }

        // 4) Veži korisnika za salon (pivot salon_user)
        $user->salons()->syncWithoutDetaching([$salon->id]);

        Auth::login($user);

        return redirect()->intended(route('booking.step1', ['salonSlug' => $salonSlug]));
    }
}
