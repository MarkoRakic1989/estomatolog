<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\Service;
use App\Models\WorkTime;
use App\Models\Appointment;
use Carbon\Carbon;
use Illuminate\Http\Request;

class CalendarController extends Controller
{
    /**
     * Vraća JSON niz dostupnih datuma za odabranog zaposlenika,
     * tako da se unutar tih dana može ugurati ukupno trajanje usluga.
     */
    public function getAvailableDates(Request $request, $salonSlug)
    {
        $employeeId  = $request->query('employee_id');
        $serviceIds  = $request->query('service_ids', []);

        // Validirajte i dohvatite Employee i ukupno trajanje usluga
        $employee = Employee::findOrFail($employeeId);
        $services = Service::whereIn('id', $serviceIds)->get();
        $totalDuration = $services->sum('duration');

        // Logika za dohvat dostupnih datuma (isto kao computeAvailableDates...)
        $today       = Carbon::today();
        $daysToCheck = 30;
        $availableDates = [];

        for ($i = 0; $i < $daysToCheck; $i++) {
            $date = $today->copy()->addDays($i)->toDateString();

            // Dohvati radno vrijeme za taj dan
            $workTime = WorkTime::where('employee_id', $employee->id)
                                ->where('date', $date)
                                ->first();
            if (! $workTime) {
                continue;
            }

            // Izračunaj slobodne slotove unutar tog dana
            $slots = $this->computeAvailableSlots($employee, $totalDuration, $date);
            if (count($slots) > 0) {
                $availableDates[] = $date;
            }
        }

        return response()->json(['dates' => $availableDates]);
    }

    /**
     * Vraća JSON niz slobodnih vremena (slotova) za zadani datum,
     * ovisno o radnom vremenu i već postojećim terminima.
     */
    public function getAvailableSlots(Request $request, $salonSlug)
    {
        $employeeId   = $request->query('employee_id');
        $serviceIds   = $request->query('service_ids', []);
        $date         = $request->query('date');

        $employee = Employee::findOrFail($employeeId);
        $services = Service::whereIn('id', $serviceIds)->get();
        $totalDuration = $services->sum('duration');

        $slots = $this->computeAvailableSlots($employee, $totalDuration, $date);

        return response()->json(['slots' => $slots]);
    }

    /**
     * Pomoćna metoda: izračunava popis svih početnih termina (u koracima od 30 minuta)
     * u kojima stane cjelokupan interval $totalDuration unutar radnog vremena.
     */
    protected function computeAvailableSlots(Employee $employee, int $totalDuration, string $date): array
    {
        $workTime = WorkTime::where('employee_id', $employee->id)
                            ->where('date', $date)
                            ->first();
        if (! $workTime) {
            return [];
        }

        $workStart = Carbon::parse("{$date} {$workTime->start_time}");
        $workEnd   = Carbon::parse("{$date} {$workTime->end_time}");

        // Ne može se ugraditi ako radno vrijeme kraće od ukupnog trajanja
        if ($workStart->diffInMinutes($workEnd) < $totalDuration) {
            return [];
        }

        $appointments = Appointment::where('employee_id', $employee->id)
                                   ->where('date', $date)
                                   ->get()
                                   ->map(fn($a) => [
                                      'start' => Carbon::parse("{$date} {$a->start_time}"),
                                      'end'   => Carbon::parse("{$date} {$a->end_time}"),
                                   ])
                                   ->sortBy('start')
                                   ->values();

        // Sastavi busyIntervals
        $busyIntervals = [];
        foreach ($appointments as $appt) {
            $busyIntervals[] = [$appt['start'], $appt['end']];
        }

        // Sastavi freeIntervals na temelju radnog vremena i busyIntervals
        $freeIntervals = [];
        if (count($busyIntervals) === 0) {
            $freeIntervals[] = [$workStart, $workEnd];
        } else {
            if ($busyIntervals[0][0]->gt($workStart)) {
                $freeIntervals[] = [$workStart, $busyIntervals[0][0]];
            }
            for ($i = 0; $i < count($busyIntervals) - 1; $i++) {
                $endCurrent = $busyIntervals[$i][1];
                $startNext  = $busyIntervals[$i + 1][0];
                if ($startNext->gt($endCurrent)) {
                    $freeIntervals[] = [$endCurrent, $startNext];
                }
            }
            $lastEnd = $busyIntervals[count($busyIntervals) - 1][1];
            if ($workEnd->gt($lastEnd)) {
                $freeIntervals[] = [$lastEnd, $workEnd];
            }
        }

        // Iz svakog free intervala izvući sve početne termine u koracima od 30 minuta
        $slotStep = 30; // minuta
        $availableSlots = [];
        foreach ($freeIntervals as [$freeStart, $freeEnd]) {
            $slotStart = $freeStart->copy();
            $slotLastPossible = $freeEnd->copy()->subMinutes($totalDuration);

            while ($slotStart->lte($slotLastPossible)) {
                $slotEnd = $slotStart->copy()->addMinutes($totalDuration);
                if ($slotEnd->lte($freeEnd)) {
                    $availableSlots[] = $slotStart->format('H:i');
                }
                $slotStart->addMinutes($slotStep);
            }
        }

        return $availableSlots;
    }
}
