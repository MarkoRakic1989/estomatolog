<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;
use Illuminate\Support\Facades\Mail;
class AppointmentController extends Controller
{
    /**
     * Prikaz svih rezervacija za prijavljenog klijenta.
     */
    public function index($salonSlug)
    {
        $paginated = Appointment::with(['salon', 'employee', 'services'])
            ->where('user_id', Auth::id())
            ->orderBy('date', 'desc')
            ->orderBy('start_time', 'desc')
            ->paginate(10);

        // Mapiramo svaku instancu u objekt koji Vue želi:
        $appointments = $paginated->through(function($a) {
            return [
                'id'           => $a->id,
                // salonName dolazi iz relacije 'salon'
                'salonName'    => $a->salon->name,
                'salonSlug'    => $a->salon->slug,
                // employeeName dolazi iz relacije 'employee'
                'employeeName' => $a->employee->name,
                'date'         => $a->date,
                'start_time'   => $a->start_time,
                'end_time'     => $a->end_time,
                'status'       => $a->status,
                // services je niz objekata { id, name, price, duration, description }
                'services'     => $a->services->map(fn($s) => [
                    'id'          => $s->id,
                    'name'        => $s->name,
                    'price'       => $s->price,
                    'duration'    => $s->duration,
                    'description' => $s->description,
                ])->all(),
            ];
        });

        return Inertia::render('Client/Appointments/Index', [
            'salon'        => [
                // Po potrebi, uzmi boje iz Auth::user()->salon
                'primary_color'   => '#000000',
                'secondary_color' => '#FF0000',
            ],
            // Slanje paginacije
            'appointments' => $appointments,
            'salonSlug' => $salonSlug,
        ]);
    }

    /**
     * Prikaz detalja jednog termina (mogućnost otkazivanja).
     */
    public function show(Appointment $appointment)
    {
        if ($appointment->user_id !== Auth::id()) {
            abort(403);
        }

        return Inertia::render('Client/Appointments/Show', [
            'appointment' => $appointment->load('salon','employee','services'),
        ]);
    }

    /**
     * Otkaži termin (ako je pravilo dozvoljeno – npr. 24h prije).
     */
    public function cancel($salonSlug,Appointment $appointmentId)
    {
        if ($appointmentId->user_id !== Auth::id()) {
            abort(403);
        }

        // Provjera može li se otkazati (npr. 24h prije)
        if (\Carbon\Carbon::parse($appointmentId->date . ' ' . $appointmentId->start_time)
            ->subHours(24)
            ->isPast()) {
            return back()->with('error', 'Termin se ne može otkazati manje od 24 sata prije.');
        }
        $appointmentId->status = 'cancelled';
        $appointmentId->save();
        // Pošalji notifikaciju radniku i vlasniku
        // Mail::to($appointmentId->employee->email)->send(new \App\Mail\appointmentCancelledMail($appointmentId));
        // Mail::to($appointmentId->salon->email)->send(new \App\Mail\appointmentCancelledMail($appointmentId));

        return redirect()->route('client.appointment.index',$salonSlug)
                         ->with('success', 'Termin je otkazan.');
    }
}
