<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Salon;
use App\Models\Service;
use App\Models\Employee;
use App\Models\WorkTime;
use App\Models\Appointment;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class BookingController extends Controller
{
    /**
     * Korak 1: Prikaz liste usluga za salon (idemo preko subdomena ili parametra {salonSlug}).
     */
    public function step1(Request $request,$salonSlug)
    {
        $salon = Salon::where('slug', $salonSlug)->firstOrFail();
        $services = $salon->services()->orderBy('name')->get();
        $selectedServices = $request->session()->get('booking.service_ids', []);
        return Inertia::render('Client/Booking/Step1', [
            'salon' => $salon,
            'services' => $services,
            'salonSlug' => $salonSlug,
            'selectedServices' => $selectedServices,
        ]);
    }
    public function showStep2(Request $request, $salonSlug)
    {
        // 1) Dohvati salon (isto kao u post-metodi)
        $salon = Salon::where('slug', $salonSlug)->firstOrFail();

        // 2) Moramo dohvatiti ‘service_ids’ iz query-stringa ili iz sessiona.
        //    Preporučeno: pohranjivati service_ids u session prilikom POST-a,
        //    pa ovdje samo čitati:
        $serviceIds = $request->session()->get('booking.service_ids', []);
        // Ako nema service_ids (korisnik je možda direktno otišao na /booking/step2 bez izborne usluge),
        // redirektiraj na korak 1.
        if (! is_array($serviceIds) || count($serviceIds) < 1) {
            return redirect()->route('booking.step1', ['salonSlug' => $salonSlug]);
        }

        // 3) Dohvati relevantne podatke (npr. Employee filtrirani prema uslugama)
        $employeesQuery = Employee::where('salon_id', $salon->id)
            ->whereHas('services', function ($q) use ($serviceIds) {
                $q->whereIn('services.id', $serviceIds);
            }, '=', count($serviceIds));

        $employees = $employeesQuery->get()->map(function ($emp) use ($serviceIds) {
            $names = $emp->services()
                ->whereIn('services.id', $serviceIds)
                ->pluck('name')
                ->toArray();

            return [
                'id'            => $emp->id,
                'name'          => $emp->name,
                'service_names' => $names,
            ];
        })->values();

        // 4) Proslijedi Inertia::render('Client/Booking/Step2', …) sa istim propsima
        return Inertia::render('Client/Booking/Step2', [
            'salonSlug'        => $salonSlug,
            'salon'            => [
                'id'              => $salon->id,
                'name'            => $salon->name,
                'primary_color'   => $salon->primary_color,
                'secondary_color' => $salon->secondary_color,
            ],
            'employees'        => $employees->all(),
            'selectedServices' => $serviceIds,
            'currentRoute'     => 'booking.step2.show',
        ]);
    }
    /**
     * Korak 2: Dohvati zaposlenike koji nude sve odabrane usluge.
     * Ulazni parametri: salonSlug, niz service_ids (iz step1 forme).
     */
    public function step2(Request $request, $salonSlug)
    {
        // 1) dohvatite salon
        $salon = Salon::where('slug', $salonSlug)->firstOrFail();

        // 2) dohvatite service_ids kao niz, s fallbackom na prazan niz
        $serviceIds = $request->input('service_ids', []);

        // 3) validirajte da je service_ids niz i da sadrži barem jedan ID
        $validator = Validator::make(
            ['service_ids' => $serviceIds],
            ['service_ids' => 'required|array|min:1']
        );

        if ($validator->fails()) {
            // Ako validacija ne prođe, vraćamo nazad na step1 s porukama o greškama
            return back()
                ->withErrors($validator)
                ->withInput();
        }

        // 4) Filtrirajte zaposlenike koji pružaju sve usluge iz serviceIds
        //    Ovdje korištenjem whereHas i count(array)
        $employeesQuery = Employee::where('salon_id', $salon->id)
            ->whereHas('services', function ($q) use ($serviceIds) {
                // Prefiksirajte 'services.id' da ne bude ambiguous
                $q->whereIn('services.id', $serviceIds);
            }, '=', count($serviceIds));

        $employees = $employeesQuery->get()->map(function ($emp) use ($serviceIds) {
            // Za svakog zaposlenika dohvatimo imena usluga koje je odabrao klijent
            $names = $emp->services()
                ->whereIn('services.id', $serviceIds)
                ->pluck('name')
                ->toArray();

            return [
                'id'            => $emp->id,
                'name'          => $emp->name,
                'service_names' => $names,
            ];
        })->values();

        // 5) Pohranite odabrane usluge u session (ako kasnije trebate)
        session(['booking.service_ids' => $serviceIds]);

        // 6) Pripremite selectedServices (samo ID-eve ili s više detalja)
        //    Ako u Step2.vue koristite samo ID-eve, možete poslati $serviceIds.
        //    Ako želite poslati ime, cijenu, trajanje—mapirajte ih.
        $selectedServices = Service::whereIn('id', $serviceIds)
            ->get()
            ->map(fn($s) => [
                'id'       => $s->id,
                'name'     => $s->name,
                'price'    => $s->price,
                'duration' => $s->duration,
            ])
            ->values();

        // 7) Vratite Inertia render za Step2.vue, uključujući currentRoute
        return Inertia::render('Client/Booking/Step2', [
            'salonSlug'        => $salonSlug,
            'salon'            => [
                'id'              => $salon->id,
                'name'            => $salon->name,
                'primary_color'   => $salon->primary_color,
                'secondary_color' => $salon->secondary_color,
            ],
            'employees'        => $employees->all(),
            'selectedServices' => $selectedServices,
            'currentRoute'     => 'booking.step2',
        ]);
    }

    /**
     * Korak 3 (GET): prikaz forme za odabir datuma (kalendar) i vremena
     */
    /**
     * Korak 3: Prikaži dostupne datume i termine za odabranog zaposlenika i usluge.
     */public function step3Form(Request $request, string $salonSlug)
{
    // 1) Dohvati salon ili 404
    $salon = Salon::where('slug', $salonSlug)->firstOrFail();

    // 2) Raw service_ids iz query-ja, uvek array
        $serviceIds = $request->session()->get('booking.service_ids', []);
    // 4) employee_id iz query-ja
    $employeeId = (int) $request->query('employee_id', 0);

    // 5) Osnovna validacija
    if (count($serviceIds) < 1 || $employeeId < 1) {
        return redirect()->route('booking.step1', ['salonSlug' => $salonSlug]);
    }

    // 6) Dohvati i potvrdni Employee
    $employee = Employee::where('id', $employeeId)
        ->where('salon_id', $salon->id)
        ->firstOrFail();

    // 7) Dohvati odabrane usluge i ukupno trajanje
    $services = Service::whereIn('id', $serviceIds)->get();
    $totalDuration = $services->sum('duration');

    // 8) Izračunaj dostupne datume i termine
    $availableDates = $this->computeAvailableDates($employee, $totalDuration);
    $firstDate      = $availableDates[0] ?? null;
    $availableSlots = $firstDate
        ? $this->computeAvailableSlots($employee, $totalDuration, $firstDate)
        : [];

    // 9) Pripremi detalje za front
    $servicesAll = $services
        ->map(fn($s) => [
            'id'       => $s->id,
            'name'     => $s->name,
            'price'    => $s->price,
            'duration' => $s->duration,
        ])
        ->values()
        ->all();

    // 10) Renderuj Inertia
    return Inertia::render('Client/Booking/Step3', [
        'salonSlug'        => $salonSlug,
        'salon'            => [
            'id'              => $salon->id,
            'name'            => $salon->name,
            'primary_color'   => $salon->primary_color,
            'secondary_color' => $salon->secondary_color,
        ],
        'selectedServices' => $serviceIds,
        'servicesAll'      => $servicesAll,
        'selectedEmployee' => [
            'id'   => $employee->id,
            'name' => $employee->name,
        ],
        'totalDuration'    => $totalDuration,
        'availableDates'   => $availableDates,
        'availableSlots'   => $availableSlots,
        'currentRoute'     => 'booking.step3',
    ]);
}

    /**
     * Računa sve datume unutar idućih 30 dana (uključujući danas) u kojima
     * zaposlenik ima definiran radni raspored i u kojima ima barem jedan
     * slobodan interval dovoljan za $totalDuration (u minutama).
     *
     * @param  Employee  $employee
     * @param  int       $totalDuration  Ukupno trajanje u minutama
     * @return array     Array stringova formata ['2025-06-05', '2025-06-06', ...]
     */
    protected function computeAvailableDates(Employee $employee, int $totalDuration): array
    {
        $availableDates = [];
        $today = Carbon::today();
        $daysToCheck = 30; // provjeri 30 dana unaprijed

        for ($i = 0; $i < $daysToCheck; $i++) {
            $date = $today->copy()->addDays($i)->toDateString();

            // 1) Dohvati WorkTime za taj datum i zaposlenika
            $workTime = WorkTime::where('employee_id', $employee->id)
                ->where('date', $date)
                ->first();

            if (! $workTime) {
                // zaposlenik ne radi taj dan
                continue;
            }

            // 2) Izračunaj sve slobodne termine za taj datum
            $slots = $this->computeAvailableSlots($employee, $totalDuration, $date);

            // 3) Ako ima bar jedan slot, taj datum je 'dostupan'
            if (count($slots) > 0) {
                $availableDates[] = $date;
            }
        }

        return $availableDates;
    }

    /**
     * Računa sve slobodne početne termine (npr. u koracima od 30 minuta)
     * za odabranog zaposlenika i datum, tako da se može uklopiti $totalDuration (u minutama).
     *
     * @param  Employee  $employee
     * @param  int       $totalDuration  Ukupno trajanje u minutama
     * @param  string    $date           Datum formata 'YYYY-MM-DD'
     * @return array     Array stringova formata ['09:00', '09:30', ...]
     */
    protected function computeAvailableSlots(Employee $employee, int $totalDuration, string $date): array
    {
        // 1) Dohvati radno vreme zaposlenika
        $workTime = WorkTime::where('employee_id', $employee->id)
            ->where('date', $date)
            ->first();

        if (! $workTime) {
            return [];
        }

        // Pretvorimo start_time i end_time u Carbon objekte
        $workStart = Carbon::parse("{$date} {$workTime->start_time}");
        $workEnd   = Carbon::parse("{$date} {$workTime->end_time}");

        // Ako je radno vreme kraće od totalDuration, nema slobodnih termina
        if ($workStart->diffInMinutes($workEnd) < $totalDuration) {
            return [];
        }

        // 2) Dohvati postojeće termine za taj datum
        $appointments = Appointment::where('employee_id', $employee->id)
            ->where('date', $date)
            ->get()
            ->map(fn($a) => [
                'start' => Carbon::parse("{$date} {$a->start_time}"),
                'end'   => Carbon::parse("{$date} {$a->end_time}"),
            ])->sortBy('start')
            ->values();

        // 3) Složimo "zauzete" intervale
        $busyIntervals = [];
        foreach ($appointments as $appt) {
            $busyIntervals[] = [$appt['start'], $appt['end']];
        }

        // 4) Izračunamo slobodne intervale između radnog vremena i svih zakazanih termina
        $freeIntervals = [];

        if (empty($busyIntervals)) {
            $freeIntervals[] = [$workStart, $workEnd];
        } else {
            // pre prvog termina
            if ($busyIntervals[0][0]->gt($workStart)) {
                $freeIntervals[] = [$workStart, $busyIntervals[0][0]];
            }
            // između termina
            for ($i = 0; $i < count($busyIntervals) - 1; $i++) {
                $endCurrent = $busyIntervals[$i][1];
                $startNext  = $busyIntervals[$i + 1][0];
                if ($startNext->gt($endCurrent)) {
                    $freeIntervals[] = [$endCurrent, $startNext];
                }
            }
            // posle poslednjeg termina
            $lastEnd = end($busyIntervals)[1];
            if ($workEnd->gt($lastEnd)) {
                $freeIntervals[] = [$lastEnd, $workEnd];
            }
        }

        // 5) Unutar svakog slobodnog intervala, generišemo slotove u koracima od 30 minuta
        $slotStep = 30; // minuta
        $availableSlots = [];

        foreach ($freeIntervals as [$freeStart, $freeEnd]) {
            $slotStart = $freeStart->copy();
            $slotLastPossible = $freeEnd->copy()->subMinutes($totalDuration);

            while ($slotStart->lte($slotLastPossible)) {
                $slotEnd = $slotStart->copy()->addMinutes($totalDuration);

                if ($slotEnd->lte($freeEnd)) {
                    $availableSlots[] = $slotStart->format('H:i');
                }

                $slotStart->addMinutes($slotStep);
            }
        }

        // 6) Ako je danasnji datum, ukloni sve termine pre (sada + 2 sata)
        if ($date === Carbon::today()->toDateString()) {
            $threshold = Carbon::now()->addHours(2);
            $availableSlots = array_filter($availableSlots, function($time) use ($date, $threshold) {
                return Carbon::parse("{$date} {$time}")->gte($threshold);
            });
            // reset indeksa
            $availableSlots = array_values($availableSlots);
        }

        return $availableSlots;
    }

    /**
     * Endpoint (API) za dohvat slobodnih termina – stavlja se u CalendarController,
     * ali možeš ostaviti i ovdje kao metoda koja vraća JSON.
     * Primjer: GET /api/calendar/{salon}/{employeeIds}?date=2025-06-10&duration=90
     */
    public function getAvailableSlots(Request $request, $salonSlug)
    {
        // Validacija
        $request->validate([
            'date' => 'required|date',
            'employee_ids' => 'required|array|min:1',
            'employee_ids.*' => 'exists:employees,id',
            'duration' => 'required|integer|min:1',
        ]);

        $date = $request->date;
        $employeeIds = $request->employee_ids;
        $duration = $request->duration; // u minutama
        $slots = [];

        foreach ($employeeIds as $empId) {
            // Dohvati radno vrijeme za tog zaposlenika na taj datum
            $workTime = WorkTime::where('employee_id', $empId)
                ->where('date', $date)
                ->first();

            if (! $workTime) {
                // zaposlenik ne radi taj dan
                continue;
            }

            $start = Carbon::parse($workTime->start_time);
            $end = Carbon::parse($workTime->end_time);

            // Dohvati već zakazane termine tog zaposlenika na taj datum
            $existingAppointments = Appointment::where('employee_id', $empId)
                ->where('date', $date)
                ->get(['start_time', 'end_time']);

            // Generiraj sve moguće slotove (npr. svaka 15 minuta)
            $pointer = $start->copy();
            while ($pointer->addMinutes(0) < $end) {
                $potentialStart = $pointer->copy();
                $potentialEnd = $pointer->copy()->addMinutes($duration);

                if ($potentialEnd > $end) break;

                // Provjera konflikta s postojećim
                $conflict = $existingAppointments->first(function ($appt) use ($potentialStart, $potentialEnd) {
                    $apptStart = Carbon::parse($appt->start_time);
                    $apptEnd = Carbon::parse($appt->end_time);
                    return $potentialStart->lt($apptEnd) && $potentialEnd->gt($apptStart);
                });

                if (! $conflict) {
                    $slots[] = [
                        'employee_id' => $empId,
                        'start' => $potentialStart->format('H:i'),
                        'end' => $potentialEnd->format('H:i'),
                    ];
                }
                // Povećaj pointer za 15 minuta (ili po tvom željenom intervalu)
                $pointer->addMinutes(15);
            }
        }

        // Vraćamo JSON: lista slobodnih slotova po zaposleniku
        return response()->json(['slots' => $slots]);
    }

    /**
     * Korak 4: potvrda i spremanje rezervacije (POST).
     */
    public function confirm(Request $request, $salonSlug)
    {
        $salon = Salon::where('slug', $salonSlug)->firstOrFail();
        $request->validate([
            'employee_id' => 'required|exists:employees,id',
            'service_ids' => 'required|array',
            'service_ids.*' => 'exists:services,id',
            'date' => 'required|date',
            'start_time' => 'required|date_format:H:i',
        ]);

        // Provjera da su usluge i zaposlenik u istom salonu
        $employee = Employee::where('id', $request->employee_id)
            ->where('salon_id', $salon->id)
            ->firstOrFail();

        $services = Service::whereIn('id', $request->service_ids)
            ->where('salon_id', $salon->id)
            ->get();
        $totalDuration = $services->sum('duration');

        $start = Carbon::parse("{$request->date} {$request->start_time}");
        $end = $start->copy()->addMinutes($totalDuration);

        $newStart = $start->format('H:i');
        $newEnd   = $end->format('H:i');

        $conflict = Appointment::where('employee_id', $employee->id)
            ->where('date', $request->date)
            // konflikt ako novi početak < postojeći kraj
            ->where('start_time', '<', $newEnd)
            // i novi kraj > postojeći početak
            ->where('end_time', '>', $newStart)
            ->exists();

        if ($conflict) {
            return back()->with('error', 'Željeni termin više nije dostupan. Molimo odaberite drugi.');
        }

        // Kreiranje rezervacije
        $appointment = Appointment::create([
            'salon_id' => $salon->id,
            'employee_id' => $employee->id,
            'user_id' => Auth::user()->id,
            'date' => $request->date,
            'start_time' => $request->start_time,
            'end_time' => $end->format('H:i'),
            'status' => 'pending',
        ]);

        // Pivot zapis za usluge
        $appointment->services()->attach($request->service_ids);

        // // Slanje maila zaposleniku i vlasniku (opa, notifikacija)
        // Mail::to($employee->email)->send(new \App\Mail\NewAppointmentMail($appointment));
        // Mail::to($salon->email)->send(new \App\Mail\NewAppointmentMail($appointment));
        // Logiranje mailova – listener će to zabilježiti u email_logs
        return redirect()->route('booking.confirmation', [
            'id'            => $appointment->id,   // ili 'appointmentId' ako ste tako definirali
            'salonSlug'     => $salon->slug,       // za domeni
        ]);
    }

    /**
     * Stranica potvrde – prikaz detalja uspješne rezervacije.
     */
    public function confirmation(Request $request,string $salonSlug, int $id)
    {
    $request->session()->forget('booking.service_ids');
        // 1) Dohvati salon na temelju sluga iz subdomene
        $salon = Salon::where('slug', $salonSlug)->firstOrFail();

        // 2) Dohvati appointment, zajedno s employee i services relacijama
        $appointment = Appointment::with(['employee', 'services'])
            ->where('id', $id)
            ->where('user_id', Auth::id())
            ->firstOrFail();

        // 3) Pripremi prop 'selectedServices' – samo ID-jevi usluga
        $selectedServices = $appointment->services
            ->pluck('id')
            ->all(); // npr. [2, 3, 5]

        // 4) Pripremi prop 'servicesAll' – detalji svake usluge (id, name, price, duration)
        $servicesAll = $appointment->services->map(fn($s) => [
            'id'       => $s->id,
            'name'     => $s->name,
            'price'    => $s->price,
            'duration' => $s->duration,
        ])->values()->all();

        // 5) Pripremi prop 'selectedEmployee' – objekt s id i imenom
        $selectedEmployee = [
            'id'   => $appointment->employee->id,
            'name' => $appointment->employee->name,
        ];

        // 6) Pripremi prop 'selectedDate' i 'selectedSlot'
        $selectedDate = $appointment->date;            // npr. "2025-06-06"
        $selectedSlot = $appointment->start_time;      // npr. "14:00"

        // 7) Renderiraj Inertia confirmation komponentu i pošalji sve props
        return Inertia::render('Client/Booking/Confirmation', [
            'salonSlug'         => $salonSlug,
            'appointmentId' => $appointment->id,
            'salon'             => [
                'id'              => $salon->id,
                'name'            => $salon->name,
                'primary_color'   => $salon->primary_color,
                'secondary_color' => $salon->secondary_color,
            ],
            'selectedServices'  => $selectedServices,
            'servicesAll'       => $servicesAll,
            'selectedEmployee'  => $selectedEmployee,
            'selectedDate'      => $selectedDate,
            'selectedSlot'      => $selectedSlot,
            'currentRoute'      => 'booking.confirmation',
        ]);
    }
    public function confirmStatus(string $salonSlug, int $appointmentId)
    {
        // 1) Dohvati salon (provjera da slug postoji)
        $salon = Salon::where('slug', $salonSlug)->firstOrFail();

        // 2) Dohvati termin pripadajućeg korisnika i u stanju "pending"
        $appointment = Appointment::where('id', $appointmentId)
            ->where('user_id', Auth::id())
            ->where('status', 'pending')
            ->firstOrFail();

        // 3) Ažuriraj status u "confirmed"
        $appointment->status = 'confirmed';
        $appointment->save();

        // 4) Preusmjeri na client panel gdje se vide svi potvrđeni termini
        return redirect()->route('client.appointment.index',[
            'salonSlug'        => $salonSlug,]);
    }
}
