<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Salon;
use Illuminate\Support\Facades\Mail;
use App\Mail\ContactMessageMail;

class ContactController extends Controller
{
    /**
     * Obrada slanja kontakt forme.
     */
    public function send(Request $request, $salonSlug)
    {
        $salon = Salon::where('slug', $salonSlug)
                      ->firstOrFail();

        // Validiraj polja: name, email, message
        $data = $request->validate([
            'name'    => 'required|string|max:255',
            'email'   => 'required|email|max:255',
            'message' => 'required|string|max:2000',
        ]);

        // Pošalji email vlasniku salona
        Mail::to($salon->email)
            ->send(new ContactMessageMail($data, $salon));

        // Vratimo JSON (Inertia će prevesti validaciju/poruku na frontend)
        return response()->json([
            'message' => 'Your message has been sent successfully!'
        ]);
    }
}
