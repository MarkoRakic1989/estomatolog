<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use App\Mail\NewUserOnSalon;
use App\Mail\AttachedToSalon;
use App\Models\User;
use App\Models\Service;
use App\Models\Employee;
use App\Models\WorkTime;
use App\Models\Appointment;
use App\Models\ServiceCategory;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;

class AppointmentController extends Controller
{
    // 1) Lista svih termina
    public function index()
    {
        $salon = Auth::user()->ownedSalon;

        $appointments = Appointment::with(['user:id,name','employee:id,name'])
            ->where('salon_id', $salon->id)
            ->orderBy('date','desc')
            ->orderBy('start_time')
            ->paginate(15);

        return Inertia::render('Owner/Appointments/Index', [
            'appointments' => $appointments,
        ]);
    }
    public function create(Request $request)
    {
        $salon = Auth::user()->ownedSalon;
        $query = $request->query('query', '');

        $suggestions = [];
        if (strlen($query) >= 3) {
            $suggestions = User::whereHas('salons', function($q) use($salon) {
                    $q->where('salon_id', $salon->id);
                })
                ->where(function($q) use($query) {
                    $q->where('email', 'like', "%{$query}%")
                    ->orWhere('phone', 'like', "%{$query}%");
                })
                ->get(['id','name','email','phone'])
                ->values()
                ->all();
        }

        return Inertia::render('Owner/Appointments/Create', [
            'suggestions' => $suggestions,
            'query'       => $query,
        ]);
    }

    // 2b) Obrada pretrage ili kreiranja i povezivanje sa salonom
    public function storeUser(Request $request)
    {
        $salon = Auth::user()->ownedSalon;

        $data = $request->validate([
            'name'  => ['nullable','string','max:255'],
            'email' => ['nullable','email'],
            'phone' => ['nullable','string'],
        ]);

        // pokušaj da nađeš korisnika
        $client = User::where('email',$data['email'])
                      ->orWhere('phone',$data['phone'])
                      ->first();

        // ako ga nema i ima ime, kreiraj novog
        if (! $client && $data['name']) {
            $client = User::create([
                'name'     => $data['name'],
                'email'    => $data['email'],
                'phone'    => $data['phone'],
                'password' => bcrypt(str()->random(10)),
            ]);
            Mail::to($client->email)->send(new NewUserOnSalon($client, $salon));
        }

        // ako postoji, proveri pivot salon_user
        if ($client && ! $client->salons()->where('salon_id',$salon->id)->exists()) {
            $client->salons()->attach($salon->id);
            Mail::to($client->email)->send(new AttachedToSalon($client, $salon));
        }
        session(['owner.appt.user_id' => $client->id]);

        return redirect()->route('owner.appointments.services.index');
    }
   public function selectServices()
    {
        $salon = Auth::user()->ownedSalon;

        // Dovučemo sve roditeljske kategorije sa njihovim potkategorijama i uslugama
        $categories = ServiceCategory::where('salon_id', $salon->id)
            ->with(['services', 'children.services'])
            ->whereNull('parent_id')
            ->orderBy('name')
            ->get();

        // Izračunamo top 5 najčešćih usluga iz pivot tabele appointment_service
        $topIds = DB::table('appointment_service')
            ->join('appointments', 'appointment_service.appointment_id', '=', 'appointments.id')
            ->where('appointments.salon_id', $salon->id)
            ->select('appointment_service.service_id', DB::raw('COUNT(*) as cnt'))
            ->groupBy('appointment_service.service_id')
            ->orderByDesc('cnt')
            ->limit(5)
            ->pluck('service_id')
            ->toArray();

        // Ako nema nijedne stavke, vratimo praznu kolekciju
        if (empty($topIds)) {
            $topServices = collect();
        } else {
            // Ovde NE stavljamo DB::raw() u orderByRaw, već direktan string
            $topServices = Service::whereIn('id', $topIds)
                ->orderByRaw("FIELD(id, " . implode(',', $topIds) . ")")
                ->get(['id', 'name']);
        }

       
        // ево како да узмеш и service_ids за сваког запосленог
        $employees = Employee::where('salon_id', $salon->id)
            ->with('services:id')     // учитај само id-је услуга
            ->orderBy('name')
            ->get()
            ->map(fn($e) => [
                'id'          => $e->id,
                'name'        => $e->name,
                'service_ids' => $e->services->pluck('id')->all(),
            ]);

        return Inertia::render('Owner/Appointments/Services', [
            'categories'  => $categories,
            'topServices' => $topServices,
            'employees'   => $employees,
        ]);
    }
    // 3b) Snimi izbor usluga i zaposlenog
    public function storeServices(Request $request)
    {
        $data = $request->validate([
            'service_ids'   => ['required','array','min:1'],
            'service_ids.*' => ['exists:services,id'],
            'employee_id'   => ['required','exists:employees,id'],
        ]);

        session([
            'owner.appt.service_ids' => $data['service_ids'],
            'owner.appt.employee_id' => $data['employee_id'],
        ]);

        return redirect()->route('owner.appointments.schedule.index');
    }

    // 4a) Prikaz dostupnih termina
    public function selectSchedule()
    {
        $salon = Auth::user()->ownedSalon;
        $employeeId = session('owner.appt.employee_id');
        $serviceIds = session('owner.appt.service_ids');

        // 5) Osnovna validacija
    if (count($serviceIds) < 1 || $employeeId < 1) {
        return redirect()->route('booking.step1', ['salonSlug' => $salon->slug]);
    }

    // 6) Dohvati i potvrdni Employee
    $employee = Employee::where('id', $employeeId)
        ->where('salon_id', $salon->id)
        ->firstOrFail();

    // 7) Dohvati odabrane usluge i ukupno trajanje
    $services = Service::whereIn('id', $serviceIds)->get();
    $totalDuration = $services->sum('duration');

    // 8) Izračunaj dostupne datume i termine
    $availableDates = $this->computeAvailableDates($employee, $totalDuration);
    $firstDate      = $availableDates[0] ?? null;
    $availableSlots = $firstDate
        ? $this->computeAvailableSlots($employee, $totalDuration, $firstDate)
        : [];

    // 9) Pripremi detalje za front
    $servicesAll = $services
        ->map(fn($s) => [
            'id'       => $s->id,
            'name'     => $s->name,
            'price'    => $s->price,
            'duration' => $s->duration,
        ])
        ->values()
        ->all();
        $nearestSlots   = $this->getNearestSlots($employee, $totalDuration);

    // 10) Renderuj Inertia
    return Inertia::render('Owner/Appointments/Schedule', [
        'salonSlug'        => $salon->slug,
        'salon'            => [
            'id'              => $salon->id,
            'slug'              => $salon->slug,
            'name'            => $salon->name,
            'primary_color'   => $salon->primary_color,
            'secondary_color' => $salon->secondary_color,
        ],
        'selectedServices' => $serviceIds,
        'servicesAll'      => $servicesAll,
        'selectedEmployee' => [
            'id'   => $employee->id,
            'name' => $employee->name,
        ],
        'totalDuration'    => $totalDuration,
        'availableDates'   => $availableDates,
        'availableSlots'   => $availableSlots,
        'nearestSlots'   => $nearestSlots,
    ]);
    }

    // 4b) Sacuvaj termin
    public function store(Request $request)
    {
        $data = $request->validate([
            'date'       => ['required','date'],
            'start_time' => ['required','date_format:H:i'],
        ]);

        $salon      = Auth::user()->ownedSalon;
        $userId     = session('owner.appt.user_id');
        $serviceIds = session('owner.appt.service_ids');
        $employeeId = session('owner.appt.employee_id');

        $services = Service::whereIn('id',$serviceIds)->get();
        $duration = $services->sum('duration');
        $start    = Carbon::parse("{$data['date']} {$data['start_time']}");
        $end      = $start->copy()->addMinutes($duration);

        $conflict = Appointment::where('employee_id',$employeeId)
            ->where('date',$data['date'])
            ->where('start_time','<',$end->format('H:i'))
            ->where('end_time','>',$data['start_time'])
            ->exists();

        if ($conflict) {
            return back()->with('error','Termin se preklapa, izaberite drugi.');
        }

        $appt = Appointment::create([
            'salon_id'    => $salon->id,
            'employee_id' => $employeeId,
            'user_id'     => $userId,
            'date'        => $data['date'],
            'start_time'  => $data['start_time'],
            'end_time'    => $end->format('H:i'),
            'status'      => 'pending',
        ]);

        $appt->services()->attach($serviceIds);

        return redirect()->route('owner.appointments.confirmation', $appt->id);
    }

    // 5) Potvrda
    public function confirmation($id)
    {
        $appt = Appointment::with(['user','employee','services'])
            ->findOrFail($id);

        return Inertia::render('Owner/Appointments/Confirmation', [
            'appointment' => $appt,
        ]);
    }

     /**
     * Računa sve datume unutar idućih 30 dana (uključujući danas) u kojima
     * zaposlenik ima definiran radni raspored i u kojima ima barem jedan
     * slobodan interval dovoljan za $totalDuration (u minutama).
     *
     * @param  Employee  $employee
     * @param  int       $totalDuration  Ukupno trajanje u minutama
     * @return array     Array stringova formata ['2025-06-05', '2025-06-06', ...]
     */
    protected function computeAvailableDates(Employee $employee, int $totalDuration): array
    {
        $availableDates = [];
        $today = Carbon::today();
        $daysToCheck = 30; // provjeri 30 dana unaprijed

        for ($i = 0; $i < $daysToCheck; $i++) {
            $date = $today->copy()->addDays($i)->toDateString();

            // 1) Dohvati WorkTime za taj datum i zaposlenika
            $workTime = WorkTime::where('employee_id', $employee->id)
                ->where('date', $date)
                ->first();

            if (! $workTime) {
                // zaposlenik ne radi taj dan
                continue;
            }

            // 2) Izračunaj sve slobodne termine za taj datum
            $slots = $this->computeAvailableSlots($employee, $totalDuration, $date);

            // 3) Ako ima bar jedan slot, taj datum je 'dostupan'
            if (count($slots) > 0) {
                $availableDates[] = $date;
            }
        }

        return $availableDates;
    }

    /**
     * Računa sve slobodne početne termine (npr. u koracima od 30 minuta)
     * za odabranog zaposlenika i datum, tako da se može uklopiti $totalDuration (u minutama).
     *
     * @param  Employee  $employee
     * @param  int       $totalDuration  Ukupno trajanje u minutama
     * @param  string    $date           Datum formata 'YYYY-MM-DD'
     * @return array     Array stringova formata ['09:00', '09:30', ...]
     */
    protected function computeAvailableSlots(Employee $employee, int $totalDuration, string $date): array
    {
        // 1) Dohvati radno vreme zaposlenika
        $workTime = WorkTime::where('employee_id', $employee->id)
            ->where('date', $date)
            ->first();

        if (! $workTime) {
            return [];
        }

        // Pretvorimo start_time i end_time u Carbon objekte
        $workStart = Carbon::parse("{$date} {$workTime->start_time}");
        $workEnd   = Carbon::parse("{$date} {$workTime->end_time}");

        // Ako je radno vreme kraće od totalDuration, nema slobodnih termina
        if ($workStart->diffInMinutes($workEnd) < $totalDuration) {
            return [];
        }

        // 2) Dohvati postojeće termine za taj datum
        $appointments = Appointment::where('employee_id', $employee->id)
            ->where('date', $date)
            ->get()
            ->map(fn($a) => [
                'start' => Carbon::parse("{$date} {$a->start_time}"),
                'end'   => Carbon::parse("{$date} {$a->end_time}"),
            ])->sortBy('start')
            ->values();

        // 3) Složimo "zauzete" intervale
        $busyIntervals = [];
        foreach ($appointments as $appt) {
            $busyIntervals[] = [$appt['start'], $appt['end']];
        }

        // 4) Izračunamo slobodne intervale između radnog vremena i svih zakazanih termina
        $freeIntervals = [];

        if (empty($busyIntervals)) {
            $freeIntervals[] = [$workStart, $workEnd];
        } else {
            // pre prvog termina
            if ($busyIntervals[0][0]->gt($workStart)) {
                $freeIntervals[] = [$workStart, $busyIntervals[0][0]];
            }
            // između termina
            for ($i = 0; $i < count($busyIntervals) - 1; $i++) {
                $endCurrent = $busyIntervals[$i][1];
                $startNext  = $busyIntervals[$i + 1][0];
                if ($startNext->gt($endCurrent)) {
                    $freeIntervals[] = [$endCurrent, $startNext];
                }
            }
            // posle poslednjeg termina
            $lastEnd = end($busyIntervals)[1];
            if ($workEnd->gt($lastEnd)) {
                $freeIntervals[] = [$lastEnd, $workEnd];
            }
        }

        // 5) Unutar svakog slobodnog intervala, generišemo slotove u koracima od 30 minuta
        $slotStep = 30; // minuta
        $availableSlots = [];

        foreach ($freeIntervals as [$freeStart, $freeEnd]) {
            $slotStart = $freeStart->copy();
            $slotLastPossible = $freeEnd->copy()->subMinutes($totalDuration);

            while ($slotStart->lte($slotLastPossible)) {
                $slotEnd = $slotStart->copy()->addMinutes($totalDuration);

                if ($slotEnd->lte($freeEnd)) {
                    $availableSlots[] = $slotStart->format('H:i');
                }

                $slotStart->addMinutes($slotStep);
            }
        }

        // 6) Ako je danasnji datum, ukloni sve termine pre (sada + 2 sata)
        if ($date === Carbon::today()->toDateString()) {
            $threshold = Carbon::now()->addHours(2);
            $availableSlots = array_filter($availableSlots, function($time) use ($date, $threshold) {
                return Carbon::parse("{$date} {$time}")->gte($threshold);
            });
            // reset indeksa
            $availableSlots = array_values($availableSlots);
        }

        return $availableSlots;
    }

    /**
     * Endpoint (API) za dohvat slobodnih termina – stavlja se u CalendarController,
     * ali možeš ostaviti i ovdje kao metoda koja vraća JSON.
     * Primjer: GET /api/calendar/{salon}/{employeeIds}?date=2025-06-10&duration=90
     */
    public function getAvailableSlots(Request $request, $salonSlug)
    {
        // Validacija
        $request->validate([
            'date' => 'required|date',
            'employee_ids' => 'required|array|min:1',
            'employee_ids.*' => 'exists:employees,id',
            'duration' => 'required|integer|min:1',
        ]);

        $date = $request->date;
        $employeeIds = $request->employee_ids;
        $duration = $request->duration; // u minutama
        $slots = [];

        foreach ($employeeIds as $empId) {
            // Dohvati radno vrijeme za tog zaposlenika na taj datum
            $workTime = WorkTime::where('employee_id', $empId)
                ->where('date', $date)
                ->first();

            if (! $workTime) {
                // zaposlenik ne radi taj dan
                continue;
            }

            $start = Carbon::parse($workTime->start_time);
            $end = Carbon::parse($workTime->end_time);

            // Dohvati već zakazane termine tog zaposlenika na taj datum
            $existingAppointments = Appointment::where('employee_id', $empId)
                ->where('date', $date)
                ->get(['start_time', 'end_time']);

            // Generiraj sve moguće slotove (npr. svaka 15 minuta)
            $pointer = $start->copy();
            while ($pointer->addMinutes(0) < $end) {
                $potentialStart = $pointer->copy();
                $potentialEnd = $pointer->copy()->addMinutes($duration);

                if ($potentialEnd > $end) break;

                // Provjera konflikta s postojećim
                $conflict = $existingAppointments->first(function ($appt) use ($potentialStart, $potentialEnd) {
                    $apptStart = Carbon::parse($appt->start_time);
                    $apptEnd = Carbon::parse($appt->end_time);
                    return $potentialStart->lt($apptEnd) && $potentialEnd->gt($apptStart);
                });

                if (! $conflict) {
                    $slots[] = [
                        'employee_id' => $empId,
                        'start' => $potentialStart->format('H:i'),
                        'end' => $potentialEnd->format('H:i'),
                    ];
                }
                // Povećaj pointer za 15 minuta (ili po tvom željenom intervalu)
                $pointer->addMinutes(15);
            }
        }

        // Vraćamo JSON: lista slobodnih slotova po zaposleniku
        return response()->json(['slots' => $slots]);
    }

    // --- Helper za 3 najbliza termina ---
    protected function getNearestSlots(Employee $emp, int $duration): array
    {
        $slots = [];
        $dates = $this->computeAvailableDates($emp, $duration);

        foreach ($dates as $date) {
            foreach ($this->computeAvailableSlots($emp, $duration, $date) as $time) {
                $slots[] = ['date'=>$date,'time'=>$time];
                if (count($slots) >= 3) {
                    return $slots;
                }
            }
        }

        return $slots;
    }
}
