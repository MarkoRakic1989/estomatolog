<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use App\Models\Service;
use Illuminate\Http\Request;
use PDF;
use Spatie\Permission\Models\Permission; // ako ti treba, inače obriši

class DashboardController extends Controller
{
    public function index()
    {
        $today        = now()->toDateString();
        $countToday   = Appointment::whereDate('date', $today)->count();
        $countWeek    = Appointment::whereBetween('date', [now()->startOfWeek(), now()->endOfWeek()])->count();
        $countMonth   = Appointment::whereMonth('date', now()->month)->count();

        $topServices = Service::withCount('appointments')
            ->orderBy('appointments_count','desc')
            ->limit(5)
            ->get();
        $paginated = Appointment::with(['salon', 'employee', 'services'])
            ->whereDate('date', $today)
            ->orderBy('date', 'desc')
            ->orderBy('start_time', 'desc')
            ->paginate(10);

        // Mapiramo svaku instancu u objekt koji Vue želi:
        $todaysAppointments = $paginated->through(function($a) {
            return [
                'id'           => $a->id,
                // salonName dolazi iz relacije 'salon'
                'salonName'    => $a->salon->name,
                'salonSlug'    => $a->salon->slug,
                // employeeName dolazi iz relacije 'employee'
                'employeeName' => $a->employee->name,
                'date'         => $a->date,
                'start_time'   => $a->start_time,
                'end_time'     => $a->end_time,
                'status'       => $a->status,
                // services je niz objekata { id, name, price, duration, description }
                'services'     => $a->services->map(fn($s) => [
                    'id'          => $s->id,
                    'name'        => $s->name,
                    'price'       => $s->price,
                    'duration'    => $s->duration,
                    'description' => $s->description,
                ])->all(),
            ];
        });
        return inertia('Owner/Dashboard', [
            'countToday'         => $countToday,
            'countWeek'          => $countWeek,
            'countMonth'         => $countMonth,
            'topServices'        => $topServices,
            'todaysAppointments' => $todaysAppointments,
        ]);
    }

    public function exportTodayPdf()
    {
        $today = now()->toDateString();
        $appointments = Appointment::with(['service','employee','user'])
            ->whereDate('date', $today)
            ->orderBy('start_time')
            ->get();
         $dompdf = app('dompdf.wrapper');

        $dompdf->loadView('pdf.owner_appointments_pdf', [
            'appointments' => $appointments,
            'date'         => $today,
        ])->setPaper('a4','portrait');

        return $dompdf->download("appointments_{$today}.pdf");
    }
}
