<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use App\Models\DentalChart;
use App\Models\DentalChartDiagnosis;
use App\Models\DentalChartIntervention;
use App\Models\DentalChartTherapy;
use App\Models\DentalChartToothStatus;
use App\Models\DiagnosisType;
use App\Models\Invoice;
use App\Models\MaterialType;
use App\Models\TherapyType;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

/**
 * Controller for managing a patient's dental chart within the owner section.
 *
 * All methods here accept a User instance and derive the appropriate
 * DentalChart from that user and the currently authenticated owner's salon.
 * This ensures we never attempt to access a chart with a null dental_chart_id
 * when creating related records (interventions, therapies, diagnoses, etc.).
 */
class DentalChartController extends Controller
{
    /**
     * Return the owner's dental chart dashboard for a given user.
     */
    public function dashboard(User $user)
    {
        return Inertia::render('Owner/Users/Chart', [
            'user' => $user,
        ]);
    }

    /**
     * Helper to find or create the dental chart for the given user and
     * authenticated salon.
     */
    protected function getOrCreateChart(User $user): DentalChart
    {
        return DentalChart::firstOrCreate([
            'user_id' => $user->id,
            'salon_id' => Auth::user()->ownedSalon->id,
        ]);
    }

    /**
     * Display the odontogram page with statuses and related data.
     */
    public function odontogram(User $user)
    {
        $chart = $this->getOrCreateChart($user);

        // Surface statuses for colouring the odontogram.
        $statuses = DentalChartToothStatus::where('dental_chart_id', $chart->id)->get();

        // Lookup tables for diagnosis and therapy types.
        $therapyTypes   = TherapyType::all()->pluck('name');
        $diagnosisTypes = DiagnosisType::all()->pluck('name');

        // Load related interventions, therapies and diagnoses for this chart.
        $interventions = DentalChartIntervention::where('dental_chart_id', $chart->id)
            ->with(['tooth', 'doctor'])
            ->orderBy('performed_at', 'desc')
            ->get();

        $therapies = DentalChartTherapy::where('dental_chart_id', $chart->id)
            ->with(['therapyType', 'doctor'])
            ->orderBy('applied_at', 'desc')
            ->get();

        $diagnoses = DentalChartDiagnosis::where('dental_chart_id', $chart->id)
            ->with('diagnosisType')
            ->orderBy('diagnosed_at', 'desc')
            ->get();

        // Treatment plans are optional; leave as empty array unless implemented.
        $treatmentPlans = [];

        return Inertia::render('Owner/Users/Chart/Odontogram', [
            'user'           => $user,
            'chart_id'       => $chart->id,
            'statuses'       => $statuses,
            'therapyTypes'   => $therapyTypes,
            'diagnosisTypes' => $diagnosisTypes,
            'interventions'  => $interventions,
            'therapies'      => $therapies,
            'diagnoses'      => $diagnoses,
            'treatmentPlans' => $treatmentPlans,
        ]);
    }

    /**
     * Save a new intervention for the patient's chart.
     */
    public function saveIntervention(Request $request, User $user)
    {
        $data = $request->validate([
            'tooth_id'     => 'required',
            'surface'      => 'required|string',
            'type'         => 'required|string|max:255',
            'description'  => 'nullable|string',
            'performed_at' => 'required|date',
        ]);

        $chart = $this->getOrCreateChart($user);
        $data['dental_chart_id'] = $chart->id;
        $data['doctor_id']       = Auth::id();

        DentalChartIntervention::create($data);

        return redirect()->route('owner.users.chart.odontogram', $user->id)
            ->with('success', 'Intervencija je sačuvana.');
    }

    /**
     * Save a new therapy entry for the patient's chart.
     */
    public function saveTherapy(Request $request, User $user)
    {
        $data = $request->validate([
            'therapy_type' => 'required|string',
            'note'         => 'nullable|string',
            'applied_at'   => 'required|date',
        ]);

        $chart = $this->getOrCreateChart($user);
        $data['dental_chart_id'] = $chart->id;

        DentalChartTherapy::create($data);

        return redirect()->route('owner.users.chart.odontogram', $user->id)
            ->with('success', 'Terapija je sačuvana.');
    }

    /**
     * Save a new diagnosis entry for the patient's chart.
     */
    public function saveDiagnosis(Request $request, User $user)
    {
        $data = $request->validate([
            'diagnosis_type' => 'required|string',
            'description'    => 'nullable|string',
            'color'          => 'nullable|string|max:7',
            'diagnosed_at'   => 'required|date',
        ]);

        $chart = $this->getOrCreateChart($user);
        $data['dental_chart_id'] = $chart->id;

        DentalChartDiagnosis::create($data);

        return redirect()->route('owner.users.chart.odontogram', $user->id)
            ->with('success', 'Dijagnoza je sačuvana.');
    }

    /**
     * Save a planned procedure entry. Implementation is left empty for now.
     */
    public function savePlan(Request $request, User $user)
    {
        $request->validate([
            'tooth_id'   => 'required',
            'plan'       => 'required|string',
            'note'       => 'nullable|string',
            'planned_at' => 'required|date',
        ]);

        // Currently not persisted because there is no DentalChartPlan model.
        // Extend this method when you implement your own planning logic.
        return redirect()->route('owner.users.chart.odontogram', $user->id)
            ->with('success', 'Plan terapije je sačuvan.');
    }

    /**
     * Save statuses for selected surfaces on the odontogram.
     */
    public function saveToothStatuses(Request $request, User $user)
    {
        $request->validate([
            'dataItems' => 'required|array',
            'chart_id'  => 'required|exists:dental_charts,id',
        ]);

        $chartId = $request->input('chart_id');
        $data    = $request->input('dataItems');

        foreach ($data as $item) {
            DentalChartToothStatus::updateOrCreate([
                'dental_chart_id' => $chartId,
                'tooth_id'        => $item['tooth_id'],
                'surface'         => $item['surface'],
            ], [
                'status'      => $item['status'],
                'color'       => $item['color'] ?? null,
                'note'        => $item['note'] ?? null,
                'status_date' => now(),
            ]);
        }

        return redirect()->route('owner.users.chart.odontogram', $user->id)
            ->with('success', 'Sačuvano!');
    }

    /**
     * Display history of tooth entries. Placeholder view.
     */
    public function toothHistory(User $user)
    {
        return Inertia::render('Owner/Users/Chart/ToothHistory', [
            'user' => $user,
        ]);
    }

    /**
     * Display therapies for this chart. Placeholder view.
     */
    public function therapies(User $user)
    {
        return Inertia::render('Owner/Users/Chart/Therapies', [
            'user' => $user,
        ]);
    }

    /**
     * Display diagnoses for this chart. Placeholder view.
     */
    public function diagnoses(User $user)
    {
        return Inertia::render('Owner/Users/Chart/Diagnoses', [
            'user' => $user,
        ]);
    }

    /**
     * Display the treatment plan page. Placeholder view.
     */
    public function treatmentPlan(User $user)
    {
        return Inertia::render('Owner/Users/Chart/TreatmentPlan', [
            'user' => $user,
        ]);
    }

    /**
     * Display the visit history page. Placeholder view.
     */
    public function visits(User $user)
    {
        return Inertia::render('Owner/Users/Chart/Visits', [
            'user' => $user,
        ]);
    }

    /**
     * Display the staff history page. Placeholder view.
     */
    public function staffHistory(User $user)
    {
        return Inertia::render('Owner/Users/Chart/StaffHistory', [
            'user' => $user,
        ]);
    }

    /**
     * Display the activity log page. Placeholder view.
     */
    public function activityLog(User $user)
    {
        return Inertia::render('Owner/Users/Chart/ActivityLog', [
            'user' => $user,
        ]);
    }

    /**
     * Show the patient's basic details form.
     */
    public function basic(User $user)
    {
        $chart = $this->getOrCreateChart($user);
        return Inertia::render('Owner/Users/Chart/Basic', [
            'user'  => $user,
            'chart' => $chart,
        ]);
    }

    /**
     * Persist changes to the patient's basic information and chart notes.
     */
    public function updateBasic(Request $request, User $user)
    {
        $validated = $request->validate([
            'phone'         => 'nullable|string|max:50',
            'email'         => 'nullable|email|max:255',
            'date_of_birth' => 'nullable|date',
            'allergies'     => 'nullable|string|max:255',
            'medical_notes' => 'nullable|string|max:255',
        ]);

        $chart = $this->getOrCreateChart($user);

        // Update the user fields.
        $user->update([
            'phone'         => $validated['phone'],
            'email'         => $validated['email'],
            'date_of_birth' => $validated['date_of_birth'],
        ]);

        // Update the chart fields.
        $chart->update([
            'allergies'     => $validated['allergies'],
            'medical_notes' => $validated['medical_notes'],
        ]);

        return redirect()->route('owner.users.chart.basic', $user->id)
            ->with('success', 'Podaci su sačuvani.');
    }

    /**
     * Show the anamnesis form for a chart.
     */
    public function anamnesis(User $user)
    {
        $chart = $this->getOrCreateChart($user);
        return Inertia::render('Owner/Users/Chart/Anamnesis', [
            'user'  => $user,
            'chart' => $chart,
        ]);
    }

    /**
     * Save anamnesis values to the chart.
     */
    public function updateAnamnesis(Request $request, User $user)
    {
        $data = $request->validate([
            'chronic_diseases'        => 'boolean',
            'smoker'                  => 'boolean',
            'alcohol'                 => 'boolean',
            'anticoagulant_therapy'   => 'boolean',
            'infectious_diseases'     => 'boolean',
            'malignant_diseases'      => 'boolean',
            'regular_therapy'         => 'boolean',
            'cardiovascular_diseases' => 'boolean',
            'other_notes'             => 'nullable|string',
        ]);

        $chart = $this->getOrCreateChart($user);
        $chart->update($data);

        return redirect()->route('owner.users.chart.anamnesis', $user->id)
            ->with('success', 'Anamneza je sačuvana.');
    }

    /**
     * Prikaz dokumenata (snimci, izveštaji) vezanih za karton.
     */
    public function documents(User $user)
    {

        $chart = DentalChart::firstOrCreate([
            'user_id' => $user->id,
            'salon_id' => Auth::user()->ownedSalon->id,
        ]);
        $documents = $chart->documents()->with('tooth')->get();
        // Učitaj korisnika kako bi se mogao prikazati "Nazad" link
        return Inertia::render('Owner/Users/Chart/DocumentsManager', [
            'chart'     => $chart,
            'user'      => $user,
            'documents' => $documents,
        ]);
    }
    /**
     * Upload a new document for the chart.
     */
    public function uploadDocument(Request $request, User $user)
    {
        $validated = $request->validate([
            'file'     => 'required|file',
            'type'     => 'required|string|max:255',
            'title'    => 'required|string|max:255',
            'note'     => 'nullable|string',
            'tooth_id' => 'nullable|string',
        ]);

        $chart = $this->getOrCreateChart($user);

        $path = $validated['file']->store('documents', 'public');
        $chart->documents()->create([
            'type'     => $validated['type'],
            'title'    => $validated['title'],
            'note'     => $validated['note'],
            'file'     => '/storage/' . $path,
            'tooth_id' => $validated['tooth_id'] ?: null,
        ]);

        return redirect()->route('owner.users.chart.documents', $user->id)
            ->with('success', 'Dokument je sačuvan.');
    }

    /**
     * Display the financial page with invoices and estimates.
     */
    public function financial(User $user)
    {
        $chart = $this->getOrCreateChart($user);
        // Some applications might not have the estimates relation; provide empty array if missing.
        $estimates = method_exists($chart, 'estimates') ? $chart->estimates()->get() : [];
        $invoices  = method_exists($chart, 'invoices') ? $chart->invoices()->get() : [];

        return Inertia::render('Owner/Users/Chart/Financial', [
            'user'      => $user,
            'chart'     => $chart,
            'invoices'  => $invoices,
            'estimates' => $estimates,
        ]);
    }

    /**
     * Save a new estimate for the chart.
     */
    public function saveEstimate(Request $request, User $user)
    {
        $data = $request->validate([
            'estimate_date' => 'required|date',
            'total'         => 'required|numeric',
            'status'        => 'required|string',
        ]);
        $chart = $this->getOrCreateChart($user);
        if (method_exists($chart, 'estimates')) {
            $chart->estimates()->create($data);
        }
        return redirect()->route('owner.users.chart.financial', $user->id)
            ->with('success', 'Predračun je sačuvan.');
    }

    /**
     * Save a new invoice for the chart.
     */
    public function saveInvoice(Request $request, User $user)
    {
        $data = $request->validate([
            'invoice_date' => 'required|date',
            'total'        => 'required|numeric',
            'status'       => 'required|string',
        ]);
        $chart = $this->getOrCreateChart($user);
        if (method_exists($chart, 'invoices')) {
            $chart->invoices()->create($data);
        }
        return redirect()->route('owner.users.chart.financial', $user->id)
            ->with('success', 'Račun je sačuvan.');
    }

    /**
     * Display the materials page with a form to add new materials.
     */
    public function materials(User $user)
    {
        $chart = $this->getOrCreateChart($user);
        $materials = method_exists($chart, 'materials') ? $chart->materials()->with('materialType')->get() : [];
        $materialTypes = MaterialType::all();
        return Inertia::render('Owner/Users/Chart/Materials', [
            'user'          => $user,
            'chart'         => $chart,
            'materials'     => $materials,
            'materialTypes' => $materialTypes,
        ]);
    }

    /**
     * Save a new material usage entry for the chart.
     */
    public function saveMaterial(Request $request, User $user)
    {
        $data = $request->validate([
            'material_type_id' => 'required|exists:material_types,id',
            'quantity'         => 'required|numeric',
            'unit'             => 'nullable|string|max:255',
            'used_at'          => 'required|date',
        ]);
        $chart = $this->getOrCreateChart($user);
        if (method_exists($chart, 'materials')) {
            $chart->materials()->create($data);
        }
        return redirect()->route('owner.users.chart.materials', $user->id)
            ->with('success', 'Materijal je sačuvan.');
    }

    /**
     * Display invoices for the chart. Placeholder.
     */
    public function invoices(User $user)
    {
        $chart = $this->getOrCreateChart($user);
        $invoices = Invoice::where('dental_chart_id', $chart->id)
            ->with('items')
            ->get();
        return Inertia::render('Owner/Users/Chart/Invoices', [
            'user'     => $user,
            'chart'    => $chart,
            'invoices' => $invoices,
        ]);
    }
}
