<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Spatie\Permission\PermissionRegistrar;

class DesignController extends Controller
{

    public function edit()
    {

        $salon = Auth::user()->ownedSalon;
        // узмемо доступне теме из config-а
        $themes = config('daisyui.themes', []);

        return inertia('Owner/Design', [
            'salon'  => [
                'logo_path'      => $salon->logo_path,
                'primary_color'  => $salon->primary_color,
                'secondary_color'=> $salon->secondary_color,
                'theme'          => $salon->theme,
            ],
            'salonSlug' => $salon->slug,      // ← додај ово
            'themes' => $themes,
        ]);
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'logo'            => 'nullable|image|max:2048',
            'primary_color'   => ['nullable','regex:/^#[0-9A-Fa-f]{6}$/'],
            'secondary_color' => ['nullable','regex:/^#[0-9A-Fa-f]{6}$/'],
            'theme' => [
                'required',
                'in:'.implode(',', config('daisyui.themes')),
            ],
        ]);

        $salon = Auth::user()->ownedSalon;
        if ($request->hasFile('logo')) {
            $path = $request->file('logo')->store('public/logos');
            $data['logo_path'] = Storage::url($path);
        }

        $salon->update([
            'logo_path'      => $data['logo_path']      ?? $salon->logo_path,
            'primary_color'  => $data['primary_color'],
            'secondary_color'=> $data['secondary_color'],
            'theme'          => $data['theme'],
        ]);

        return redirect()->route('owner.design.edit')
                         ->with('success','Dizajn uspješno ažuriran.');
    }
}
