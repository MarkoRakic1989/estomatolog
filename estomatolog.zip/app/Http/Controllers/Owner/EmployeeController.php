<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreEmployeeRequest;
use App\Http\Requests\UpdateEmployeeRequest;
use App\Models\Employee;
use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
// Нови фасада namespace
use Intervention\Image\Laravel\Facades\Image;

class EmployeeController extends Controller
{

    public function index()
    {
        $salon = Auth::user()->ownedSalon;

        $employees = Employee::with(['user.roles', 'services'])
            ->where('salon_id', $salon->id)
            ->get()
            ->map(fn($emp) => [
                'id'        => $emp->id,
                'name'      => $emp->name,
                'email'     => $emp->user->email,
                'phone'     => $emp->phone,
                'photo'     => $emp->photo,
                'roles'     => $emp->user->getRoleNames(),
                'services'  => $emp->services,
            ]);

        return inertia('Owner/Employees/Index', compact('employees'));
    }

    public function create()
    {
        $services = Auth::user()->ownedSalon->services;

        return inertia('Owner/Employees/Form', [
            'employee' => null,
            'services' => $services,
        ]);
    }

    public function store(StoreEmployeeRequest $request)
    {
        $data  = $request->validated();
        $salon = Auth::user()->ownedSalon;

        // 1) User логика (стаје нетакнуто)
        $user = User::firstWhere('email', $data['email']);
        if ($user) {
            $user->hasRole('worker') || $user->assignRole('worker');
        } else {
            $user = User::create([
                'name'     => $data['name'],
                'email'    => $data['email'],
                'password' => bcrypt(Str::random(12)),
            ]);
            $user->assignRole('worker');
        }
        $salon->users()->syncWithoutDetaching([$user->id]);

        // 2) Upload photo
        $filename = null;
        if ($request->hasFile('photo')) {
            $file      = $request->file('photo');
            $ext       = $file->getClientOriginalExtension();
            $slugName  = Str::slug($data['name']);
            $salonSlug = Str::slug($salon->slug);
            $base      = "bookapp-{$salonSlug}-{$slugName}";
            $timestamp = time();
            $filename  = "{$base}-{$timestamp}.{$ext}";

            // Ако већ постоји, додај random суфикс
            if (Storage::disk('public')->exists("images/{$filename}")) {
                $filename = "{$base}-{$timestamp}-".Str::random(4).".{$ext}";
            }

            // Resize + save у public/storage/images
           $img = Image::read($file)
            ->cover(300, 450)
            ->encodeByExtension($ext, quality: 90);
            Storage::disk('public')->put("images/{$filename}", (string) $img);
        }

        // 3) Креирање Employee
        $employee = Employee::create([
            'salon_id' => $salon->id,
            'user_id'  => $user->id,
            'name'     => $data['name'],
            'email'    => $data['email'],
            'phone'    => $data['phone'] ?? null,
            'photo'    => $filename,
        ]);

        $employee->services()->sync($data['service_ids'] ?? []);

        return redirect()->route('owner.employees.index')
                         ->with('success', 'Zaposleni je uspešno dodat.');
    }

    public function edit(Employee $employee)
    {
        $salon = Auth::user()->ownedSalon;
        abort_unless($employee->salon_id === $salon->id, 403);

        return inertia('Owner/Employees/Form', [
            'employee' => [
                'id'          => $employee->id,
                'name'        => $employee->name,
                'phone'       => $employee->phone,
                'photo'       => $employee->photo,
                'service_ids' => $employee->services->pluck('id')->toArray(),
                'email'       => $employee->user->email, // readonly
            ],
            'services' => $salon->services,
        ]);
    }

    public function update(UpdateEmployeeRequest $request, Employee $employee)
    {
        $salon = Auth::user()->ownedSalon;
        abort_unless($employee->salon_id === $salon->id, 403);

        $data = $request->validated();

        // 1) Нови Upload photo
        if ($request->hasFile('photo')) {
            // Обриши стару
            $employee->photo && Storage::disk('public')->delete("images/{$employee->photo}");

            $file      = $request->file('photo');
            $ext       = $file->getClientOriginalExtension();
            $slugName  = Str::slug($data['name']);
            $salonSlug = Str::slug($salon->slug);
            $base      = "bookapp-{$salonSlug}-{$slugName}";
            $timestamp = time();
            $filename  = "{$base}-{$timestamp}.{$ext}";

            if (Storage::disk('public')->exists("images/{$filename}")) {
                $filename = "{$base}-{$timestamp}-".Str::random(4).".{$ext}";
            }

            $img = Image::read($file)
            ->cover(300, 450)
            ->encodeByExtension($ext, quality: 90);
            Storage::disk('public')->put("images/{$filename}", (string) $img);

            $employee->photo = $filename;
        }

        // 2) Ажурирање Employee без мејла
        $employee->update([
            'name'  => $data['name'],
            'phone' => $data['phone'] ?? null,
            // photo већ намештен горе
        ]);

        $employee->services()->sync($data['service_ids'] ?? []);

        return redirect()->route('owner.employees.index')
                         ->with('success', 'Podaci zaposlenog su ažurirani.');
    }

    public function destroy(Employee $employee)
    {
        $salon = Auth::user()->ownedSalon;
        abort_unless($employee->salon_id === $salon->id, 403);

        // Detach pivot
        $salon->users()->detach($employee->user_id);

        // Delete photo
        $employee->photo && Storage::disk('public')->delete("images/{$employee->photo}");

        // Delete record
        $employee->delete();

        return redirect()->route('owner.employees.index')
                         ->with('success', 'Zaposleni je uklonjen.');
    }
}
