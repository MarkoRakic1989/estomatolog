<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use App\Models\Gallery;
use App\Models\GalleryImage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class GalleryController extends Controller
{
    public function index()
    {
        $galleries = Gallery::with('images')->get();
        return inertia('Owner/Galleries/Index', compact('galleries'));
    }

    public function create()
    {
        return inertia('Owner/Galleries/Form', ['gallery' => null]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name'   => 'required|string|max:255',
            'images' => 'nullable|array',
            'images.*' => 'image|max:2048',
        ]);
        $gallery = Gallery::create(['name'=> $data['name']]);
        if (!empty($data['images'])) {
            foreach ($data['images'] as $img) {
                $path = $img->store('public/galleries');
                $gallery->images()->create(['path'=>Storage::url($path)]);
            }
        }
        return redirect()->route('owner.galleries.index');
    }

    public function edit(Gallery $gallery)
    {
        return inertia('Owner/Galleries/Form', ['gallery'=> $gallery->load('images')]);
    }

    public function update(Request $request, Gallery $gallery)
    {
        $data = $request->validate([
            'name'   => 'required|string|max:255',
            'images' => 'nullable|array',
            'images.*' => 'image|max:2048',
        ]);
        $gallery->update(['name'=> $data['name']]);
        if (!empty($data['images'])) {
            foreach ($data['images'] as $img) {
                $path = $img->store('public/galleries');
                $gallery->images()->create(['path'=>Storage::url($path)]);
            }
        }
        return redirect()->route('owner.galleries.index');
    }

    public function destroy(Gallery $gallery)
    {
        // obrisi fajlove
        foreach ($gallery->images as $img) {
            Storage::delete(str_replace('/storage/','public/',$img->path));
        }
        $gallery->delete();
        return redirect()->route('owner.galleries.index');
    }
}
