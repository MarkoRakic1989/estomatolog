<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreCouponRequest;
use App\Mail\PromoEmail;
use App\Models\Coupon;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;

class MarketingController extends Controller
{
    public function showEmailForm()
    {
        return inertia('Owner/Marketing/Email');
    }

    public function sendEmail(Request $request)
    {
        $data = $request->validate([
            'subject' => 'required|string',
            'body'    => 'required|string',
        ]);

        $users = Auth::user()->salon->clients;
        foreach ($users as $user) {
            Mail::to($user->email)
                ->send(new PromoEmail($data['subject'], $data['body']));
        }

        return back()->with('success','Emails sent.');
    }

    public function couponsIndex()
    {
        $coupons = Coupon::where('active',true)->get();
        return inertia('Owner/Marketing/Coupons/Index', compact('coupons'));
    }

    public function couponsCreate()
    {
        return inertia('Owner/Marketing/Coupons/Create');
    }

    public function couponsStore(StoreCouponRequest $request)
    {
        Coupon::create($request->validated());
        return redirect()->route('owner.marketing.coupons.index');
    }

    public function couponsDestroy(Coupon $coupon)
    {
        $coupon->delete();
        return back();
    }
}
