<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use App\Models\Page;
use Illuminate\Http\Request;

class PageController extends Controller
{
    public function index()
    {
        $pages = Page::orderBy('created_at','desc')->get();
        return inertia('Owner/Pages/Index', ['pages' => $pages]);
    }

    public function create()
    {
        return inertia('Owner/Pages/Form', ['page' => null]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'slug'    => 'required|unique:pages,slug',
            'title'   => 'required|string',
            'content' => 'required|string',
        ]);
        Page::create($data);
        return redirect()->route('owner.pages.index');
    }

    public function edit(Page $page)
    {
        return inertia('Owner/Pages/Form', ['page' => $page]);
    }

    public function update(Request $request, Page $page)
    {
        $data = $request->validate([
            'slug'    => "required|unique:pages,slug,{$page->id}",
            'title'   => 'required|string',
            'content' => 'required|string',
        ]);
        $page->update($data);
        return redirect()->route('owner.pages.index');
    }

    public function destroy(Page $page)
    {
        $page->delete();
        return redirect()->route('owner.pages.index');
    }
}
