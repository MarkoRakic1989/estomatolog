<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreServiceCategoryRequest;
use App\Http\Requests\UpdateServiceCategoryRequest;
use App\Models\ServiceCategory;
use Intervention\Image\Laravel\Facades\Image;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Inertia\Inertia;
use Illuminate\Support\Str;

class ServiceCategoryController extends Controller
{
    public function index(Request $request)
    {
        $salonId  = Auth::user()->ownedSalon->id;
        $parentId = $request->input('parent_id');
        $parent   = $parentId
                    ? ServiceCategory::where('salon_id', $salonId)
                                     ->findOrFail($parentId)
                    : null;

        $serviceCategories = ServiceCategory::where('salon_id', $salonId)
            ->where('parent_id', $parentId)
            ->with('children')     // <— obavezno!
            ->orderBy('name')
            ->get();

        return Inertia::render('Owner/ServiceCategories/Index', [
            'serviceCategories' => $serviceCategories,
            'parent'            => $parent,
        ]);
    }

    public function create(Request $request)
    {
        $salonId = Auth::user()->ownedSalon->id;
        $parents = ServiceCategory::where('salon_id', $salonId)
                     ->whereNull('parent_id')
                     ->orderBy('name')
                     ->get();

        return Inertia::render('Owner/ServiceCategories/Create', [
            'parents'   => $parents,
            'parent_id' => $request->input('parent_id'),
        ]);
    }

    public function store(StoreServiceCategoryRequest $request)
    {
        $salonId = Auth::user()->ownedSalon->id;
        $data    = $request->validated();
        $data['salon_id'] = $salonId;

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $ext  = $file->getClientOriginalExtension();
            $filename = 'service-categories-'.time().'.'.$ext;

            // resize to 300x200
           $img = Image::read($file)
            ->cover(300, 200)
            ->encodeByExtension($ext, quality: 90);

            Storage::disk('public')->put("images/service-categories/{$filename}", (string) $img);

            $data['image'] = $filename;
        }

        ServiceCategory::create($data);

        return redirect()
            ->route('owner.service-categories.index');
    }

    public function edit(ServiceCategory $serviceCategory)
    {
        $salonId = Auth::user()->ownedSalon->id;
        $parents = ServiceCategory::where('salon_id', $salonId)
                     ->whereNull('parent_id')
                     ->where('id', '!=', $serviceCategory->id)
                     ->orderBy('name')
                     ->get();

        return Inertia::render('Owner/ServiceCategories/Edit', [
            'serviceCategory' => $serviceCategory,
            'parents'         => $parents,
        ]);
    }

    public function update(UpdateServiceCategoryRequest $request, ServiceCategory $serviceCategory)
    {
        $data = $request->validated();

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $ext  = $file->getClientOriginalExtension();
            $filename = 'service-categories-'.time().'.'.$ext;

            // resize to 300x200
           $img = Image::read($file)
            ->cover(300, 200)
            ->encodeByExtension($ext, quality: 90);

            Storage::disk('public')->put("images/service-categories/{$filename}", (string) $img);
            $data['image'] = $filename;
        }

        $serviceCategory->update($data);

        return redirect()
            ->route('owner.service-categories.index');
    }

    public function destroy(ServiceCategory $serviceCategory)
    {
        $serviceCategory->delete();
        return back();
    }
}
