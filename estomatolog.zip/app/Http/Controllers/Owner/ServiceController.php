<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use App\Models\Service;
use App\Models\ServiceCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Laravel\Facades\Image;
use Inertia\Inertia;

class ServiceController extends Controller
{
    public function index()
    {
        $salon = Auth::user()->ownedSalon;
        $services = $salon->services()
                          ->orderBy('name')
                          ->paginate(15);

        return Inertia::render('Owner/Services/Index', [
            'services' => $services,
        ]);
    }

    public function create()
    {
        $salon = Auth::user()->ownedSalon;
        $categories = ServiceCategory::where('salon_id', $salon->id)
                                     ->orderBy('parent_id')
                                     ->orderBy('name')
                                     ->get();

        return Inertia::render('Owner/Services/Create', [
            'categories' => $categories,
        ]);
    }

    public function store(Request $request)
    {
        $salon = Auth::user()->ownedSalon;

        $data = $request->validate([
            'name'                 => 'required|string|max:255',
            'description'          => 'nullable|string',
            'service_category_id'  => 'required|exists:service_categories,id',
            'price'                => 'required|numeric|min:0',
            'duration'             => 'required|integer|min:1',
            'image'                => 'nullable|image|max:2048',
        ]);

        // Handle upload & resize
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $ext  = $file->getClientOriginalExtension();
            $filename = 'service-'.time().'.'.$ext;

            $img = Image::read($file)
                        ->cover(300, 200)
                        ->encodeByExtension($ext, quality: 90);

            Storage::disk('public')->put("images/{$filename}", (string) $img);
            $data['icon'] = $filename;
        }

        $data['salon_id'] = $salon->id;
        $service = Service::create($data);

        // Sync pivot table
        $service->serviceCategories()->sync([ $data['service_category_id'] ]);

        return redirect()
            ->route('owner.services.index')
            ->with('success', 'Service je uspešno kreiran.');
    }

    public function edit(Service $service)
    {
        $salon = Auth::user()->ownedSalon;
        abort_unless($service->salon_id === $salon->id, 403);

        $categories = ServiceCategory::where('salon_id', $salon->id)
                                     ->orderBy('parent_id')
                                     ->orderBy('name')
                                     ->get();

        $selectedCategoryId = $service->serviceCategories->pluck('id')->first();
        return Inertia::render('Owner/Services/Edit', [
            'service'    => $service,
            'categories' => $categories,
            'selectedCategoryId' => $selectedCategoryId,
        ]);
    }

    public function update(Request $request, Service $service)
    {
        $salon = Auth::user()->ownedSalon;
        abort_unless($service->salon_id === $salon->id, 403);

        $data = $request->validate([
            'name'                 => 'required|string|max:255',
            'description'          => 'nullable|string',
            'service_category_id'  => 'required|exists:service_categories,id',
            'price'                => 'required|numeric|min:0',
            'duration'             => 'required|integer|min:1',
            'image'                => 'nullable|image|max:2048',
        ]);

        // If new image uploaded, delete old + store new
        if ($request->hasFile('image')) {
            if ($service->icon) {
                Storage::disk('public')->delete("images/{$service->icon}");
            }
            $file = $request->file('image');
            $ext  = $file->getClientOriginalExtension();
            $filename = 'service-'.time().'.'.$ext;

            $img = Image::read($file)
                        ->cover(300, 200)
                        ->encodeByExtension($ext, quality: 90);

            Storage::disk('public')->put("images/{$filename}", (string) $img);
            $data['icon'] = $filename;
        }

        $data['salon_id'] = $salon->id;
        $service->update($data);

        // Sync pivot table
        $service->serviceCategories()->sync([ $data['service_category_id'] ]);

        return redirect()
            ->route('owner.services.index')
            ->with('success', 'Service je uspešno ažuriran.');
    }

    public function toggleSelfBookable(Request $request, Service $service)
    {
        $request->validate([
            'self_bookable' => 'required|boolean',
        ]);

        $service->update([
            'self_bookable' => $request->input('self_bookable'),
        ]);

        return redirect()
            ->route('owner.services.index')
            ->with('success', 'Service je uspešno ažuriran.');
    }

    public function destroy(Service $service)
    {
        if ($service->icon) {
            Storage::disk('public')->delete("images/{$service->icon}");
        }
        $service->delete();

        return redirect()
            ->route('owner.services.index')
            ->with('success', 'Service je obrisan.');
    }
}
