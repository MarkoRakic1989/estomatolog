<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\ServiceMaterial;

class ServiceMaterialController extends Controller
{
    public function index($service_id)
    {
        $materials = ServiceMaterial::where('service_id', $service_id)->get();
        return response()->json($materials);
    }

    public function store(Request $request)
    {
        $request->validate([
            'service_id'    => 'required|exists:services,id',
            'material_name' => 'required|string|max:100',
            'unit'          => 'nullable|string|max:32',
            'quantity'      => 'required|numeric|min:0.001',
        ]);

        $material = ServiceMaterial::create($request->only(['service_id', 'material_name', 'unit', 'quantity']));
        return response()->json($material, 201);
    }

    public function update(Request $request, $id)
    {
        $material = ServiceMaterial::findOrFail($id);
        $request->validate([
            'material_name' => 'required|string|max:100',
            'unit'          => 'nullable|string|max:32',
            'quantity'      => 'required|numeric|min:0.001',
        ]);
        $material->update($request->only(['material_name', 'unit', 'quantity']));
        return response()->json($material);
    }

    public function destroy($id)
    {
        $material = ServiceMaterial::findOrFail($id);
        $material->delete();
        return response()->json(['message' => 'Materijal uklonjen.']);
    }
}
