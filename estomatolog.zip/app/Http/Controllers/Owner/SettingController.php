<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use App\Models\Employee;
use Spatie\Permission\Models\Role;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Facades\Auth;

class SettingController extends Controller
{
    public function rolesIndex()
    {
        $salon = Auth::user()->ownedSalon;

        $users = $salon->employees()          // вучу само запослене
            ->with('user.roles')             // учитам да бих могао онима checkboxes
            ->get()
            ->map(fn(Employee $emp) => $emp->user)
            ->filter();                      // елиминишем null ако неко нема user

        $roles = Role::all();

        return Inertia::render('Owner/Settings/Roles', compact('users','roles'));
    }

    public function updateRoles(Request $request)
    {
        $data = $request->validate([
            'user_id' => 'required|exists:users,id',
            'roles'   => 'nullable|array',
            'roles.*' => 'exists:roles,name',
        ]);

        $user = \App\Models\User::findOrFail($data['user_id']);
        $user->syncRoles($data['roles'] ?? []);

        return back()->with('success','Uloge su ažurirane.');
    }
}
