<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use App\Models\Package;
use App\Models\Subscription;
use App\Models\SubscriptionPayment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Mail\SubscriptionInvoiceMail;
use Illuminate\Support\Facades\Mail;


class SubscriptionController extends Controller
{
    public function index()
    {
        $salon = Auth::user()->ownedSalon;
        $current = $salon->subscriptions()->latest('ends_at')->first();
        $packages = Package::where('is_active', 1)->orderBy('price')->get();
        $payments = $current ? $current->payments()->orderByDesc('created_at')->get() : collect();

        return inertia('Owner/Subscription/Index', [
            'current' => $current,
            'packages' => $packages,
            'payments' => $payments,
        ]);
    }

    // Zahtevaj novi paket
    public function requestPackage(Request $request)
    {
        $salon = Auth::user()->ownedSalon;
        $package = Package::findOrFail($request->package_id);
        // Ako ima aktivnu/pending pretplatu za taj paket — zabrani novu
        $active = $salon->subscriptions()
            ->where('package_id', $package->id)
            ->where('salon_id', $salon->id)
            ->where('user_id', Auth::user()->id)
            ->whereIn('status', ['active', 'pending'])
            ->where('ends_at', '>=', now())
            ->exists();
        if ($active) {
            return back()->with('error', 'Već imate aktivnu ili naručenu pretplatu za ovaj paket.');
        }

        $sub = $salon->subscriptions()->create([
            'salon_id' => $salon->id,
            'user_id' => Auth::user()->id,
            'package_id' => $package->id,
            'status' => 'pending',
            'starts_at' => now(),
            'ends_at' => now()->addMonth(),
            'price' => $package->price,
        ]);
        Mail::to(Auth::user()->email)
            ->send(new SubscriptionInvoiceMail($salon, $package, $sub));
            Mail::to('markoteodesk@gmail.com')
    ->send(new SubscriptionInvoiceMail($salon, $package, $sub));
        return back()->with('success', 'Paket je naručen! Uplatite iznos i kliknite "Obavesti admina" kad uplata bude izvršena.');
    }

    // Korisnik šalje info adminu da je uplatio
    public function notifyPayment(Request $request)
    {
        $salon = Auth::user()->ownedSalon;
        $subscription = $salon->subscriptions()->latest('ends_at')->first();

        // Zabeleži uplate kao "pending"
        $payment = $subscription->payments()->create([
            'amount' => $subscription->price,
            'status' => 'pending',
            'note' => $request->note,
            'paid_at' => now(),
            'reference_number' => $request->reference_number,
        ]);

        // Pošalji email superadminu (menjaj email adresu po potrebi)
        Mail::raw(
            "Korisnik {$salon->name} ({$salon->id}) je prijavio uplatu za pretplatu #{$subscription->id}. 
            Iznos: {$payment->amount} RSD, Poziv na broj: {$payment->reference_number}, 
            Poruka korisnika: {$payment->note}",
            function ($m) {
                $m->to('markoteodesk@gmail.com')->subject('Nova prijava uplate za pretplatu');
            }
        );

        return back()->with('success', 'Vaša uplata je prijavljena. Administrator će je uskoro potvrditi.');
    }
}
