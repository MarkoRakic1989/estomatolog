<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Appointment;
use App\Models\Chart;
use App\Models\ToothStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;
use Illuminate\Support\Facades\File;

class UserController extends Controller
{
    /** Prikaz liste pacijenata, search i paginacija, badge za blokiranog */
    public function index(Request $request)
    {
        $salon = Auth::user()->ownedSalon;

        $query = $salon->users()->select('users.*');

        // Pretraga po imenu/emailu
        if ($request->filled('q')) {
            $q = $request->q;
            $query->where(function ($qr) use ($q) {
                $qr->where('users.name', 'like', "%{$q}%")
                    ->orWhere('users.email', 'like', "%{$q}%");
            });
        }

        $query->orderBy('users.name');

        $users = $query->paginate(20)->withQueryString();

        // Pripremi podatke za frontend (is_blocked badge)
        $users->getCollection()->transform(function ($user) {
            $user->is_blocked = (bool)($user->is_blocked ?? $user->blocked ?? false);
            return $user;
        });

        return Inertia::render('Owner/Users/Index', [
            'users' => $users,
            'category' => $salon->category->slug ?? null
        ]);
    }

    /** Blokiranje korisnika */
    public function block(User $user)
    {
        $this->authorize('users.manage');
        $user->update(['is_blocked' => true]);
        return back()->with('success', 'Pacijent blokiran');
    }

    /** Deblokiranje korisnika */
    public function unblock(User $user)
    {
        $this->authorize('users.manage');
        $user->update(['is_blocked' => false]);
        return back()->with('success', 'Pacijent odblokiran');
    }

    /** Prikaz tabovanog kartona korisnika (profil, odontogram, intervencije, badgevi, dokumenta, termini) */
    public function chart(User $user)
    {
        $salon = Auth::user()->ownedSalon;
        if (!$salon->users()->where('users.id', $user->id)->exists()) {
            abort(403, 'Nemate pravo pristupa ovom pacijentu.');
        }

        // Dohvati poslednji karton (Chart) pacijenta za ovaj salon
        $chart = $user->charts()->where('salon_id', $salon->id)->latest()->first();

        // Ako ne postoji, kreiraj novi
        if (!$chart) {
            $chart = $user->charts()->create([
                'salon_id' => $salon->id,
                'opened_at' => now(),
                'doctor_note' => null,
            ]);
        }

        // Ovde šalji samo osnovne podatke, svi tabovi vuku API podatke iz drugih kontrolera!
        return Inertia::render('Owner/Users/Chart', [
            'user' => $user,
            'chart' => $chart,
            // Ostali props po potrebi...
        ]);
    }

    /** Prikaz starih appointmenta i istorije — za tab 'intervencije' ili 'termini' */
    public function show(User $user)
    {
        $salonId = Auth::user()->ownedSalon->id;
        $appointments = Appointment::with(['employee', 'services', 'reports'])
            ->where('salon_id', $salonId)
            ->where('user_id', $user->id)
            ->orderByDesc('date')
            ->get();

        return Inertia::render('Owner/Users/Show', [
            'user'         => $user,
            'appointments' => $appointments,
        ]);
    }

    /** Snimi izveštaj za odabrani termin */
    public function report(User $user, Appointment $appointment, Request $request)
    {
        $salonId = Auth::user()->ownedSalon->id;
        abort_unless(
            $appointment->salon_id === $salonId
            && $appointment->user_id === $user->id,
            403
        );
        $data = $request->validate([
            'content' => 'required|string',
        ]);
        $appointment->reports()->create([
            'content' => $data['content'],
        ]);
        return back()->with('success', 'Izveštaj sačuvan');
    }

    /** Prikaz SVG odontograma (opcionalno) */
    public function dentalChart(User $user)
    {
        $salonId = Auth::user()->ownedSalon->id;
        $dentalChart = file_get_contents(resource_path('js/svg/vilica.svg'));

        // Povuci sve ToothStatus zapise za prikaz bojenja
        $toothStatuses = ToothStatus::whereHas('chart', function($q) use ($salonId, $user) {
            $q->where('salon_id', $salonId)
              ->where('user_id', $user->id);
        })->get(['tooth_id', 'surface', 'status', 'color', 'note', 'status_date', 'updated_at']);

        return Inertia::render('Owner/Users/DentalChart', [
            'user'         => $user,
            'dentalChart'  => $dentalChart,
            'toothStatuses'=> $toothStatuses,
        ]);
    }

    /** (API) SVG vilica kao raw fajl */
    public function loadDentalSvg(User $user)
    {
        $path = resource_path('svg/vilica.svg');
        if (!File::exists($path)) {
            abort(404, 'SVG not found');
        }
        return response(
            File::get($path),
            200,
            ['Content-Type' => 'image/svg+xml']
        );
    }
}
