<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use App\Models\WorkTime;
use App\Models\Appointment;
use App\Models\Employee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Illuminate\Support\Facades\DB;
class WorkTimeController extends Controller
{

    /**
     * GET /owner/worktimes
     * Prikaz kalendara sa svim slotovima i zaposlenima.
     */
    public function index(Request $request)
    {
        $salon = Auth::user()->ownedSalon;

        $employees = Employee::where('salon_id', $salon->id)
            ->orderBy('name')
            ->get();

        $worktimes = WorkTime::with('employee')
            ->whereIn('employee_id', $employees->pluck('id'))
            ->get();

        return Inertia::render('Owner/WorkTime/Index', [
            'employees' => $employees,
            'worktimes' => $worktimes,
            'week_start' => $request->input('week_start', now()->startOfWeek()->toDateString()),
        ]);
    }

    /**
     * POST /owner/worktimes
     * Kreiraj novi slot.
     */
    public function store(Request $request)
    {
        $salon = Auth::user()->ownedSalon;

        $data = $request->validate([
            'employee_id' => [
                'required','integer',
                Rule::exists('employees','id')->where('salon_id', $salon->id),
            ],
            'date'       => 'required|date',
            'start_time' => 'required|date_format:H:i',
            'end_time'   => 'required|date_format:H:i|after:start_time',
        ]);

        // Provera rezervacija
        $conflict = Appointment::where('employee_id', $data['employee_id'])
            ->where('date', $data['date'])
            ->where(function($q) use($data) {
                $q->whereBetween('start_time', [$data['start_time'], $data['end_time']])
                  ->orWhereBetween('end_time',   [$data['start_time'], $data['end_time']])
                  ->orWhereRaw('? BETWEEN start_time AND end_time', [$data['start_time']])
                  ->orWhereRaw('? BETWEEN start_time AND end_time', [$data['end_time']]);
            })->exists();

        if ($conflict) {
            return back()->with('error', 'Slot se ne može kreirati jer postoji rezervacija unutar odabranog vremena.');
        }

        // Provera preklapanja sa drugim radnim vremenskim slotovima
        $overlap = WorkTime::where('employee_id', $data['employee_id'])
            ->where('date', $data['date'])
            ->where(function($q) use($data) {
                $q->whereBetween('start_time', [$data['start_time'], $data['end_time']])
                  ->orWhereBetween('end_time',   [$data['start_time'], $data['end_time']])
                  ->orWhereRaw('? BETWEEN start_time AND end_time', [$data['start_time']])
                  ->orWhereRaw('? BETWEEN start_time AND end_time', [$data['end_time']]);
            })->exists();

        if ($overlap) {
            return back()->with('error', 'Slot se ne može kreirati jer se preklapa sa postojećim radnim vremenom.');
        }

        WorkTime::create($data);

        return redirect()->route('owner.worktimes.index')->with('success', 'Slot je uspešno kreiran.');
    }

    /**
     * POST /owner/worktimes/{worktime}/copy
     * Kopiraj postojeći slot na novi datum ili zaposlenog.
     */
    public function copy(Request $request, WorkTime $worktime)
    {
        $salon = Auth::user()->ownedSalon;

        $data = $request->validate([
            'target_date'  => 'required|date',
            'employee_id'  => [
                'sometimes','integer',
                Rule::exists('employees','id')->where('salon_id', $salon->id),
            ],
        ]);

        $empId = $data['employee_id'] ?? $worktime->employee_id;
        $date  = $data['target_date'];

        // Nemoj prepisivati tamo gde već ima slot
        $exists = WorkTime::where('employee_id', $empId)
            ->where('date', $date)
            ->exists();
        if ($exists) {
            return back()->with('error', 'Ciljni slot već postoji za odabranog zaposlenog i datum.');
        }

        // Provera rezervacija i preklapanja (kao u store)
        $conflict = Appointment::where('employee_id', $empId)
            ->where('date', $date)
            ->where(function($q) use($worktime) {
                $q->whereBetween('start_time', [$worktime->start_time, $worktime->end_time])
                  ->orWhereBetween('end_time',   [$worktime->start_time, $worktime->end_time])
                  ->orWhereRaw('? BETWEEN start_time AND end_time', [$worktime->start_time])
                  ->orWhereRaw('? BETWEEN start_time AND end_time', [$worktime->end_time]);
            })->exists();
        if ($conflict) {
            return back()->with('error', 'Ne možete kopirati slot jer postoji rezervacija u tom periodu.');
        }

        $overlap = WorkTime::where('employee_id', $empId)
            ->where('date', $date)
            ->where(function($q) use($worktime) {
                $q->whereBetween('start_time', [$worktime->start_time, $worktime->end_time])
                  ->orWhereBetween('end_time',   [$worktime->start_time, $worktime->end_time])
                  ->orWhereRaw('? BETWEEN start_time AND end_time', [$worktime->start_time])
                  ->orWhereRaw('? BETWEEN start_time AND end_time', [$worktime->end_time]);
            })->exists();
        if ($overlap) {
            return back()->with('error', 'Ne možete kopirati slot jer se preklapa sa postojećim radnim vremenom.');
        }

        WorkTime::create([
            'employee_id' => $empId,
            'date'        => $date,
            'start_time'  => $worktime->start_time,
            'end_time'    => $worktime->end_time,
        ]);

        return redirect()->route('owner.worktimes.index')->with('success', 'Slot je uspešno kopiran.');
    }

    /**
     * PUT /owner/worktimes/{worktime}
     * Ažuriraj postojeći slot.
     */
    public function update(Request $request, $worktime)
    {
        $slot = WorkTime::findOrFail($worktime);
        
        $salon = Auth::user()->ownedSalon;

        $data = $request->validate([
            'employee_id' => [
                'required','integer',
                Rule::exists('employees','id')->where('salon_id', $salon->id),
            ],
            'date'       => 'required|date',
            'start_time' => 'required|date_format:H:i',
            'end_time'   => 'required|date_format:H:i|after:start_time',
        ]);

        // Provera rezervacija
       $outside = Appointment::where('employee_id', $data['employee_id'])
            ->where('date', $data['date'])
            ->where(function($q) use($data) {
                $q->where('start_time', '<',  $data['start_time'])
                ->orWhere('end_time',   '>',  $data['end_time']);
            })->exists();

        if ($outside) {
            return back()->with('error', 'Ne možete pomeriti radno vreme tako da neki postojeći termin bude van radnog vremena.');
        }

        $slot->update($data);

        return redirect()->route('owner.worktimes.index')->with('success', 'Termin je uspešno ažuriran.');
    }

    public function swap(Request $request)
    {
        $salon = Auth::user()->ownedSalon;
        // Očekuješ dva ID-ja smena za swap
        $ids = $request->validate([
            
        'first_id'  => [
            'required','integer',
            Rule::exists('work_times','id')->where(function($q) use($salon) {
                // dozvoljava samo work_times čiji employee_id pripada ovom salonu
                $q->whereIn('employee_id', function($q2) use($salon) {
                    $q2->select('id')
                       ->from('employees')
                       ->where('salon_id', $salon->id);
                });
            }),
        ],
        'second_id' => [
            'required','integer',
            Rule::exists('work_times','id')->where(function($q) use($salon) {
                $q->whereIn('employee_id', function($q2) use($salon) {
                    $q2->select('id')
                       ->from('employees')
                       ->where('salon_id', $salon->id);
                });
            }),
        ],
        ]);

        $wtA = WorkTime::findOrFail($ids['first_id']);
        $wtB = WorkTime::findOrFail($ids['second_id']);

        // Podaci posle swap-a
        $dataA = [
            'start_time' => $wtB->start_time,
            'end_time'   => $wtB->end_time,
        ];
        $dataB = [
            'start_time' => $wtA->start_time,
            'end_time'   => $wtA->end_time,
        ];

        // Helper koji vraća true ako postoji zakazana rezervacija van intervala
        $hasConflict = function(array $d, WorkTime $wt) {
            return Appointment::where('employee_id', $wt->employee_id)
                ->where('date', $wt->date)
                ->where(function($q) use($d) {
                    $q->where('start_time', '<',  $d['start_time'])
                    ->orWhere('end_time',   '>',  $d['end_time']);
                })->exists();
        };

        // Prethodno proveri konflikte za obe
        if ($hasConflict($dataA, $wtA) || $hasConflict($dataB, $wtB)) {
            return back()->with('error',
                'Swap nije moguć jer bi jedna od smena izašla van postojećih termina.'
            );
        }

        // Ako je čisto, uradi oba update-a u transakciji
        DB::transaction(function() use ($wtA, $wtB, $dataA, $dataB) {
            $wtA->update($dataA);
            $wtB->update($dataB);
        });

        return back()->with('success', 'Smene uspešno zamenjene.');
    }
    /**
     * DELETE /owner/worktimes/{worktime}
     * Obriši slot ako nema rezervacija u njemu.
     */
    public function destroy($worktime)
    {
        $slot = WorkTime::findOrFail($worktime);
        $exists = Appointment::where('employee_id', $slot->employee_id)
            ->where('date', $slot->date)
            ->whereBetween('start_time', [$slot->start_time, $slot->end_time])
            ->exists();

        if ($exists) {
            return back()->with('error', 'Ne možete obrisati slot jer postoje rezervacije u tom terminu.');
        }

        $slot->delete();

        return redirect()->route('owner.worktimes.index')->with('success', 'Slot je uspešno obrisan.');
    }
}
