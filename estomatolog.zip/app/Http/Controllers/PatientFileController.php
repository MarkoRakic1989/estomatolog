<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PatientFileController extends Controller
{
    //
}
