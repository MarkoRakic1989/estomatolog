<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Salon;
use App\Models\Service;
use Illuminate\Support\Str;
use Inertia\Inertia;

class PublicController extends Controller
{
    /**
     * Prikaz Home stranice za salon pod određenim slugom.
     */
    public function home(Request $request, $salonSlug)
    {
        // 1) Dohvati salon prema slugu, zajedno sa svim uslugama
        $salon = Salon::with('services')
                      ->where('slug', $salonSlug)
                      ->firstOrFail();

        // 2) Pripremi “topServices” (npr. po cijeni ili po nekoj drugoj logici)
        //    Ovdje ćemo jednostavno uzeti prvih 3 iz kolekcije (možete prilagoditi sort())
        $topServices = $salon->services
                             ->take(3)
                             ->map(fn($s) => [
                                 'id'          => $s->id,
                                 'name'        => $s->name,
                                 'price'       => $s->price,
                                 'short_desc'  => Str::limit($s->description, 60),
                                 'duration'    => $s->duration,
                             ])
                             ->values();

        // 3) Pripremi “allServices” (za Services.vue)
        $allServices = $salon->services
                             ->map(fn($s) => [
                                 'id'          => $s->id,
                                 'name'        => $s->name,
                                 'description' => $s->description,
                                 'price'       => $s->price,
                                 'duration'    => $s->duration,
                             ])
                             ->values();

        // 4) Pošalji Inertia odgovor s ispravnim props‐ovima
        return Inertia::render('Public/Home', [
            'salonSlug'    => $salonSlug,
            'salon'        => [
                'id'              => $salon->id,
                'name'            => $salon->name,
                'email'           => $salon->email,
                'phone'           => $salon->phone,
                'logo'            => $salon->logo,
                'primary_color'   => $salon->primary_color,
                'secondary_color' => $salon->secondary_color,
                'description'     => $salon->description,
                'is_active'       => $salon->is_active,
                'paid_until'      => $salon->paid_until,
                'cover'           => $salon->logo,
                // Ako želite imati zaseban “cover” stupac, dodajte ga.
                // Ovdje za demo koristim logo kao cover ili ostavite null.
            ],
            'topServices'  => $topServices,
            'allServices'  => $allServices,
            'currentRoute' => 'public.home',
        ]);
    }

    /**
     * Prikaz stranice “Services” (s popisom svih usluga).
     * Možete koristiti ili sam Home controller (budući da smo poslali allServices),
     * ali za jasniji kod, napravit ćemo zasebnu metodu.
     */
    public function services(Request $request, $salonSlug)
    {
        $salon = Salon::with('services')
                      ->where('slug', $salonSlug)
                      ->firstOrFail();

        $allServices = $salon->services
                             ->map(fn($s) => [
                                 'id'          => $s->id,
                                 'name'        => $s->name,
                                 'description' => $s->description,
                                 'price'       => $s->price,
                                 'duration'    => $s->duration,
                             ])
                             ->values();

        return Inertia::render('Public/Services', [
            'salonSlug'    => $salonSlug,
            'salon'        => [
                'id'              => $salon->id,
                'name'            => $salon->name,
                'email'           => $salon->email,
                'phone'           => $salon->phone,
                'logo'            => $salon->logo,
                'primary_color'   => $salon->primary_color,
                'secondary_color' => $salon->secondary_color,
                'description'     => $salon->description,
                'is_active'       => $salon->is_active,
                'paid_until'      => $salon->paid_until,
                'cover'           => $salon->logo,
            ],
            'services'     => $allServices,
            'currentRoute' => 'public.services',
        ]);
    }

    /**
     * Prikaz “About” stranice.
     */
    public function about(Request $request, $salonSlug)
    {
        $salon = Salon::where('slug', $salonSlug)
                      ->firstOrFail();

        return Inertia::render('Public/About', [
            'salonSlug'    => $salonSlug,
            'salon'        => [
                'id'              => $salon->id,
                'name'            => $salon->name,
                'email'           => $salon->email,
                'phone'           => $salon->phone,
                'logo'            => $salon->logo,
                'primary_color'   => $salon->primary_color,
                'secondary_color' => $salon->secondary_color,
                'description'     => $salon->description,
                'is_active'       => $salon->is_active,
                'paid_until'      => $salon->paid_until,
                'cover'           => $salon->logo,
                'about_html'      => $salon->description, // koristimo isti stupac “description” za “about”
            ],
            'currentRoute' => 'public.about',
        ]);
    }

    /**
     * Prikaz “Contact” stranice (forma).
     */
    public function contact(Request $request, $salonSlug)
    {
        $salon = Salon::where('slug', $salonSlug)
                      ->firstOrFail();

        return Inertia::render('Public/Contact', [
            'salonSlug'    => $salonSlug,
            'salon'        => [
                'id'              => $salon->id,
                'name'            => $salon->name,
                'email'           => $salon->email,
                'phone'           => $salon->phone,
                'logo'            => $salon->logo,
                'primary_color'   => $salon->primary_color,
                'secondary_color' => $salon->secondary_color,
                'description'     => $salon->description,
                'is_active'       => $salon->is_active,
                'paid_until'      => $salon->paid_until,
                'cover'           => $salon->logo,
            ],
            'currentRoute' => 'public.contact',
        ]);
    }
}
