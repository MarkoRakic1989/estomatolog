<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PwaController extends Controller
{
    /**
     * Prikaz offline stranice (kada korisnik nema interneta).
     */
    public function offline()
    {
        return view('offline');
    }

    /**
     * (Opcionalno) Ako želiš dinamički generirati manifest, možeš.
     * Inače, manifest.json i serviceworker.js su u public/ direktoriju.
     */
    public function manifest()
    {
        $manifest = [
            'name' => config('app.name'),
            'short_name' => config('app.name'),
            'start_url' => '/',
            'display' => 'standalone',
            'background_color' => '#ffffff',
            'theme_color' => '#000000',
            'icons' => [
                [
                    'src' => asset('images/pwa/icons/icon-72x72.png'),
                    'sizes' => '72x72',
                    'type' => 'image/png'
                ],
                // ... ostale varijante
            ],
        ];

        return response()->json($manifest);
    }
}
