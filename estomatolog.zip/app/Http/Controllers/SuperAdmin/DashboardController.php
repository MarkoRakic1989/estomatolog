<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\Salon;
use App\Models\User;
use App\Models\Package;
use App\Models\Subscription;
use Carbon\Carbon;
use Inertia\Inertia;

class DashboardController extends Controller
{
    public function index()
    {
        $totalSalons      = Salon::count();
        $totalUsers       = User::count();
        $totalPackages    = Package::count();
        $activeSubs       = Subscription::where('status', 'active')->count();
        $pendingSubs      = Subscription::where('status', 'pending')->count();
        $expiredSubs      = Subscription::where('status', 'expired')->count();
        $revenueThisMonth = Subscription::where('status', 'active')
            ->whereBetween('starts_at', [Carbon::now()->startOfMonth(), Carbon::now()->endOfMonth()])
            ->join('packages', 'subscriptions.package_id', '=', 'packages.id')
            ->sum('packages.price');

        return Inertia::render('SuperAdmin/Dashboard', [
        'totalSalons'      => $totalSalons,
        'totalUsers'       => $totalUsers,
        'totalPackages'    => $totalPackages,
        'activeSubs'       => $activeSubs,
        'pendingSubs'      => $pendingSubs,
        'expiredSubs'      => $expiredSubs,
        'revenueThisMonth' => $revenueThisMonth,
    ]);
    }
}
