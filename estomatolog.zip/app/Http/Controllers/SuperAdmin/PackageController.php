<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\Package;
use Illuminate\Http\Request;
use Inertia\Inertia;

class PackageController extends Controller
{
    /**
     * Display a listing of the packages.
     */
    public function index(Request $request)
    {
        $packages = Package::orderBy('created_at', 'desc')
            ->paginate(15)
            ->through(fn($pkg) => [
                'id'           => $pkg->id,
                'name'         => $pkg->name,
                'price'        => $pkg->price,
                'duration'     => $pkg->duration_months,
                'description'  => $pkg->description,
                'is_active'    => $pkg->is_active,
            ]);

        return Inertia::render('SuperAdmin/Packages/Index', [
            'packages' => $packages,
            'filters'  => $request->only('page'),
            'flash'    => ['success' => session('success')],
        ]);
    }

    /**
     * Show the form for creating a new package.
     */
    public function create()
    {
        return Inertia::render('SuperAdmin/Packages/Create');
    }

    /**
     * Store a newly created package in storage.
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'name'        => 'required|string|max:255',
            'price'       => 'required|numeric|min:0',
            'duration'    => 'required|integer|min:1',
            'description' => 'nullable|string',
            'is_active'   => 'required|boolean',
        ]);

        Package::create([
            'name'            => $data['name'],
            'price'           => $data['price'],
            'duration_months' => $data['duration'],
            'description'     => $data['description'] ?? null,
            'is_active'       => $data['is_active'],
        ]);

        return redirect()
            ->route('superadmin.packages.index')
            ->with('success', 'Paket je uspešno kreiran.');
    }

    /**
     * Show the form for editing the specified package.
     */
    public function edit(Package $package)
    {
        return Inertia::render('SuperAdmin/Packages/Edit', [
            'package' => [
                'id'           => $package->id,
                'name'         => $package->name,
                'price'        => $package->price,
                'duration'     => $package->duration_months,
                'description'  => $package->description,
                'is_active'    => $package->is_active,
            ],
        ]);
    }

    /**
     * Update the specified package in storage.
     */
    public function update(Request $request, Package $package)
    {
        $data = $request->validate([
            'name'        => 'required|string|max:255',
            'price'       => 'required|numeric|min:0',
            'duration'    => 'required|integer|min:1',
            'description' => 'nullable|string',
            'is_active'   => 'required|boolean',
        ]);

        $package->update([
            'name'            => $data['name'],
            'price'           => $data['price'],
            'duration_months' => $data['duration'],
            'description'     => $data['description'] ?? null,
            'is_active'       => $data['is_active'],
        ]);

        return redirect()
            ->route('superadmin.packages.index')
            ->with('success', 'Paket je uspešno ažuriran.');
    }

    /**
     * Remove the specified package from storage.
     */
    public function destroy(Package $package)
    {
        $package->delete();

        return redirect()
            ->route('superadmin.packages.index')
            ->with('success', 'Paket je uspešno obrisan.');
    }
}
