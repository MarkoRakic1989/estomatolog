<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Spatie\Permission\Models\Permission;
use Illuminate\Http\Request;
use Inertia\Inertia;

class PermissionController extends Controller
{
    /**
     * Prikaz paginirane liste permisija preko Inertia.
     */
    public function index(Request $request)
    {
        $permissions = Permission::orderBy('name')
            ->paginate(20)
            ->through(fn($perm) => [
                'id'         => $perm->id,
                'name'       => $perm->name,
                'guard_name' => $perm->guard_name,
            ]);

        return Inertia::render('SuperAdmin/Permissions/Index', [
            'permissions' => $permissions,
            'flash'       => ['success' => session('success')],
        ]);
    }

    /**
     * Forma za kreiranje nove permisije.
     */
    public function create()
    {
        return Inertia::render('SuperAdmin/Permissions/Create');
    }

    /**
     * Čuvanje nove permisije.
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'name'       => 'required|string|unique:permissions,name',
            'guard_name' => 'required|string',
        ]);

        Permission::create($data);

        return redirect()
            ->route('superadmin.permissions.index')
            ->with('success', 'Permisija je kreirana.');
    }

    /**
     * Forma za izmenu postojeće permisije.
     */
    public function edit(Permission $permission)
    {
        return Inertia::render('SuperAdmin/Permissions/Edit', [
            'permission' => [
                'id'         => $permission->id,
                'name'       => $permission->name,
                'guard_name' => $permission->guard_name,
            ],
        ]);
    }

    /**
     * Ažuriranje permisije.
     */
    public function update(Request $request, Permission $permission)
    {
        $data = $request->validate([
            'name'       => "required|string|unique:permissions,name,{$permission->id}",
            'guard_name' => 'required|string',
        ]);

        $permission->update($data);

        return redirect()
            ->route('superadmin.permissions.index')
            ->with('success', 'Permisija je ažurirana.');
    }

    /**
     * Brisanje permisije.
     */
    public function destroy(Permission $permission)
    {
        $permission->delete();

        return redirect()
            ->route('superadmin.permissions.index')
            ->with('success', 'Permisija je obrisana.');
    }
}
