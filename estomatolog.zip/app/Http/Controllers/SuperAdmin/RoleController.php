<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Http\Request;
use Inertia\Inertia;

class RoleController extends Controller
{
    /**
     * Prikaz liste uloga (paginated) preko Inertia.
     */
    public function index(Request $request)
    {
        $roles = Role::with('permissions')
            ->orderBy('name')
            ->paginate(15)
            ->through(fn($role) => [
                'id'          => $role->id,
                'name'        => $role->name,
                'permissions' => $role->permissions->pluck('name')->all(),
            ]);

        return Inertia::render('SuperAdmin/Roles/Index', [
            'roles' => $roles,
            'flash' => ['success' => session('success')],
        ]);
    }

    /**
     * Forma za kreiranje nove uloge.
     */
    public function create()
    {
        $permissions = Permission::orderBy('name')
            ->get(['id','name']);

        return Inertia::render('SuperAdmin/Roles/Create', [
            'permissions' => $permissions,
        ]);
    }

    /**
     * Čuvanje nove uloge.
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'name'        => 'required|string|unique:roles,name',
            'permissions' => 'nullable|array',
            'permissions.*' => 'exists:permissions,name',
        ]);

        $role = Role::create(['name' => $data['name']]);
        $role->syncPermissions($data['permissions'] ?? []);

        return redirect()
            ->route('superadmin.roles.index')
            ->with('success', 'Uloga je kreirana.');
    }

    /**
     * Forma za izmenu postojeće uloge.
     */
    public function edit(Role $role)
    {
        $role->load('permissions');
        $permissions = Permission::orderBy('name')
            ->get(['id','name']);

        return Inertia::render('SuperAdmin/Roles/Edit', [
            'role'        => [
                'id'          => $role->id,
                'name'        => $role->name,
                'permissions' => $role->permissions->pluck('name')->all(),
            ],
            'permissions' => $permissions,
        ]);
    }

    /**
     * Ažuriranje uloge.
     */
    public function update(Request $request, Role $role)
    {
        $data = $request->validate([
            'name'         => "required|string|unique:roles,name,{$role->id}",
            'permissions'  => 'nullable|array',
            'permissions.*'=> 'exists:permissions,name',
        ]);

        $role->update(['name' => $data['name']]);
        $role->syncPermissions($data['permissions'] ?? []);

        return redirect()
            ->route('superadmin.roles.index')
            ->with('success', 'Uloga je ažurirana.');
    }

    /**
     * Brisanje uloge.
     */
    public function destroy(Role $role)
    {
        $role->delete();

        return redirect()
            ->route('superadmin.roles.index')
            ->with('success', 'Uloga je obrisana.');
    }
}
