<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\Salon;
use App\Models\User;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Laravel\Facades\Image;
use Inertia\Inertia;

class SalonController extends Controller
{
    public function index()
    {
        $salons = Salon::with('owner', 'category')
            ->orderBy('created_at', 'desc')
            ->paginate(15)
            ->through(fn($salon) => [
                'id'            => $salon->id,
                'name'          => $salon->name,
                'slug'          => $salon->slug,
                'category'      => [
                    'id'   => $salon->category->id,
                    'name' => $salon->category->name,
                ],
                'owner_email'   => $salon->owner->email,
                'is_active'     => $salon->is_active,
                'paid_until'    => $salon->paid_until?->toDateString(),
            ]);

        return Inertia::render('SuperAdmin/Salons/Index', [
            'salons'  => $salons,
            'filters' => request()->only('search', 'page'),
            'flash'   => ['success' => session('success')],
        ]);
    }

    public function create()
    {
        $categories = Category::select('id','name')->get();

        return Inertia::render('SuperAdmin/Salons/Create', [
            'categories' => $categories,
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'category_id'     => 'required|exists:categories,id',
            'slug'            => 'required|string|unique:salons,slug',
            'theme'           => 'required|string',
            'name'            => 'required|string|max:255',
            'owner_email'     => 'required|email',
            'phone'           => 'nullable|string|max:50',
            'primary_color'   => 'nullable|string|max:7',
            'secondary_color' => 'nullable|string|max:7',
            'description'     => 'nullable|string',
            'is_active'       => 'boolean',
            'paid_until'      => 'nullable|date',
            'dark_mode'       => 'boolean',
            'logo'            => 'nullable|image|max:2048',
            'cover_image'     => 'nullable|image|max:4096',
        ]);
        // 1) Owner user logic
        $user = User::firstWhere('email', $data['owner_email']);
        if (! $user) {
            $user = User::create([
                'name'     => Str::before($data['owner_email'], '@'),
                'email'    => $data['owner_email'],
                'role'    => 'owner',
                'password' => bcrypt(Str::random(12)),
            ]);
            $user->assignRole('owner');
        } elseif (! $user->hasRole('owner')) {
            $user->assignRole('owner');
        }

        // 2) Handle images
        $logoFilename  = null;
        if ($request->hasFile('logo')) {
            $file         = $request->file('logo');
            $ext          = $file->getClientOriginalExtension();
            $base         = 'salon-logo-'.Str::slug($data['name']);
            $ts           = time();
            $logoFilename = "{$base}-{$ts}.{$ext}";

            // default logo 300×300
            $img = Image::read($file)
                        ->cover(300,300)
                        ->encodeByExtension($ext, quality: 90);
            Storage::disk('public')->put("images/logos/{$logoFilename}", (string)$img);

            // mobile logo 100×100
            $imgMobile = Image::read($file)
                              ->cover(100,100)
                              ->encodeByExtension($ext, quality: 90);
            Storage::disk('public')->put("images/logos/mobile/{$logoFilename}", (string)$imgMobile);
        }

        $coverFilename = null;
        if ($request->hasFile('cover_image')) {
            $file          = $request->file('cover_image');
            $ext           = $file->getClientOriginalExtension();
            $base          = 'salon-cover-'.Str::slug($data['name']);
            $ts            = time();
            $coverFilename = "{$base}-{$ts}.{$ext}";

            // default cover 1200×400
            $img = Image::read($file)
                        ->cover(1200,400)
                        ->encodeByExtension($ext, quality: 90);
            Storage::disk('public')->put("images/covers/{$coverFilename}", (string)$img);

            // mobile cover 600×200
            $imgMobile = Image::read($file)
                              ->cover(600,200)
                              ->encodeByExtension($ext, quality: 90);
            Storage::disk('public')->put("images/covers/mobile/{$coverFilename}", (string)$imgMobile);
        }

        // 3) Create Salon
        Salon::create([
            'user_id'        => $user->id,
            'category_id'     => $data['category_id'],
            'slug'            => $data['slug'],
            'theme'           => $data['theme'],
            'name'            => $data['name'],
            'email'            => $data['owner_email'],
            'phone'           => $data['phone'] ?? null,
            'logo'            => $logoFilename,
            'cover_image'     => $coverFilename,
            'primary_color'   => $data['primary_color'] ?? '#FFFFFF',
            'secondary_color' => $data['secondary_color'] ?? '#000000',
            'description'     => $data['description'] ?? null,
            'is_active'       => $data['is_active'] ?? true,
            'paid_until'      => $data['paid_until'] ?? null,
            'dark_mode'       => $data['dark_mode'] ?? false,
        ]);

        return redirect()
            ->route('superadmin.salons.index')
            ->with('success', 'Salon je uspešno kreiran.');
    }

    public function edit(Salon $salon)
    {
        $categories = Category::select('id','name')->get();
        $salon->load(['owner:id,email','category:id,name']);

        return Inertia::render('SuperAdmin/Salons/Edit', [
            'salon'      => $salon,
            'categories' => $categories,
            'flash'      => ['success' => session('success')],
        ]);
    }

    public function update(Request $request, Salon $salon)
    {
        $data = $request->validate([
            'category_id'     => 'required|exists:categories,id',
            'slug'            => "required|string|unique:salons,slug,{$salon->id}",
            'theme'           => 'required|string',
            'name'            => 'required|string|max:255',
            'owner_email'     => 'required|email',
            'phone'           => 'nullable|string|max:50',
            'primary_color'   => 'nullable|string|max:7',
            'secondary_color' => 'nullable|string|max:7',
            'description'     => 'nullable|string',
            'is_active'       => 'boolean',
            'paid_until'      => 'nullable|date',
            'dark_mode'       => 'boolean',
            'logo'            => 'nullable|image|max:2048',
            'cover_image'     => 'nullable|image|max:4096',
        ]);

        // owner logic
        $user = User::firstWhere('email', $data['owner_email']);
        if (! $user) {
            $user = User::create([
                'name'     => Str::before($data['owner_email'], '@'),
                'email'    => $data['owner_email'],
                'role'    => 'owner',
                'password' => bcrypt(Str::random(12)),
            ]);
            $user->assignRole('owner');
        } elseif (! $user->hasRole('owner')) {
            $user->assignRole('owner');
        }

        // image updates
        if ($request->hasFile('logo')) {
            $salon->logo && Storage::disk('public')->delete("images/logos/{$salon->logo}");
            $salon->logo && Storage::disk('public')->delete("images/logos/mobile/{$salon->logo}");

            $file         = $request->file('logo');
            $ext          = $file->getClientOriginalExtension();
            $base         = 'salon-logo-'.Str::slug($data['name']);
            $logoFilename = "{$base}-".time().".{$ext}";

            $img = Image::read($file)->cover(300,300)->encodeByExtension($ext,90);
            Storage::disk('public')->put("images/logos/{$logoFilename}", (string)$img);
            $imgMobile = Image::read($file)->cover(100,100)->encodeByExtension($ext,90);
            Storage::disk('public')->put("images/logos/mobile/{$logoFilename}", (string)$imgMobile);

            $salon->logo = $logoFilename;
        }

        if ($request->hasFile('cover_image')) {
            $salon->cover_image && Storage::disk('public')->delete("images/covers/{$salon->cover_image}");
            $salon->cover_image && Storage::disk('public')->delete("images/covers/mobile/{$salon->cover_image}");

            $file            = $request->file('cover_image');
            $ext             = $file->getClientOriginalExtension();
            $coverFilename   = 'salon-cover-'.Str::slug($data['name']).'-'.time().".{$ext}";

            $img = Image::read($file)->cover(1200,400)->encodeByExtension($ext,90);
            Storage::disk('public')->put("images/covers/{$coverFilename}", (string)$img);
            $imgMobile = Image::read($file)->cover(600,200)->encodeByExtension($ext,90);
            Storage::disk('public')->put("images/covers/mobile/{$coverFilename}", (string)$imgMobile);

            $salon->cover_image = $coverFilename;
        }

        // update salon
        $salon->update([
            'user_id'        => $user->id,
            'category_id'     => $data['category_id'],
            'slug'            => $data['slug'],
            'theme'           => $data['theme'],
            'name'            => $data['name'],
            'phone'           => $data['phone'] ?? null,
            'primary_color'   => $data['primary_color'] ?? $salon->primary_color,
            'secondary_color' => $data['secondary_color'] ?? $salon->secondary_color,
            'description'     => $data['description'] ?? $salon->description,
            'is_active'       => $data['is_active'] ?? $salon->is_active,
            'paid_until'      => $data['paid_until'] ?? $salon->paid_until,
            'dark_mode'       => $data['dark_mode'] ?? $salon->dark_mode,
            'logo'            => $salon->logo,
            'cover_image'     => $salon->cover_image,
        ]);

        return redirect()
            ->route('superadmin.salons.index')
            ->with('success', 'Salon je uspešno ažuriran.');
    }

    public function destroy(Salon $salon)
    {
        // delete images
        $salon->logo && Storage::disk('public')->delete("images/logos/{$salon->logo}");
        $salon->logo && Storage::disk('public')->delete("images/logos/mobile/{$salon->logo}");
        $salon->cover_image && Storage::disk('public')->delete("images/covers/{$salon->cover_image}");
        $salon->cover_image && Storage::disk('public')->delete("images/covers/mobile/{$salon->cover_image}");

        $salon->delete();

        return redirect()
            ->route('superadmin.salons.index')
            ->with('success', 'Salon je obrisan.');
    }
}
