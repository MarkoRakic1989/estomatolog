<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\Subscription;
use App\Models\Salon;
use App\Models\Package;
use App\Models\User;
use Illuminate\Http\Request;
use Inertia\Inertia;

class SubscriptionController extends Controller
{
    /**
     * Prikaz paginiranih pretplata.
     */
    public function index(Request $request)
    {
        $subscriptions = Subscription::with(['salon', 'package', 'user'])
            ->orderBy('created_at', 'desc')
            ->paginate(15)
            ->through(fn($sub) => [
                'id'         => $sub->id,
                'salon'      => ['id' => $sub->salon->id, 'name' => $sub->salon->name],
                'package'    => ['id' => $sub->package->id, 'name' => $sub->package->name],
                'user'       => ['id' => $sub->user->id,   'name' => $sub->user->name],
                'starts_at'  => $sub->starts_at->toDateString(),
                'ends_at'    => $sub->ends_at->toDateString(),
                'status'     => $sub->status,
            ]);

        return Inertia::render('SuperAdmin/Subscriptions/Index', [
            'subscriptions' => $subscriptions,
            'filters'       => $request->only('page'),
            'flash'         => ['success' => session('success')],
        ]);
    }

    public function create()
    {
        $salons   = Salon::select('id','name')->orderBy('name')->get();
        $packages = Package::select('id','name')->orderBy('name')->get();
        $users    = User::select('id','name')->orderBy('name')->get();

        return Inertia::render('SuperAdmin/Subscriptions/Create', [
            'salons'   => $salons,
            'packages' => $packages,
            'users'    => $users,
        ]);
    }

    // Čuvanje nove pretplate
    public function store(Request $request)
    {
        $data = $request->validate([
            'salon_id'   => 'required|exists:salons,id',
            'package_id' => 'required|exists:packages,id',
            'user_id'    => 'required|exists:users,id',
            'starts_at'  => 'required|date',
            'ends_at'    => 'required|date|after_or_equal:starts_at',
            'status'     => 'required|in:pending,active,expired',
        ]);

        Subscription::create($data);

        return redirect()->route('superadmin.subscriptions.index')
                         ->with('success', 'Pretplata je uspešno kreirana.');
    }
    /**
     * Forma za izmenu jedne pretplate.
     */
    public function edit(Subscription $subscription)
    {
        // list of salons/packages/users for selects:
        $salons   = Salon::select('id', 'name')->orderBy('name')->get();
        $packages = Package::select('id', 'name')->orderBy('name')->get();
        $users    = User::select('id', 'name')->orderBy('name')->get();

        // pripremimo payload za edit formu
        $payload = [
            'id'         => $subscription->id,
            'salon'      => ['id' => $subscription->salon_id,  'name' => $subscription->salon->name],
            'package'    => ['id' => $subscription->package_id,'name' => $subscription->package->name],
            'user'       => ['id' => $subscription->user_id,   'name' => $subscription->user->name],
            'starts_at'  => $subscription->starts_at->toDateString(),
            'ends_at'    => $subscription->ends_at->toDateString(),
            'status'     => $subscription->status,
        ];

        return Inertia::render('SuperAdmin/Subscriptions/Edit', [
            'subscription' => $payload,
            'salons'       => $salons,
            'packages'     => $packages,
            'users'        => $users,
        ]);
    }

    /**
     * Ažuriranje pretplate.
     */
    public function update(Request $request, Subscription $subscription)
    {
        $data = $request->validate([
            'salon_id'   => 'required|exists:salons,id',
            'package_id' => 'required|exists:packages,id',
            'user_id'    => 'required|exists:users,id',
            'starts_at'  => 'required|date',
            'ends_at'    => 'required|date|after_or_equal:starts_at',
            'status'     => 'required|in:pending,active,expired',
        ]);

        $subscription->update($data);

        return redirect()
            ->route('superadmin.subscriptions.index')
            ->with('success', 'Pretplata je uspešno ažurirana.');
    }

    /**
     * Brisanje pretplate.
     */
    public function destroy(Subscription $subscription)
    {
        $subscription->delete();

        return redirect()
            ->route('superadmin.subscriptions.index')
            ->with('success', 'Pretplata je uspešno obrisana.');
    }
}
