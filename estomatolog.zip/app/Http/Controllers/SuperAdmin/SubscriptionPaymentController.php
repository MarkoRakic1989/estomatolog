<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\SubscriptionPayment;
use App\Models\Subscription;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SubscriptionPaymentController extends Controller
{
    public function index()
    {
        $payments = SubscriptionPayment::with(['subscription', 'confirmer'])->orderByDesc('created_at')->paginate(30);
        return inertia('SuperAdmin/SubscriptionPayments/Index', ['payments' => $payments]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'subscription_id' => 'required|exists:subscriptions,id',
            'amount' => 'required|numeric',
            'paid_at' => 'required|date',
        ]);
        $payment = SubscriptionPayment::create([
            'subscription_id' => $request->subscription_id,
            'amount' => $request->amount,
            'paid_at' => $request->paid_at,
            'reference_number' => $request->reference_number,
            'status' => 'confirmed',
            'confirmed_by' => Auth::user()->id,
            'note' => $request->note,
        ]);
        // update status subscriptiona:
        $subscription = $payment->subscription;
        $subscription->status = 'active';
        $subscription->starts_at = now();
        $subscription->ends_at = now()->addMonth();
        $subscription->save();

        return redirect()->back()->with('success', 'Uplata uspešno potvrđena i pretplata aktivirana.');
    }
}
