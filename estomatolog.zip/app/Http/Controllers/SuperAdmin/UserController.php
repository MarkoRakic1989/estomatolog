<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Inertia\Inertia;

class UserController extends Controller
{
    /**
     * Prikaz svih korisnika sa statusom (blokirani/neblokirani).
     */
    public function index(Request $request)
    {
        $users = User::with('roles')
            ->orderBy('created_at', 'desc')
            ->paginate(20)
            ->through(fn($user) => [
                'id'         => $user->id,
                'name'       => $user->name,
                'email'      => $user->email,
                'roles'      => $user->roles->pluck('name'),
                'is_blocked' => ! $user->is_active,
            ]);

        return Inertia::render('SuperAdmin/Users/Index', [
            'users'   => $users,
            'filters' => $request->only('search', 'page'),
            'flash'   => [
                'success' => session('success'),
            ],
        ]);
    }

    /**
     * Blokiraj korisnika – postavi is_active = false.
     */
    public function block(User $user)
    {
        $user->update(['is_active' => 0]);

        return redirect()
            ->route('superadmin.users.index')
            ->with('success', "Korisnik {$user->name} je blokiran.");
    }

    /**
     * Otblokiraj korisnika – postavi is_active = true.
     */
    public function unblock(User $user)
    {
        $user->update(['is_active' => 1]);

        return redirect()
            ->route('superadmin.users.index')
            ->with('success', "Korisnik {$user->name} je otblokiran.");
    }
}
