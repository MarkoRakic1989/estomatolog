<?php

namespace App\Http\Controllers\Worker;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

class AppointmentController extends Controller
{
    /**
     * Prikaz svih termina za prijavljenog radnika.
     */
    public function index()
    {
        $workerId = Auth::user()->id; // Assuming auth user is Employee? Ako Employee nema auth, trebamo drugačije
        // Pretpostavka: User model s ulogom 'worker' ima vezu prema Employee, npr. user->employee->id
        $employee = Auth::user()->employee;
        $appointments = Appointment::with('salon','user','services')
                            ->where('employee_id', $employee->id)
                            ->whereIn('status', ['pending','confirmed'])
                            ->orderBy('date','asc')
                            ->paginate(20);

        return Inertia::render('Worker/Appointments/Index', [
            'appointments' => $appointments,
        ]);
    }

    /**
     * Predaj formu za potvrdu/otkazivanje termina (možda modal ili direktna akcija).
     * Ili puedes dopuniti index s akcijama.
     */
    public function edit(Appointment $appointment)
    {
        $employee = Auth::user()->employee;
        if ($appointment->employee_id !== $employee->id) {
            abort(403);
        }

        return Inertia::render('Worker/Appointments/Edit', [
            'appointment' => $appointment->load('salon','user','services'),
        ]);
    }

    /**
     * Ažuriranje statusa termina (npr. potvrdi ili otkaži).
     */
    public function update(Request $request, Appointment $appointment)
    {
        $employee = Auth::user()->employee;
        if ($appointment->employee_id !== $employee->id) {
            abort(403);
        }

        $request->validate([
            'status' => 'required|in:confirmed,cancelled',
        ]);

        $appointment->update([
            'status' => $request->status,
        ]);

        // Pošalji notifikaciju klijentu (po želji)

        return redirect()->route('worker.appointment.index')
                         ->with('success', 'Status termina je ažuriran.');
    }

    /**
     * Ova metoda možda ne treba create/store, jer radnik ne kreira nove termine.
     * Ali može imati destroy za otkaz samog termina, ili to radnik radi samo ako je potrebno.
     */
    public function destroy(Appointment $appointment)
    {
        $employee = Auth::user()->employee;
        if ($appointment->employee_id !== $employee->id) {
            abort(403);
        }

        $appointment->delete();

        return redirect()->route('worker.appointment.index')
                         ->with('success', 'Termin je otkazan i obrisan.');
    }
}
