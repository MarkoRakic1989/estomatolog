<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CheckPackageFeature
{
    /**
     * Handle an incoming request.
     * Provera da li korisnikov salonov paket podržava određenu funkciju.
     * Primeri upotrebe: package:premium, package:files, package:marketing
     */
    public function handle(Request $request, Closure $next, $feature)
    {
        $user = Auth::user();

        // 1. Provera relacije
        if (!$user || !$user->ownedSalon) {
            abort(403, 'Nemate pristup ovoj funkcionalnosti.');
        }

        // 2. Pronađi poslednju aktivnu/pending pretplatu
        $subscription = $user->ownedSalon->subscriptions()
            ->with('package')
            ->whereIn('status', ['active', 'pending'])
            ->where('ends_at', '>=', now())
            ->orderByDesc('ends_at')
            ->orderByDesc('id')
            ->first();

        if (!$subscription || !$subscription->package) {
            abort(403, 'Nemate aktivan paket.');
        }

        $package = $subscription->package;

        // 3. LOGUJ podatke radi dijagnoze!
        \Log::info('PackageMiddleware:', [
            'user' => $user->id,
            'salon_id' => $user->ownedSalon->id,
            'package_id' => $package->id,
            'package_code' => $package->code,
            'route' => $request->route()->getName(),
            'feature' => $feature,
        ]);

        // 4. Provera
        switch ($feature) {
            case 'premium':
                if ($package->code !== 'premium') {
                    abort(403, 'Ova funkcija je dostupna samo u premium paketu.');
                }
                break;
            case 'files':
                if (!in_array($package->code, ['standard', 'premium'])) {
                    abort(403, 'Fajlovi su dostupni samo u standard ili premium paketu.');
                }
                break;
            case 'marketing':
                if ($package->code !== 'premium') {
                    abort(403, 'Marketing je samo u premium paketu.');
                }
                break;
            default:
                abort(403, 'Nepodržana funkcionalnost.');
        }

        return $next($request);
    }
}
