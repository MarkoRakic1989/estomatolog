<?php

namespace App\Http\Middleware;

use Closure;
use App\Models\Salon;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CheckSalonMembership
{
    /**
     * Provjerava da li je prijavljeni korisnik vezan za salon iz URL-a.
     * Ako nije, vraća 403.
     */
    public function handle(Request $request, Closure $next)
    {
        // Ako nema ulogovanog, propuštamo dalje (javne rute)
        if (! Auth::check()) {
            return $next($request);
        }

        $host = $request->getHost();
        $slug = explode('.', $host)[0];
        if ($slug) {
            // prvo dohvati salon
            $salon = Salon::where('slug', $slug)->first();
            $user = Auth::user();
            // zatim provjeri membership
            if (! $salon || ! $user->salons->contains('id', $salon->id)) {
                abort(403, 'Nemate pristup ovom salonu.');
            }
        }

        return $next($request);
    }
}
