<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CheckSubscriptionStatus
{
    public function handle(Request $request, Closure $next)
    {
        $user = Auth::user();

        if (!$user || !$user->ownedSalon) {
            abort(403, 'Nemate aktivan salon.');
        }

        $salon = $user->ownedSalon;

        $subscription = $salon->subscriptions()
            ->whereIn('status', ['active', 'pending'])
            ->where('ends_at', '>=', now())
            ->orderBy('ends_at', 'desc')
            ->first();

        // Ako NEMA važeću pretplatu:
        if (!$subscription) {
            // Dozvoli dashboard i sve subscription rute!
            if ($request->routeIs('owner.dashboard') || $request->routeIs('owner.subscription.*')) {
                // Na dashboard možeš proslediti poruku kroz session/flash:
                $request->session()->flash('error', 'Nemate aktivnu pretplatu! Pristup je ograničen dok ne obnovite paket.');
                return $next($request);
            }
            // Sve ostalo preusmeri na dashboard i prikaži poruku
            return redirect()->route('owner.dashboard')
                ->with('error', 'Nemate aktivnu pretplatu! Pristup je ograničen dok ne obnovite paket.');
        }

        // Ako ima pretplatu, sve normalno
        return $next($request);
    }
}
