<?php
namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;

class StoreAppointmentRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array
    {
        return [
            'service_id'  => 'required|exists:services,id',
            'employee_id' => 'required|exists:employees,id',
            'user_id'     => 'required|exists:users,id',
            'start_time'  => 'required|date',
        ];
    }
}