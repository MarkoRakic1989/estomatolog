<?php
namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;

class UpdateCouponRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array
    {
        $id = $this->route('coupon')->id;
        return [
            'code' => "required|unique:coupons,code,$id",
            'type' => 'required|in:percent,fixed',
            'value' => 'required|numeric',
            'valid_from' => 'nullable|date',
            'valid_until' => 'nullable|date',
            'usage_limit' => 'nullable|integer',
        ];
    }
}