<?php
namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;

class UpdateEmployeeRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array
    {
        $id = $this->route('employee')->id;
        return [
            'name'        => 'required|string|max:255',
            'email'       => "required|email|unique:employees,email,$id",
            'phone'       => 'nullable',
            'service_ids' => 'array',
            'service_ids.*' => 'exists:services,id',
        ];
    }
}