<?php

namespace App\Mail;

use App\Models\User;
use App\Models\Salon;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class AttachedToSalon extends Mailable
{
    use Queueable, SerializesModels;

    public $user;
    public $salon;

    public function __construct(User $user, Salon $salon)
    {
        $this->user  = $user;
        $this->salon = $salon;
    }

    public function build()
    {
        return $this->subject('Povezani ste sa salonom ' . $this->salon->name)
                    ->view('emails.attached_to_salon')
                    ->with([
                        'name'  => $this->user->name,
                        'salon' => $this->salon->name,
                    ]);
    }
}
