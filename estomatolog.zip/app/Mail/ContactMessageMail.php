<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ContactMessageMail extends Mailable
{
    use Queueable, SerializesModels;

    public $data;
    public $salon;

    /**
     * Kreira novu email poruku s podacima i salonom.
     */
    public function __construct(array $data, $salon)
    {
        $this->data  = $data;  // ['name'=>'...', 'email'=>'...', 'message'=>'...']
        $this->salon = $salon; // instanca modela Salon
    }

    /**
     * Sastavlja email (subject i view).
     */
    public function build()
    {
        return $this
            ->subject("New Contact Message from {$this->data['name']}")
            ->view('emails.contact_message')
            ->with([
                'name'    => $this->data['name'],
                'email'   => $this->data['email'],
                'message' => $this->data['message'],
                'salon'   => $this->salon,
            ]);
    }
}
