<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class NewAppointmentMail extends Mailable
{
    use Queueable, SerializesModels;

    // 1) Dodajte deklaraciju svojstva ovdje:
    public $appointment;

    /**
     * Stvara novi e-mail s podacima o rezervaciji.
     */
    public function __construct($appointment)
    {
        // 2) Sada Intelephense prepoznaje da $this->appointment postoji
        $this->appointment = $appointment;
    }

    /**
     * Sastavlja e-mail (view, subject, itd.).
     */
    public function build()
    {
        return $this
            ->subject('Nova rezervacija')
            ->view('emails.new_appointment')
            ->with([
                'appointment' => $this->appointment,
            ]);
    }
}
