<?php

namespace App\Mail;

use App\Models\User;
use App\Models\Salon;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class NewUserOnSalon extends Mailable
{
    use Queueable, SerializesModels;

    public $user;
    public $salon;
    public $password;

    public function __construct(User $user, Salon $salon)
    {
        $this->user   = $user;
        $this->salon  = $salon;
        // pretpostavimo da ste lozinku negde čuvali u $user->plain_password
        $this->password = 'lozinka koju ste kreirali';
    }

    public function build()
    {
        return $this->subject('Dobrodošli u ' . $this->salon->name)
                    ->view('emails.new_user_on_salon')
                    ->with([
                        'name'     => $this->user->name,
                        'email'    => $this->user->email,
                        'password' => $this->password,
                        'salon'    => $this->salon->name,
                    ]);
    }
}
