<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class PromoEmail extends Mailable
{
    use Queueable, SerializesModels;

    public string $subjectText;
    public string $bodyText;

    public function __construct(string $subject, string $body)
    {
        $this->subjectText = $subject;
        $this->bodyText    = $body;
    }

    public function build()
    {
        return $this
            ->subject($this->subjectText)
            ->view('emails.promo')
            ->with(['bodyText' => $this->bodyText]);
    }
}
