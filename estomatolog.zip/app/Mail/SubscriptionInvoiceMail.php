<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class SubscriptionInvoiceMail extends Mailable
{
    use Queueable, SerializesModels;

    public $salon;
    public $package;
    public $subscription;

    public function __construct($salon, $package, $subscription)
    {
        $this->salon = $salon;
        $this->package = $package;
        $this->subscription = $subscription;
    }

    public function build()
    {
        return $this->subject('Vaš račun za pretplatu - ' . $this->package->name)
            ->markdown('emails.subscription_invoice');
    }
}
