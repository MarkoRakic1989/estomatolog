<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Appointment extends Model
{
    use HasFactory;

    protected $fillable = [
        'salon_id',
        'employee_id',
        'user_id',
        'service_id',   // ako čuvaš jednu uslugu direktno u appointments
        'date',
        'start_time',
        'end_time',
        'status',
        'note',
    ];

    /**
     * Jedan Appointment pripada jednoj usluzi.
     */
    public function service()
    {
        return $this->belongsTo(Service::class);
    }

    /**
     * Jedan Appointment pripada jednom zaposlenom.
     */
    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }

    /**
     * Jedan Appointment pripada jednom korisniku.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Ako si ranije koristio pivot appointment_service za više usluga:
     */
    public function services()
    {
        return $this->belongsToMany(Service::class, 'appointment_service')
                    ->withTimestamps();
    }
     public function salon()
    {
        return $this->belongsTo(Salon::class);
    }

    /**
     * Helper: izračunava ukupan trajanje svih povezanih usluga (u minutama).
     * Koristi se kod validacije slobodnih termina i prilikom spremanja 'end_time'.
     *
     * @return int
     */
    public function totalDuration(): int
    {
        // Zbraja polje duration u povezanim uslugama
        return $this->services()->sum('duration');
    }
    protected static function booted()
    {
        static::updated(function ($appt) {
            if ($appt->status === 'finished') {
                //event(new AppointmentCompleted($appt));
            }
        });
    }
    public function reports() {
        return $this->hasMany(Report::class);
    }
}
