<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    /**
     * Polja koja se mogu masovno dodjeljivati.
     * - name: naziv kategorije
     * - icon: ikona ili klasa
     * - default_color: fallback boja za nove salone
     */
    protected $fillable = [
        'name',
        'icon',
        'default_color',
    ];

    /**
     * Relacija: jedna kategorija može imati više salona.
     */
    public function salons()
    {
        return $this->hasMany(Salon::class);
    }
}
