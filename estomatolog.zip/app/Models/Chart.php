<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Chart extends Model
{
    protected $fillable = [
        'user_id',
        'salon_id',
        'opened_at',
        'doctor_note',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function salon()
    {
        return $this->belongsTo(Salon::class);
    }

    public function toothStatuses()
    {
        return $this->hasMany(ToothStatus::class);
    }

    public function interventions()
    {
        return $this->hasMany(Intervention::class);
    }

    public function diagnoses()
    {
        return $this->hasMany(Diagnosis::class);
    }

    public function documents()
    {
        return $this->hasMany(Document::class);
    }
}
