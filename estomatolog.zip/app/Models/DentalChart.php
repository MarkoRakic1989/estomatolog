<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DentalChart extends Model
{
    protected $fillable = ['user_id', 'salon_id', 'opened_at', 'doctor_note','chronic_diseases','smoker','alcohol','anticoagulant_therapy',
                'infectious_diseases',
                'malignant_diseases',
                'regular_therapy',
                'cardiovascular_diseases',
                'other_notes',];

    public function user()           { return $this->belongsTo(User::class); }
    public function salon()          { return $this->belongsTo(Salon::class); }
    public function toothStatuses()  { return $this->hasMany(DentalChartToothStatus::class); }
    public function interventions()  { return $this->hasMany(DentalChartIntervention::class); }
    public function diagnoses()      { return $this->hasMany(DentalChartDiagnosis::class); }
    public function documents()      { return $this->hasMany(DentalChartDocument::class, 'dental_chart_id'); }
    public function therapies()      { return $this->hasMany(DentalChartTherapy::class); }
    public function materials()      { return $this->hasMany(DentalChartMaterial::class); }
    public function histories()      { return $this->hasMany(DentalChartHistory::class); }
}
