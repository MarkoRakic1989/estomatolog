<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DentalChartDiagnosis extends Model
{
    protected $fillable = [
        'dental_chart_id', 'diagnosis_type_id', 'description', 'color', 'diagnosed_at'
    ];

    public function dentalChart()    { return $this->belongsTo(DentalChart::class); }
    public function diagnosisType()  { return $this->belongsTo(DiagnosisType::class); }
}
