<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DentalChartDocument extends Model
{
    protected $fillable = [
        'dental_chart_id', 'tooth_id', 'intervention_id', 'type', 'file', 'title', 'note'
    ];

    public function dentalChart()    { return $this->belongsTo(DentalChart::class, 'dental_chart_id'); }
    public function tooth()          { return $this->belongsTo(Tooth::class); }
    public function intervention()   { return $this->belongsTo(DentalChartIntervention::class); }
}
