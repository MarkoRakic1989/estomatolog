<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DentalChartHistory extends Model
{
    protected $fillable = [
        'dental_chart_id', 'type', 'description', 'recorded_at'
    ];

    public function dentalChart() { return $this->belongsTo(DentalChart::class); }
}
