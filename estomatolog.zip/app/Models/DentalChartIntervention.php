<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DentalChartIntervention extends Model
{
    protected $fillable = [
        'dental_chart_id', 'tooth_id', 'surface', 'doctor_id', 'type', 'description', 'performed_at', 'status'
    ];

    public function dentalChart() { return $this->belongsTo(DentalChart::class); }
    public function tooth()       { return $this->belongsTo(Tooth::class); }
    public function doctor()      { return $this->belongsTo(User::class, 'doctor_id'); }
    public function documents()   { return $this->hasMany(DentalChartDocument::class, 'intervention_id'); }
}
