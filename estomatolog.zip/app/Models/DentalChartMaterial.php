<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DentalChartMaterial extends Model
{
    protected $fillable = [
        'dental_chart_id', 'material_type_id', 'quantity', 'unit', 'used_at'
    ];

    public function dentalChart()   { return $this->belongsTo(DentalChart::class); }
    public function materialType()  { return $this->belongsTo(MaterialType::class); }
}
