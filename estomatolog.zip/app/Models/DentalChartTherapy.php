<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DentalChartTherapy extends Model
{
    protected $fillable = [
        'dental_chart_id', 'therapy_type_id', 'doctor_id', 'applied_at', 'note'
    ];

    public function dentalChart()  { return $this->belongsTo(DentalChart::class); }
    public function therapyType()  { return $this->belongsTo(TherapyType::class); }
    public function doctor()       { return $this->belongsTo(User::class, 'doctor_id'); }
}
