<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DentalChartToothStatus extends Model
{
    protected $fillable = [
        'dental_chart_id', 'tooth_id', 'surface', 'status', 'color', 'note', 'status_date'
    ];

    public function dentalChart() { return $this->belongsTo(DentalChart::class); }
    public function tooth()       { return $this->belongsTo(Tooth::class); }
}
