<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DiagnosisType extends Model
{
    protected $fillable = ['name', 'code', 'description'];

    public function chartDiagnoses() { return $this->hasMany(DentalChartDiagnosis::class); }
}
