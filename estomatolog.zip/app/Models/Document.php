<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Document extends Model
{
    protected $fillable = [
        'chart_id',
        'tooth_id',
        'intervention_id',
        'type',
        'file',
        'title',
        'note',
    ];

    public function chart()
    {
        return $this->belongsTo(Chart::class);
    }

    public function tooth()
    {
        return $this->belongsTo(Teeth::class);
    }

    public function intervention()
    {
        return $this->belongsTo(Intervention::class);
    }
}
