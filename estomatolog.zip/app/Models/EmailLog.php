<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmailLog extends Model
{
    use HasFactory;

    /**
     * Polja koja se mogu masovno upisivati:
     * - recipient: email adresa primaoca
     * - subject: naslov poruke
     * - body: sadržaj poruke (plain text ili HTML)
     */
    protected $fillable = [
        'recipient',
        'subject',
        'body',
    ];
}
