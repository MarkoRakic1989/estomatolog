<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    use HasFactory;

    /**
     * Polja koja se mogu masovno upisivati:
     * - salon_id: ID salona kojem radnik pripada
     * - name: ime radnika
     * - email: adresa elektroničke pošte radnika
     * - phone: broj telefona (opcionalno)
     * - photo: putanja do fotografije zaposlenog (opcionalno)
     */
    protected $fillable = [
        'salon_id',
        'name',
        'email',
        'phone',
        'photo',
        'user_id',
    ];

    /**
     * Relacija: zaposlenik pripada jednom salonu.
     */
    public function salon()
    {
        return $this->belongsTo(Salon::class);
    }

    /**
     * Relacija: zaposlenik može raditi više usluga (pivot table employee_service).
     */
    public function services()
    {
        return $this->belongsToMany(Service::class, 'employee_service')
                    ->withTimestamps();
    }

    /**
     * Relacija: zaposlenik može imati više rezervacija.
     */
    public function appointments()
    {
        return $this->hasMany(Appointment::class);
    }
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Relacija: zaposlenik može imati različita radna vremena (po datumima).
     */
    public function workTimes()
    {
        return $this->hasMany(WorkTime::class);
    }
}
