<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Estimate extends Model
{
    protected $fillable = [
        'user_id', 'dental_chart_id', 'estimate_date', 'total', 'status'
    ];

    public function user()        { return $this->belongsTo(User::class); }
    public function dentalChart() { return $this->belongsTo(DentalChart::class); }
    public function items()       { return $this->hasMany(EstimateItem::class); }
    public function invoices()    { return $this->hasMany(Invoice::class); }
}
