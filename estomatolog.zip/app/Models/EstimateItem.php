<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EstimateItem extends Model
{
    protected $fillable = [
        'estimate_id', 'service_id', 'tooth_id', 'description', 'quantity', 'unit_price', 'total'
    ];
    public function estimate() { return $this->belongsTo(Estimate::class); }
    public function service()  { return $this->belongsTo(Service::class); }
    public function tooth()    { return $this->belongsTo(Tooth::class); }
}
