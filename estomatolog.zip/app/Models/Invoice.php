<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
    protected $fillable = [
        'user_id', 'dental_chart_id', 'invoice_date', 'total', 'status', 'estimate_id'
    ];
    public function user()        { return $this->belongsTo(User::class); }
    public function dentalChart() { return $this->belongsTo(DentalChart::class); }
    public function estimate()    { return $this->belongsTo(Estimate::class); }
    public function items()       { return $this->hasMany(InvoiceItem::class); }
    public function payments()    { return $this->hasMany(Payment::class); }
    public function debts()       { return $this->hasMany(Debt::class); }
    public function discounts()   { return $this->hasMany(Discount::class); }
}
