<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
class InvoiceItem extends Model
{
    protected $fillable = [
        'invoice_id', 'service_id', 'tooth_id', 'description', 'quantity', 'unit_price', 'total'
    ];
    public function invoice() { return $this->belongsTo(Invoice::class); }
    public function service() { return $this->belongsTo(Service::class); }
    public function tooth()   { return $this->belongsTo(Tooth::class); }
}
