<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MaterialType extends Model
{
    protected $fillable = ['name', 'unit', 'description'];

    public function chartMaterials() { return $this->hasMany(DentalChartMaterial::class); }
}
