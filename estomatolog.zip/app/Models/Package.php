<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
class Package extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'code',
        'price',
        'duration_months',
        'description',
        'is_active',
    ];

    /**
     * Pretplate koje koriste ovaj paket.
     */
    public function subscriptions()
    {
        return $this->hasMany(Subscription::class);
    }

    // Automatski generiši code iz imena
    public function setNameAttribute($value)
    {
        $this->attributes['name'] = $value;
        // Generiši slug/code svaki put kada se menja ime
        $this->attributes['code'] = Str::slug($value);
    }
}
