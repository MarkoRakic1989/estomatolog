<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Page extends Model
{
    use HasFactory;
    protected $fillable = ['salon_id', 'title', 'slug', 'content',];
    public function salon()
{
    return $this->belongsTo(Salon::class);
}
}