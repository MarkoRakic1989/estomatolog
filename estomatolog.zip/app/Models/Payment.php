<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    protected $fillable = [
        'invoice_id', 'amount', 'paid_at', 'method', 'reference', 'status'
    ];
    public function invoice() { return $this->belongsTo(Invoice::class); }
}
