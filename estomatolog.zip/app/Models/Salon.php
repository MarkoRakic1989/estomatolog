<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Salon extends Model
{
    use HasFactory;

    /**
     * Polja koja se mogu masovno upisivati:
     * - user_id: vlasnik salona (ID iz tabele users)
     * - category_id: katergija salona (ID iz tabele categories)
     * - slug: jedinstveni string za URL
     * - name: naziv salona
     * - logo: putanja do logotipa
     * - primary_color: primarna boja brenda salona
     * - secondary_color: sekundarna boja
     * - description: javni opis salona
     * - is_active: da li je salon aktivan (npr. nakon naplate)
     */
    protected $fillable = [
        'user_id',
        'category_id',
        'slug',
        'name',
        'email',
        'phone',
        'logo',
        'primary_color',
        'secondary_color',
        'description',
        'is_active',
        'dark_mode',
        'cover_image',
        'theme',
    ];

    /**
     * Relacija: salon pripada jednoj kategoriji.
     */
    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    /**
     * Relacija: salon pripada jednom vlasniku (User).
     * U tablici users pretpostavljamo da vlasnik ima ulogu 'owner'.
     */
    public function owner()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * Relacija: salon može imati više usluga.
     */

    public function services()
    {
        return $this->hasMany(Service::class);
    }
    public function serviceCategories()
    {
        return $this->hasMany(ServiceCategory::class);
    }

    /**
     * Relacija: salon može imati više zaposlenih.
     */
    public function employees()
    {
        return $this->hasMany(Employee::class);
    }
    public function users()
    {
        return $this->belongsToMany(User::class)->withTimestamps();
    }

    /**
     * Relacija: salon može imati više galerijskih slika (ako uvedemo Gallery model).
     * Ne radimo u ovoj fazi, ali može se proširiti.
     */
    // public function galleries()
    // {
    //     return $this->hasMany(Gallery::class);
    // }

    /**
     * Relacija: salon može imati više rezervacija (kroz zaposlene).
     */
    public function appointments()
    {
        return $this->hasMany(Appointment::class);
    }
    public function expenses()
    {
        return $this->hasMany(Expense::class);
    }

    public function patientFiles()
    {
        return $this->hasMany(PatientFile::class);
    }
    public function subscriptions()
    {
        return $this->hasMany(\App\Models\Subscription::class);
    }
    public function charts() { return $this->hasMany(Chart::class); }
}
