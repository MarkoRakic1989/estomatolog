<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Service extends Model
{
    use HasFactory;

    /**
     * Polja koja se mogu masovno upisivati:
     * - salon_id: id salona kojem usluga pripada
     * - name: naziv usluge
     * - duration: trajanje usluge u minutama
     * - price: cijena usluge
     * - description: detaljni opis usluge
     * - capacity: kolika je maksimalna istovremena popunjenost
     */
    protected $fillable = [
        'salon_id',
        'name',
        'duration',
        'slug',
        'price',
        'description',
        'capacity',
        'icon',
        'self_bookable',  // <— novo polje
    ];

    /**
     * Automatically generate/update slug on create & update.
     */
    protected static function booted()
    {
        static::creating(function ($svc) {
            if (! $svc->slug) {
                $svc->slug = static::generateUniqueSlug($svc->name, $svc->salon_id);
            }
        });

        static::updating(function ($svc) {
            if ($svc->isDirty('name')) {
                $svc->slug = static::generateUniqueSlug(
                    $svc->name,
                    $svc->salon_id,
                    $svc->id
                );
            }
        });
    }

    /**
     * Build a slug from the given name, scoped to salon_id, avoiding collisions.
     *
     * @param  string     $name
     * @param  int        $salonId
     * @param  int|null   $ignoreId
     * @return string
     */
    protected static function generateUniqueSlug(string $name, int $salonId, int $ignoreId = null): string
    {
        $base = Str::slug($name);
        $slug = $base;
        $i = 1;

        while (static::where('salon_id', $salonId)
                     ->when($ignoreId, fn($q) => $q->where('id', '!=', $ignoreId))
                     ->where('slug', $slug)
                     ->exists()
        ) {
            $slug = "{$base}-{$i}";
            $i++;
        }

        return $slug;
    }
    /**
     * Relacija: usluga pripada jednom salonu.
     */
    public function salon()
    {
        return $this->belongsTo(Salon::class);
    }

    /**
     * Relacija: usluga se može naći u više rezervacija (pivot).
     */
    public function appointments()
    {
        return $this->belongsToMany(Appointment::class)
                    ->withTimestamps();
    }

    /**
     * Relacija: usluga može biti pružana od strane više zaposlenih (pivot employee_service).
     */
    public function employees()
    {
        return $this->belongsToMany(Employee::class, 'employee_service')
                    ->withTimestamps();
    }
    public function stockItems()
    {
        return $this->belongsToMany(StockItem::class, 'service_stock_item')
                    ->withPivot('quantity');
    }
    public function serviceCategories(): \Illuminate\Database\Eloquent\Relations\BelongsToMany
    {
        return $this->belongsToMany(\App\Models\ServiceCategory::class, 'service_category_service');
    }
    public function materials()
    {
        return $this->hasMany(ServiceMaterial::class);
    }
}
