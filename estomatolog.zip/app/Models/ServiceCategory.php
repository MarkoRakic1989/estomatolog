<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Support\Str;

class ServiceCategory extends Model
{
   
    protected $fillable = [
      'name',
      'salon_id',
      'parent_id',
      'image',
      'slug',
    ];

    // Generišemo slug pre čuvanja (ako nije ručno postavljen)
    protected static function booted()
    {
        static::creating(function ($cat) {
            if (! $cat->slug) {
                $cat->slug = static::generateUniqueSlug($cat->name, $cat->salon_id);
            }
        });
        static::updating(function ($cat) {
            // ako je ime promenjeno, regenerišemo slug
            if ($cat->isDirty('name')) {
                $cat->slug = static::generateUniqueSlug($cat->name, $cat->salon_id, $cat->id);
            }
        });
    }

    protected static function generateUniqueSlug($name, $salonId, $ignoreId = null)
    {
        $base = Str::slug($name);
        $slug = $base;
        $i = 1;

        while (static::where('salon_id', $salonId)
                     ->when($ignoreId, fn($q) => $q->where('id', '!=', $ignoreId))
                     ->where('slug', $slug)
                     ->exists()
        ) {
            $slug = $base . '-' . $i++;
        }

        return $slug;
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(ServiceCategory::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(ServiceCategory::class, 'parent_id');
    }

    // Veza prema uslugama (pivot service_category_service)
    public function services()
    {
        return $this->belongsToMany(
            Service::class,
            'service_category_service',
            'service_category_id',
            'service_id'
        )->orderBy('name');
    }
    
    // veza na salon
    public function salon()
    {
        return $this->belongsTo(Salon::class);
    }
}
