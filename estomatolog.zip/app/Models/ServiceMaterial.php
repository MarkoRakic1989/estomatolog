<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
class ServiceMaterial extends Model
{
    protected $fillable = [
        'service_id', 'stock_item_id', 'quantity'
    ];
    public function service()   { return $this->belongsTo(Service::class); }
    public function stockItem() { return $this->belongsTo(StockItem::class); }
}
