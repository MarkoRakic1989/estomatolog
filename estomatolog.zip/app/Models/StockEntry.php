<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StockEntry extends Model
{
    protected $fillable = [
        'supplier_id', 'entry_date', 'type'
    ];
    public function supplier()   { return $this->belongsTo(Supplier::class); }
    public function items()      { return $this->hasMany(StockEntryItem::class); }
}
