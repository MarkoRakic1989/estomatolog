<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
class StockItem extends Model
{
    protected $fillable = [
        'name', 'unit', 'quantity', 'min_quantity', 'unit_price', 'last_restocked_at'
    ];
    public function entryItems()       { return $this->hasMany(StockEntryItem::class); }
    public function serviceMaterials() { return $this->hasMany(ServiceMaterial::class); }
}
