<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Subscription extends Model
{
    use HasFactory;

    protected $fillable = [
        'salon_id',
        'package_id',
        'user_id',
        'starts_at',
        'ends_at',
        'status',
        'price',
    ];

    /**
     * Cast polja u odgovarajuće tipove.
     */
    protected $casts = [
        'starts_at' => 'datetime',
        'ends_at'   => 'datetime',
    ];

    public function salon()
    {
        return $this->belongsTo(Salon::class);
    }

    public function package()
    {
        return $this->belongsTo(Package::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function payments() {
        return $this->hasMany(\App\Models\SubscriptionPayment::class);
    }
}
