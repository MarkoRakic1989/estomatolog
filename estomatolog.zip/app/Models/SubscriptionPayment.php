<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubscriptionPayment extends Model
{
    protected $fillable = [
        'subscription_id', 'amount', 'paid_at', 'reference_number',
        'status', 'confirmed_by', 'note'
    ];

    public function subscription()
    {
        return $this->belongsTo(Subscription::class);
    }

    public function confirmer()
    {
        return $this->belongsTo(User::class, 'confirmed_by');
    }
}
