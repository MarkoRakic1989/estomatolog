<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Tooth extends Model
{
    protected $fillable = ['code', 'type', 'position', 'name'];

    public function statuses()      { return $this->hasMany(DentalChartToothStatus::class); }
    public function interventions() { return $this->hasMany(DentalChartIntervention::class); }
    public function documents()     { return $this->hasMany(DentalChartDocument::class); }
}
