<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use HasFactory, Notifiable, HasRoles;

    // Dodajemo 'role' u $fillable
    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'phone',
        'is_active',
        'date_of_birth', 'allergies', 'medical_notes',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    /**
     * Relacija: ako je korisnik u ulozi 'owner', povezujemo ga s jednim salonom.
     */
    public function salons()
    {
        return $this->belongsToMany(Salon::class)->withTimestamps();
    }

    // nakon migracije dolje možeš dodati:
    public function employee()
    {
        return $this->hasOne(Employee::class);
    }
    public function ownedSalon()
    {
        return $this->hasOne(Salon::class, 'user_id');
    }
    /**
     * Relacija: klijent ima više rezervacija.
     */
    public function appointments()
    {
        return $this->hasMany(Appointment::class);
    }
    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function toothReports()
    {
        return $this->hasMany(ToothReport::class);
    }
    /**
     * Helper metoda: provjerava trenutnu ulogu.
     */
    public function isRole(string $role): bool
    {
        return $this->role === $role;
    }
    public function files()
    {
        return $this->hasMany(PatientFile::class);
    }
    public function charts() { return $this->hasMany(Chart::class); }
}
