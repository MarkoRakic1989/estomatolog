<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Warranty extends Model
{
    protected $fillable = [
        'asset_id', 'start_date', 'end_date', 'provider', 'notes'
    ];
    public function asset() { return $this->belongsTo(Asset::class); }
}
