<?php
namespace App\Policies;
use App\Models\User;
use App\Models\Appointment;
use Illuminate\Auth\Access\HandlesAuthorization;

class AppointmentPolicy
{
    use HandlesAuthorization;
    public function before(User $user) { return $user->role==='owner'; }
    public function viewAny(User $user) { return true; }
    public function confirm(User $user, Appointment $appt){ return $user->salon_id=== $appt->salon_id; }
    public function cancel(User $user, Appointment $appt){ return $user->salon_id=== $appt->salon_id; }
    public function create(User $user){ return true; }
}