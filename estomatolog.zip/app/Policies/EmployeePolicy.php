<?php
namespace App\Policies;
use App\Models\User;
use App\Models\Employee;
use Illuminate\Auth\Access\HandlesAuthorization;

class EmployeePolicy
{
    use HandlesAuthorization;
    public function before(User $user) { return $user->role==='owner'; }
    public function viewAny(User $user) { return true; }
    public function create(User $user) { return true; }
    public function update(User $user, Employee $e){ return $user->salon_id=== $e->salon_id; }
    public function delete(User $user, Employee $e){ return $user->salon_id=== $e->salon_id; }
}