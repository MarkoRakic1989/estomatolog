<?php
namespace App\Policies;
use App\Models\User;
use App\Models\Gallery;
use Illuminate\Auth\Access\HandlesAuthorization;

class GalleryPolicy
{
    use HandlesAuthorization;
    public function before(User $user) {
        return $user->role === 'owner';
    }
    public function viewAny(User $user) { return true; }
    public function view(User $user, Gallery $gal) { return true; }
    public function create(User $user) { return true; }
    public function update(User $user, Gallery $gal) { return true; }
    public function delete(User $user, Gallery $gal) { return true; }
}