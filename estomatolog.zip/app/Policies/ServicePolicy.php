<?php

namespace App\Policies;

use App\Models\Service;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class ServicePolicy
{
    use HandlesAuthorization;

    /**
     * Odmah dozvoli superadminu.
     */
    public function before(User $user, $ability)
    {
        if ($user->role === 'superadmin') {
            return true;
        }
    }

    /**
     * Odredi može li vlasnik salona uređivati uslugu.
     */
    public function update(User $user, Service $service)
    {
        // Vlasnik usluge je onaj koji posjeduje salon
        return $user->role === 'owner'
            && $user->ownedSalon
            && $service->salon_id === $user->ownedSalon->id;
    }

    public function delete(User $user, Service $service)
    {
        return $this->update($user, $service);
    }

    // Implementiraj i ostale metode prema potrebi...
}
