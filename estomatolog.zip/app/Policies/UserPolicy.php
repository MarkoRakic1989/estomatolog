<?php
namespace App\Policies;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class UserPolicy
{
    use HandlesAuthorization;
    public function before(User $user) { return $user->role==='owner'; }
    public function viewAny(User $user) { return true; }
    public function block(User $user, User $target){ return $user->salon_id === $target->salon_id; }
}