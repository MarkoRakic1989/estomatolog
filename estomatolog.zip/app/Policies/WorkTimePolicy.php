<?php
namespace App\Policies;
use App\Models\User;
use App\Models\WorkTime;
use Illuminate\Auth\Access\HandlesAuthorization;

class WorkTimePolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user) {
        return $user->role === 'owner';
    }
    public function view(User $user, WorkTime $wt) {
        return $user->role === 'owner' && $user->salon_id === $wt->employee->salon_id;
    }
    public function create(User $user) {
        return $user->role === 'owner';
    }
    public function update(User $user, WorkTime $wt) {
        return $this->view($user,$wt);
    }
    public function delete(User $user, WorkTime $wt) {
        return $this->view($user,$wt);
    }
}