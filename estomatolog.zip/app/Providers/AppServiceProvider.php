<?php

namespace App\Providers;

use App\Models\Salon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Vite;
use Illuminate\Support\ServiceProvider;
use Inertia\Inertia;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {

        Vite::prefetch(concurrency: 3);

        Inertia::share([
            'auth' => fn() => Auth::check()
                ? [
                    'id'    => Auth::id(),
                    'name'  => Auth::user()->name,
                    'email' => Auth::user()->email,
                    'roles' => Auth::user()->getRoleNames()->toArray(),
                  ]
                : null,

            // 2) Враћајмо ПРАВИ array, не Collection
            'permissions' => fn() => Auth::check()
                // getAllPermissions() учитава stvarne Permission modele
                ? Auth::user()
                    ->getAllPermissions()
                    ->pluck('name')
                    ->toArray()
                : [],

            // Izvlacenje teme iz Salona na osnovu slug-a iz URL-a
            'theme' => function () {
                // Pokušavamo da dohvatimo parametar 'salonSlug' iz trenutne rute
                $slug = request()->route('salonSlug');

                if (! $slug) {
                    // fallback: ako koristite imenovani parametar 'slug'
                    $slug = request()->route('slug');
                }

                if ($slug) {
                    $salon = Salon::where('slug', $slug)->first();
                    return $salon ? $salon->theme : null;
                }

                return null;
            },

            'package_code' => function () {
                $user = Auth::user();
                if (!$user || !$user->ownedSalon) return null;
                $sub = $user->ownedSalon->subscriptions()
                    ->with('package')
                    ->whereIn('status', ['active', 'pending'])
                    ->where('ends_at', '>=', now())
                    ->orderByDesc('ends_at')
                    ->orderByDesc('id')
                    ->first();
                return $sub?->package?->code ?? null;
            }
        ]);
    }
}
