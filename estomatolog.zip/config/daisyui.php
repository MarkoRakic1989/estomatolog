<?php

return [
    'themes' => [
  "light", "dark", "black"
],
];
