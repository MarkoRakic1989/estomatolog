<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Pokreće migraciju za kreiranje tabele 'categories'.
     * Svaka kategorija predstavlja tip biznisa (npr. frizerski salon, fitness itd.).
     */
    public function up(): void
    {
        Schema::create('categories', function (Blueprint $table) {
            $table->id(); // BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY
            $table->string('name')->unique(); // Naziv kategorije, npr. "Frizerski salon"
            $table->string('icon')->nullable(); // Putanja ili naziv ikone (SVG, FontAwesome klasa itd.)
            $table->string('default_color', 7)->default('#000000');
            // Hex boja (šest znamenki + '#'), npr. "#FF5733" za početni predložak boje
            $table->timestamps(); // created_at, updated_at
        });
    }

    /**
     * Briše tabelu 'categories' ukoliko migracija bude vraćena unazad.
     */
    public function down(): void
    {
        Schema::dropIfExists('categories');
    }
};
