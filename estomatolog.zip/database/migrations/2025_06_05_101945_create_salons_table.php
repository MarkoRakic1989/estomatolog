<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Kreira tabelu 'salons', glavni entitet za svaki registrovani biznis.
     */
    public function up(): void
    {
        Schema::create('salons', function (Blueprint $table) {
            $table->id();
            // Vlasnik salona (user koji je kreirao biznis)
            $table->foreignId('user_id')
                  ->constrained('users')
                  ->cascadeOnDelete();
            // Kategorija biznisa (veza prema tabeli 'categories')
            $table->foreignId('category_id')
                  ->constrained('categories')
                  ->cascadeOnDelete();
            $table->string('slug')->unique();
            // Slug će se koristiti za URL tipa salon1.tvoj-sajt.com ili /salon/{slug}
            $table->string('name'); // Ime salona, npr. "Salon Lepote Ana"
            $table->string('logo')->nullable();
            // Putanja (npr. 'logos/ana.png') ili null ako još nema logotip
            $table->string('primary_color', 7)->default('#FFFFFF');
            // Primarna boja brenda salona
            $table->string('secondary_color', 7)->default('#000000');
            // Sekundarna boja, npr. za hover, linkove itd.
            $table->text('description')->nullable();
            // Kratak opis salona (javni opis)
            $table->boolean('is_active')->default(true);
            // Da li je salon aktivan ili blokiran/neaktivan
            $table->timestamps();
        });
    }

    /**
     * Briše tabelu 'salons'.
     */
    public function down(): void
    {
        Schema::dropIfExists('salons');
    }
};
