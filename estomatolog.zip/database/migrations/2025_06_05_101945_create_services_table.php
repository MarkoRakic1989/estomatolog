<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Kreira tabelu 'services' – sve usluge koje salon nudi.
     */
    public function up(): void
    {
        Schema::create('services', function (Blueprint $table) {
            $table->id();
            // Veza prema salonu koji pruža ovu uslugu
            $table->foreignId('salon_id')
                  ->constrained('salons')
                  ->cascadeOnDelete();
            $table->string('name');
            // Naziv usluge, npr. "Šišanje", "Masaža leđa"
            $table->integer('duration');
            // Trajanje usluge u minutima (npr. 30, 60, 90)
            $table->decimal('price', 8, 2);
            // Cijena usluge (npr. 25.00)
            $table->text('description')->nullable();
            // Opis usluge, može biti detaljniji od imena
            $table->integer('capacity')->default(1);
            // Koliko klijenata može istovremeno (npr. masaža stolica - 2)
            $table->timestamps();
        });
    }

    /**
     * Briše tabelu 'services'.
     */
    public function down(): void
    {
        Schema::dropIfExists('services');
    }
};
