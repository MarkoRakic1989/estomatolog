<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Kreira tabelu 'employees' – popis zaposlenih (radnika) unutar svakog salona.
     * Svaki zaposlenik pripada jednom salonu i može raditi više usluga.
     */
    public function up(): void
    {
        Schema::create('employees', function (Blueprint $table) {
            $table->id();
            // Veza prema salonu
            $table->foreignId('salon_id')
                  ->constrained('salons')
                  ->cascadeOnDelete();
            $table->string('name');
            // Ime zaposlenog, npr. "Ana Petrović"
            $table->string('email')->unique();
            // Email zaposlenog – koristi se za slanje notifikacija
            $table->string('phone')->nullable();
            // Telefonski broj zaposlenog (opcionalno)
            $table->string('photo')->nullable();
            // Putanja do slike zaposlenog (npr. 'employees/ana.jpg')
            $table->timestamps();
        });
    }

    /**
     * Briše tabelu 'employees'.
     */
    public function down(): void
    {
        Schema::dropIfExists('employees');
    }
};
