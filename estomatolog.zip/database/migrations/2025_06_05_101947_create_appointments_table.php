<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Kreira tabelu 'appointments' – evidencija svih rezervacija.
     */
    public function up(): void
    {
        Schema::create('appointments', function (Blueprint $table) {
            $table->id();
            // Veza na salon u kojem je rezervacija
            $table->foreignId('salon_id')
                  ->constrained('salons')
                  ->cascadeOnDelete();
            // Veza na zaposlenog (radnika) unutar tog salona
            $table->foreignId('employee_id')
                  ->constrained('employees')
                  ->cascadeOnDelete();
            // Klijent (user) koji je napravio rezervaciju
            $table->foreignId('user_id')
                  ->constrained('users')
                  ->cascadeOnDelete();
            // Datum rezervacije (isteka termina): npr. 2025-06-11
            $table->date('date');
            // Vrijeme početka termina (npr. "10:30:00")
            $table->time('start_time');
            // Vrijeme završetka termina (izračunato na osnovu trajanja usluga)
            $table->time('end_time');
            // Status rezervacije: pending, confirmed ili cancelled
            $table->enum('status', ['pending', 'confirmed', 'cancelled'])->default('pending');
            $table->timestamps();

            // Indeksiranje za brže pretrage po datumu i zaposlenom
            $table->index(['employee_id', 'date'], 'appointments_employee_date_index');
        });
    }

    /**
     * Briše tabelu 'appointments'.
     */
    public function down(): void
    {
        Schema::dropIfExists('appointments');
    }
};
