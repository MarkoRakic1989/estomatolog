<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Kreira tabelu 'email_logs' – zapis svakog poslanog e-maila radi audita.
     */
    public function up(): void
    {
        Schema::create('email_logs', function (Blueprint $table) {
            $table->id();
            // Primaoc e-maila (adresa), npr. "radnik@salon.com"
            $table->string('recipient');
            // Predmet poruke
            $table->string('subject');
            // Tjelo poruke (plain text ili HTML)
            $table->longText('body');
            // Slanje se događa asinkrono (u redu ili odmah), a timestamp bilježi kad
            $table->timestamps();

            // Dodaj indeks prema recipient za eventualno filtriranje
            $table->index('recipient', 'email_logs_recipient_index');
        });
    }

    /**
     * Briše tabelu 'email_logs'.
     */
    public function down(): void
    {
        Schema::dropIfExists('email_logs');
    }
};
