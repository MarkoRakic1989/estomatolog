<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Pivot tabela 'appointment_service' – spaja rezervacije i odabrane usluge.
     * Potrebna je za situacije kada klijent odabere više usluga u jednoj rezervaciji.
     */
    public function up(): void
    {
        Schema::create('appointment_service', function (Blueprint $table) {
            $table->id();
            $table->foreignId('appointment_id')
                  ->constrained('appointments')
                  ->cascadeOnDelete();
            $table->foreignId('service_id')
                  ->constrained('services')
                  ->cascadeOnDelete();
            $table->timestamps();

            // Indeks za brže agregiranje usluga po rezervaciji
            $table->index('appointment_id', 'appt_service_appointment_index');
        });
    }

    /**
     * Briše pivot tabelu 'appointment_service'.
     */
    public function down(): void
    {
        Schema::dropIfExists('appointment_service');
    }
};
