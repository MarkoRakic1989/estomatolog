<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Pivot tabela 'employee_service'
     * Određuje koje usluge svaki zaposleni pruža.
     */
    public function up(): void
    {
        Schema::create('employee_service', function (Blueprint $table) {
            $table->id();
            // Zaposleni
            $table->foreignId('employee_id')
                  ->constrained('employees')
                  ->cascadeOnDelete();
            // Usluga
            $table->foreignId('service_id')
                  ->constrained('services')
                  ->cascadeOnDelete();
            $table->timestamps();
        });
    }

    /**
     * Briše pivot tabelu 'employee_service'.
     */
    public function down(): void
    {
        Schema::dropIfExists('employee_service');
    }
};
