<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Dodaje enum polje 'role' u tabelu 'users'.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // Dodajemo enum kolonu 'role' s četiri moguća stanja i defaultom 'client'
            $table->enum('role', ['superadmin','owner','worker','client'])
                  ->default('client')
                  ->after('password');
        });
    }

    /**
     * Uklanja kolonu 'role' kad se migracija vrati unazad.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('role');
        });
    }
};
