<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterCategoriesAddColumns extends Migration
{
    /**
     * Pokreće migraciju: dodaje nove stupce u tablicu categories.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('categories', function (Blueprint $table) {
            // 1) Dodajemo stupac 'slug' ako ne postoji
            if (! Schema::hasColumn('categories', 'slug')) {
                $table->string('slug')->unique()
                      ->comment('Npr. beauty, hair, trainer...');
            }

            // 2) Dodajemo stupce za ikone (opcionalno, nullable)
            if (! Schema::hasColumn('categories', 'icon_192')) {
                $table->string('icon_192')->nullable()
                      ->comment('Putanja do ikone 192×192 u storage (opcionalno)');
            }
            if (! Schema::hasColumn('categories', 'icon_512')) {
                $table->string('icon_512')->nullable()
                      ->comment('Putanja do ikone 512×512 u storage (opcionalno)');
            }

            // 3) Dodajemo stupce za boje teme i pozadine (opcionalno, nullable)
            if (! Schema::hasColumn('categories', 'theme_color')) {
                $table->string('theme_color')->nullable()
                      ->comment('Hex boja teme za ovu kategoriju (npr. #FFC0CB)');
            }
            if (! Schema::hasColumn('categories', 'background_color')) {
                $table->string('background_color')->nullable()
                      ->comment('Hex boja pozadine za ovu kategoriju');
            }

            // 4) Vjerovatno već imate $table->string('name')->unique() iz početne migracije,
            //    ali ako slučajno nedostaje unique() na name, možete dodati:
            //    $table->unique('name');
            //
            // Napomena: prije dodavanja unique indeksa potrebno je osigurati da ne postoje duplikati.
        });
    }

    /**
     * Ponovno vraća promjene natrag: uklanja stupce koje smo dodali.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('categories', function (Blueprint $table) {
            // Uklonimo stupce redom (provjeravamo postojanje)
            if (Schema::hasColumn('categories', 'background_color')) {
                $table->dropColumn('background_color');
            }
            if (Schema::hasColumn('categories', 'theme_color')) {
                $table->dropColumn('theme_color');
            }
            if (Schema::hasColumn('categories', 'icon_512')) {
                $table->dropColumn('icon_512');
            }
            if (Schema::hasColumn('categories', 'icon_192')) {
                $table->dropColumn('icon_192');
            }
            if (Schema::hasColumn('categories', 'slug')) {
                // Prvo drop unique index, pa potom drop column
                $table->dropUnique(['slug']);
                $table->dropColumn('slug');
            }
            // Ako ste ručno dodali unique('name') u ovoj migraciji, ovdje biste dropali taj index:
            // $table->dropUnique(['name']);
        });
    }
}
