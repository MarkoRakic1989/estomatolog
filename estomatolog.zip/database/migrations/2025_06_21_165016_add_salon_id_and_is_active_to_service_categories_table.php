<?php
// database/migrations/xxxx_xx_xx_add_salon_id_and_is_active_to_service_categories_table.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddSalonIdAndIsActiveToServiceCategoriesTable extends Migration
{
    public function up()
    {
        Schema::table('service_categories', function (Blueprint $table) {
            // vezujemo kategorije za salon
            $table->foreignId('salon_id')
                  ->after('id')
                  ->constrained()
                  ->cascadeOnDelete();
            // status vidljivosti
            $table->boolean('is_active')
                  ->default(true)
                  ->after('slug');
        });
    }

    public function down()
    {
        Schema::table('service_categories', function (Blueprint $table) {
            $table->dropForeign(['salon_id']);
            $table->dropColumn(['salon_id', 'is_active']);
        });
    }
}
