<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTeethTable extends Migration
{
    public function up()
    {
        Schema::create('teeth', function (Blueprint $table) {
            $table->id();
            $table->string('code'); // 11, 12...
            $table->string('type'); // permanent/deciduous
            $table->string('position'); // upper-right, lower-left...
            $table->string('name')->nullable(); // Centralni sekutić...
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('teeth');
    }
}
