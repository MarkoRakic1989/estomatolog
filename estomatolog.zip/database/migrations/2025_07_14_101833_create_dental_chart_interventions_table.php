<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDentalChartInterventionsTable extends Migration
{
    public function up()
    {
        Schema::create('dental_chart_interventions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('dental_chart_id')->constrained();
            $table->foreignId('tooth_id')->constrained('teeth');
            $table->string('surface')->nullable();
            $table->foreignId('doctor_id')->constrained('users');
            $table->string('type');
            $table->text('description')->nullable();
            $table->dateTime('performed_at')->nullable();
            $table->string('status')->default('done');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('dental_chart_interventions');
    }
}
