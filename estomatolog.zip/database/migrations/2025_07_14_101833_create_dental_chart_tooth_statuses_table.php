<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDentalChartToothStatusesTable extends Migration
{
    public function up()
    {
        Schema::create('dental_chart_tooth_statuses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('dental_chart_id')->constrained();
            $table->foreignId('tooth_id')->constrained('teeth');
            $table->string('surface'); // mesial, distal, occlusal, root...
            $table->string('status');
            $table->string('color')->nullable();
            $table->text('note')->nullable();
            $table->date('status_date')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('dental_chart_tooth_statuses');
    }
}
