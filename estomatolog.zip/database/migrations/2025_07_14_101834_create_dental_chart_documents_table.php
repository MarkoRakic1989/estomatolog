<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDentalChartDocumentsTable extends Migration
{
    public function up()
    {
        Schema::create('dental_chart_documents', function (Blueprint $table) {
            $table->id();
            $table->foreignId('dental_chart_id')->constrained();
            $table->foreignId('tooth_id')->nullable()->constrained('teeth');
            $table->foreignId('intervention_id')->nullable()->constrained('dental_chart_interventions');
            $table->string('type')->nullable(); // RTG, slika, izveštaj
            $table->string('file');
            $table->string('title')->nullable();
            $table->text('note')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('dental_chart_documents');
    }
}
