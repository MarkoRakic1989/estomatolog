<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDentalChartTherapiesTable extends Migration
{
    public function up()
    {
        Schema::create('dental_chart_therapies', function (Blueprint $table) {
            $table->id();
            $table->foreignId('dental_chart_id')->constrained();
            $table->foreignId('therapy_type_id')->constrained('therapy_types');
            $table->foreignId('doctor_id')->constrained('users');
            $table->date('applied_at');
            $table->text('note')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('dental_chart_therapies');
    }
}
