<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDentalChartHistoriesTable extends Migration
{
    public function up()
    {
        Schema::create('dental_chart_histories', function (Blueprint $table) {
            $table->id();
            $table->foreignId('dental_chart_id')->constrained();
            $table->string('type'); // anamnesis, habit, family, etc
            $table->text('description');
            $table->date('recorded_at')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('dental_chart_histories');
    }
}
