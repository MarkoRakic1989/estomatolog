<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDentalChartMaterialsTable extends Migration
{
    public function up()
    {
        Schema::create('dental_chart_materials', function (Blueprint $table) {
            $table->id();
            $table->foreignId('dental_chart_id')->constrained();
            $table->foreignId('material_type_id')->constrained('material_types');
            $table->decimal('quantity', 10, 3)->default(1);
            $table->string('unit')->nullable();
            $table->date('used_at')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('dental_chart_materials');
    }
}
