<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('dental_charts', function (Blueprint $table) {
            // Add anamnesis-related boolean fields with sensible defaults.
            $table->boolean('chronic_diseases')->default(false)->after('doctor_note');
            $table->boolean('smoker')->default(false)->after('chronic_diseases');
            $table->boolean('alcohol')->default(false)->after('smoker');
            $table->boolean('anticoagulant_therapy')->default(false)->after('alcohol');
            $table->boolean('infectious_diseases')->default(false)->after('anticoagulant_therapy');
            $table->boolean('malignant_diseases')->default(false)->after('infectious_diseases');
            $table->boolean('regular_therapy')->default(false)->after('malignant_diseases');
            $table->boolean('cardiovascular_diseases')->default(false)->after('regular_therapy');
            // Additional notes field for anamnesis; can be null.
            $table->text('other_notes')->nullable()->after('cardiovascular_diseases');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('dental_charts', function (Blueprint $table) {
            $table->dropColumn([
                'chronic_diseases',
                'smoker',
                'alcohol',
                'anticoagulant_therapy',
                'infectious_diseases',
                'malignant_diseases',
                'regular_therapy',
                'cardiovascular_diseases',
                'other_notes',
            ]);
        });
    }
};