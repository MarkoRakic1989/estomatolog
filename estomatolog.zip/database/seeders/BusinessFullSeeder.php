<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use App\Models\User;
use App\Models\Salon;
use App\Models\Category;            // tabela biznis kategorija
use App\Models\ServiceCategory;
use App\Models\Service;
use Spatie\Permission\Models\Role;

class BusinessFullSeeder extends Seeder
{
    public function run()
    {
        // 1) Učitaj JSON
        $payload = json_decode(
            File::get(database_path('seeders/data/business_full.json')),
            true
        );

        // 2) Kreiraj rolu 'owner'
        Role::firstOrCreate(['name' => 'owner']);

        // 3) Prođi kroz sve salone iz JSON-a
        foreach ($payload['salons'] as $item) {
            // 3.1) Kreiraj ili nađi korisnika
            $user = User::firstOrCreate(
                ['email' => $item['owner']['email']],
                [
                    'name'     => $item['owner']['name'],
                    'password' => Hash::make($item['owner']['password']),
                ]
            );
            $user->assignRole('owner');

            // 3.2) Kreiraj ili nađi salon
            $bizCat = Category::where('slug', $item['category_slug'])->firstOrFail();
            $salon = Salon::firstOrCreate(
                ['slug' => $item['slug']],
                [
                    'name'        => $item['name'],
                    'category_id' => $bizCat->id,
                    'user_id'     => $user->id,
                    'is_active'   => true,
                ]
            );

            // 3.3) Poveži salon i korisnika (pivot salon_user)
            $salon->users()->syncWithoutDetaching($user->id);

            // 4) Učitaj sve service_categories i services za ovaj salon
            foreach ($payload['business_categories'] as $bc) {
                if ($bc['slug'] !== $item['category_slug']) {
                    continue;
                }

                foreach ($bc['categories'] as $sc) {
                    // 4.1) Kreiraj ili nađi ServiceCategory
                    $svcCat = ServiceCategory::firstOrCreate(
                        [
                          'salon_id' => $salon->id,
                          'name'     => $sc['name'],
                        ],
                        [
                          'slug'      => Str::slug($sc['name']),
                          'parent_id' => null,
                        ]
                    );

                    // 4.2) Kreiraj svaku uslugu i poveži je preko pivot-a
                    foreach (array_unique($sc['services']) as $srv) {
                        $service = Service::firstOrCreate(
                            [
                              'salon_id' => $salon->id,
                              'name'     => $srv,
                            ],
                            [
                              'slug'     => Str::slug($srv),
                              'duration' => 60,    // podrazumevano trajanje
                              'price'    => 0,     // podrazumevana cena
                            ]
                        );
                        // pivot service_category_service
                        $service->serviceCategories()->syncWithoutDetaching($svcCat->id);
                    }
                }
            }
        }
    }
}
