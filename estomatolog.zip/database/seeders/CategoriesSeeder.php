<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class CategoriesSeeder extends Seeder
{
    public function run()
    {
        $categories = [
            [
                'name'             => 'Salon lepote',
                'slug'             => 'beauty',
                'icon_192'         => null, // možeš naknadno postaviti specifične ikone u storage/salons/{slug}/
                'icon_512'         => null,
                'theme_color'      => '#FFC0CB', // pastelno roza
                'background_color' => '#FFF0F5',
            ],
            [
                'name'             => 'Frizerski salon',
                'slug'             => 'hair',
                'icon_192'         => null,
                'icon_512'         => null,
                'theme_color'      => '#8B4513', // smeđa
                'background_color' => '#F5F5DC',
            ],
            [
                'name'             => 'Personalni trener',
                'slug'             => 'trainer',
                'icon_192'         => null,
                'icon_512'         => null,
                'theme_color'      => '#008000', // zelena
                'background_color' => '#F0FFF0',
            ],
            [
                'name'             => 'Joga studio',
                'slug'             => 'yoga',
                'icon_192'         => null,
                'icon_512'         => null,
                'theme_color'      => '#6A5ACD', // srednje plava
                'background_color' => '#E6E6FA',
            ],
            [
                'name'             => 'Spa centar',
                'slug'             => 'spa',
                'icon_192'         => null,
                'icon_512'         => null,
                'theme_color'      => '#20B2AA', // tamno tirkizna
                'background_color' => '#E0FFFF',
            ],
            [
                'name'             => 'Masažni salon',
                'slug'             => 'massage',
                'icon_192'         => null,
                'icon_512'         => null,
                'theme_color'      => '#CD853F', // peruška boja
                'background_color' => '#FFEBCD',
            ],
            [
                'name'             => 'Salon za nokte',
                'slug'             => 'nails',
                'icon_192'         => null,
                'icon_512'         => null,
                'theme_color'      => '#FF69B4', // vruće ružičasta
                'background_color' => '#FFF0F5',
            ],
            [
                'name'             => 'Brijačnica',
                'slug'             => 'barber',
                'icon_192'         => null,
                'icon_512'         => null,
                'theme_color'      => '#000080', // mornarsko plava
                'background_color' => '#F0F8FF',
            ],
            [
                'name'             => 'Fitness centar',
                'slug'             => 'fitness',
                'icon_192'         => null,
                'icon_512'         => null,
                'theme_color'      => '#DC143C', // karnelijanska crvena
                'background_color' => '#FFEBEE',
            ],
            [
                'name'             => 'Kombinovani beauty/barber',
                'slug'             => 'barber_beauty',
                'icon_192'         => null,
                'icon_512'         => null,
                'theme_color'      => '#708090', // siva
                'background_color' => '#F5F5F5',
            ],
            [
                'name'             => 'Plesni studio',
                'slug'             => 'dance',
                'icon_192'         => null,
                'icon_512'         => null,
                'theme_color'      => '#708090', // siva
                'background_color' => '#F5F5F5',
            ],
        ];

        foreach ($categories as $cat) {
            DB::table('categories')->updateOrInsert(
                ['slug' => $cat['slug']],
                $cat
            );
        }
    }
}
