<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\DiagnosisType;

class DiagnosisTypeSeeder extends Seeder
{
    public function run()
    {
        $diagnoses = [
            ['name'=>'Karijes',                  'code'=>'K02',    'description'=>'Oštećenje zubne strukture izazvano bakterijama'],
            ['name'=>'Pulpitis',                 'code'=>'K04.0',  'description'=>'Upala zubne pulpe'],
            ['name'=>'Periapikalni apsces',      'code'=>'K04.6',  'description'=>'Gnojna infekcija u vrhu korena zuba'],
            ['name'=>'Gingivitis',               'code'=>'K05.0',  'description'=>'Upala desni'],
            ['name'=>'Paradontopatija',          'code'=>'K05.3',  'description'=>'Oboljenje potpornog aparata zuba'],
            ['name'=>'Trauma zuba',              'code'=>'S03.2',  'description'=>'Povreda zuba usled udara'],
            ['name'=>'Abradiran zub',            'code'=>'K03.0',  'description'=>'Habanje gleđi'],
            ['name'=>'Erozija zuba',             'code'=>'K03.2',  'description'=>'Hemijsko oštećenje gleđi'],
            ['name'=>'Fraktura zuba',            'code'=>'S02.5',  'description'=>'Prelom zubne krune ili korena'],
            ['name'=>'Endodontska infekcija',    'code'=>'K04.7',  'description'=>'Infekcija kanala korena'],
            ['name'=>'Parodontni džep',          'code'=>'K05.2',  'description'=>'Patološki produbljen sulkus'],
            ['name'=>'Periimplantitis',          'code'=>'K08.8',  'description'=>'Upala oko zubnog implanta'],
            ['name'=>'Halitoza',                 'code'=>'R19.6',  'description'=>'Neprijatan zadah iz usta'],
            ['name'=>'Leukoplakija',             'code'=>'K13.2',  'description'=>'Bele promene sluzokože'],
            ['name'=>'Oralna kandidijaza',       'code'=>'B37.0',  'description'=>'Gljivična infekcija usta'],
            ['name'=>'Herpes simplex',           'code'=>'B00.9',  'description'=>'Virusna infekcija usne sluzokože'],
            ['name'=>'Afte',                     'code'=>'K12.0',  'description'=>'Afte na sluzokoži usne duplje'],
            ['name'=>'Neuralgija trigeminusa',   'code'=>'G50.0',  'description'=>'Bol duž trigeminalnog živca'],
            ['name'=>'Upala sinusa',             'code'=>'J01.9',  'description'=>'Sinuzitis'],
            ['name'=>'Malokluzija',              'code'=>'K07.0',  'description'=>'Nepravilan zagriz'],
        ];
        foreach ($diagnoses as $diag) {
            DiagnosisType::create($diag);
        }
    }
}
