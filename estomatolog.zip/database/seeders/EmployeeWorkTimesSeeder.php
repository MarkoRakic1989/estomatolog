<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\{User, Salon, Category, Service, Employee};
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class EmployeeWorkTimesSeeder extends Seeder
{
    public function run(): void
    {
        $categories = ['Frizerski salon', 'Salon lepote', 'Masažni salon', 'Spa centar', 'Brijačnica'];
        $salons = collect();

        foreach ($categories as $index => $name) {
            $owner = User::create([
                'name' => 'Salon' . ($index + 1),
                'email' => 'vlasnik' . ($index + 1) . '@example.com',
                'password' => Hash::make('password'),
                'role' => 'owner',
                'phone' => '06000000' . $index,
            ]);

            $category = \App\Models\Category::firstOrCreate(['name' => $name]);

            $salons->push(Salon::create([
                'user_id' => $owner->id,
                'category_id' => $category->id,
                'slug' => Str::slug($name) . '-' . ($index + 1),
                'name' => 'Salon' . ($index + 1),
                'email' => 'salon' . ($index + 1) . '@example.com',
                'phone' => '06012345' . $index,
                'logo' => null,
                'primary_color' => '#000000',
                'secondary_color' => '#FFFFFF',
                'description' => 'Opis za ' . $name . ' salon.',
                'is_active' => 1,
            ]));
        }

        foreach ($salons as $salon) {
            for ($i = 1; $i <= 2; $i++) {
                $employee = Employee::create([
                    'salon_id' => $salon->id,
                    'name' => 'Radnik ' . $salon->id . '-' . $i,
                    'email' => 'radnik' . $salon->id . $i . '@example.com',
                    'phone' => '06112345' . $salon->id . $i,
                ]);

                for ($d = 0; $d < 7; $d++) {
                    $date = Carbon::now()->addDays($d)->toDateString();
                    DB::table('work_times')->insert([
                        'employee_id' => $employee->id,
                        'date' => $date,
                        'start_time' => '09:00:00',
                        'end_time' => '17:00:00',
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }
            }

            for ($s = 1; $s <= 3; $s++) {
                Service::create([
                    'salon_id' => $salon->id,
                    'name' => 'Usluga ' . $s,
                    'description' => 'Opis usluge ' . $s,
                    'price' => rand(1000, 3000),
                    'duration' => rand(30, 90),
                ]);
            }
        }

        for ($u = 1; $u <= 20; $u++) {
            $user = User::create([
                'name' => 'Korisnik ' . $u,
                'email' => 'korisnik' . $u . '@example.com',
                'password' => Hash::make('password'),
                'role' => 'client',
                'phone' => '06212345' . $u,
            ]);

            $user->salons()->sync($salons->random(3)->pluck('id')->toArray());
        }
    }
}
