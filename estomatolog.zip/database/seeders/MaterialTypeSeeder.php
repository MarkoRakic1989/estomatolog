<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\MaterialType;

class MaterialTypeSeeder extends Seeder
{
    public function run()
    {
        $materials = [
            ['name'=>'Amalgam',           'unit'=>'g',    'description'=>'Tradicionalni materijal za plombe'],
            ['name'=>'Kompozit',          'unit'=>'g',    'description'=>'Svetlosno očvršćavajući materijal za bele plombe'],
            ['name'=>'Staklo-jonomer',    'unit'=>'g',    'description'=>'Ionomerni cement za osnovne plombe'],
            ['name'=>'Keramika',          'unit'=>'g',    'description'=>'Materijal za estetske nadoknade'],
            ['name'=>'Metal',             'unit'=>'g',    'description'=>'Upotreba za krunice, mostove'],
            ['name'=>'Guta-perka',        'unit'=>'kom',  'description'=>'Endodontski materijal za punjenje kanala'],
            ['name'=>'Lidokain',          'unit'=>'amp',  'description'=>'Lokalni anestetik'],
            ['name'=>'Adrenalin',         'unit'=>'amp',  'description'=>'Za vazokonstrikciju u lokalnoj anesteziji'],
            ['name'=>'Septanest',         'unit'=>'amp',  'description'=>'Lokalni anestetik sa adrenalinom'],
            ['name'=>'Artikain',          'unit'=>'amp',  'description'=>'Moderni lokalni anestetik'],
            ['name'=>'Cink oksid eugenol', 'unit'=>'g',   'description'=>'Privremeni ispun i cement'],
            ['name'=>'Kalcium hidroksid',  'unit'=>'g',   'description'=>'Preparat za zaštitu pulpe'],
            ['name'=>'Chlorhexidin',      'unit'=>'ml',   'description'=>'Antiseptik za ispiranje kanala'],
            ['name'=>'Natrijum hipohlorit','unit'=>'ml',  'description'=>'Antiseptik za endodonciju'],
            ['name'=>'Alginat',           'unit'=>'g',    'description'=>'Materijal za uzimanje otisaka'],
            ['name'=>'Silikat',           'unit'=>'g',    'description'=>'Materijal za uzimanje preciznih otisaka'],
            ['name'=>'Polikarboksilat cement', 'unit'=>'g','description'=>'Za fiksaciju nadoknada'],
            ['name'=>'Stainless steel wire','unit'=>'cm',  'description'=>'Žica za ortodonciju'],
            ['name'=>'Elastične gumice',   'unit'=>'kom', 'description'=>'Ortodoncija'],
            ['name'=>'Fosfatni cement',     'unit'=>'g',   'description'=>'Klasični cement'],
            ['name'=>'Kompozitne lepljive mase','unit'=>'g','description'=>'Za fiksaciju aparata i nadoknada'],
        ];
        foreach ($materials as $material) {
            MaterialType::create($material);
        }
    }
}
