<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PackageSeeder extends Seeder
{
    public function run()
    {
        // OBRISI POSTOJECE

        DB::table('packages')->insert([
            [
                'name' => 'Basic',
                'price' => 4000,
                'duration_months' => 1,
                'description' => '
                    <ul>
                        <li><b>Online zakazivanje termina</b></li>
                        <li><b>Osnovni prikaz sajta za ordinaciju</b></li>
                        <li><b>Karton pacijenta (istorija rada po zubima)</b></li>
                        <li><b>Osnovne statistike</b></li>
                        <li><b>Notifikacije o terminima na email</b></li>
                    </ul>
                ',
                'is_active' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Standard',
                'price' => 7000,
                'duration_months' => 1,
                'description' => '
                    <ul>
                        <li><b>Sve iz Basic paketa</b></li>
                        <li><b>Dodavanje fajlova uz karton (snimci, slike, analize)</b></li>
                        <li><b>Napredni karton (alergije, terapije, napomene)</b></li>
                        <li><b>Galerija slika, blog/stranice ordinacije</b></li>
                        <li><b>Personalizovan dizajn sajta</b></li>
                        <li><b>Detaljne statistike o pacijentima i uslugama</b></li>
                    </ul>
                ',
                'is_active' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Premium',
                'price' => 10000,
                'duration_months' => 1,
                'description' => '
                    <ul>
                        <li><b>Sve iz Standard paketa</b></li>
                        <li><b>Upravljanje zalihama i materijalima</b></li>
                        <li><b>Povezivanje usluga sa troškovima materijala</b></li>
                        <li><b>Automatska upozorenja za nedostatak zaliha</b></li>
                        <li><b>Fakturisanaje i evidencija troškova</b></li>
                        <li><b>Napredne analitike za biznis</b></li>
                        <li><b>Marketing alati (newsletter, kuponi...)</b></li>
                    </ul>
                ',
                'is_active' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}
