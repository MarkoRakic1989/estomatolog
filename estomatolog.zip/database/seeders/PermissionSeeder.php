<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class PermissionSeeder extends Seeder
{
    public function run(): void
    {
        // 1) дефинишемо перми­сије
        $actions = ['view', 'manage'];
        $modules = [
            'dashboard',
            'suppliers',
            'expenses',
            'assets',
            'warranties',
            'maintenances',
            'stock',
            'services',
            'appointments',
            'invoices',
            'invoice-items',  // само destroy али укључујемо заједно
            'worktime',
            'pages',
            'galleries',
            'design',
            'employees',
            'users',
            'marketing',
            'subscription',
        ];

        $permissions = [];
        foreach ($modules as $mod) {
            foreach ($actions as $act) {
                $permissions[] = "{$mod}.{$act}";
            }
        }
        // subscription само view
        $permissions = array_filter($permissions, fn($p) => $p !== 'subscription.manage');

        foreach ($permissions as $perm) {
            Permission::firstOrCreate(['name' => $perm]);
        }

        // 2) дефинишемо улоге
        $roles = [
            'owner' => $permissions,
            'manager' => array_filter($permissions, fn($p) => !in_array(explode('.', $p)[0], ['design','gallery'])), 
            'receptionist' => [
                'appointments.manage','appointments.view',
                'invoices.manage','invoices.view',
                'dashboard.view',
            ],
            'cashier' => ['invoices.manage','invoices.view','dashboard.view'],
            'service' => ['appointments.view','appointments.manage','dashboard.view'],
            'inventory' => ['stock.manage','stock.view','dashboard.view'],
            'marketing' => ['marketing.manage','marketing.view','dashboard.view'],
            'view-only' => ['dashboard.view'],
        ];

        foreach ($roles as $roleName => $perms) {
            $role = Role::firstOrCreate(['name' => $roleName]);
            $role->syncPermissions($perms);
        }
    }
}
