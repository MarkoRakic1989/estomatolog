<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RolesAndPermissionsSeeder extends Seeder
{
    public function run()
    {
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();

        // OBRISI SVE
        \DB::table('role_has_permissions')->truncate();
        \DB::table('model_has_roles')->truncate();
        \DB::table('model_has_permissions')->truncate();
        Permission::query()->delete();
        Role::query()->delete();

        // SAMO VIEW I MANAGE ZA SVAKI MODUL
        $permissions = [
            'dashboard.view',

            'appointments.view',
            'appointments.manage',

            'users.view',
            'users.manage',

            'employees.view',
            'employees.manage',

            'services.view',
            'services.manage',

            'service-categories.view',
            'service-categories.manage',

            'worktime.view',
            'worktime.manage',

            'pages.view',
            'pages.manage',

            'galleries.view',
            'galleries.manage',

            'design.view',
            'design.manage',

            'patient_files.view',
            'patient_files.manage',

            'expenses.view',
            'expenses.manage',

            'suppliers.view',
            'suppliers.manage',

            'stock.view',
            'stock.manage',

            'invoices.view',
            'invoices.manage',

            'assets.view',
            'assets.manage',

            'warranties.view',
            'warranties.manage',

            'maintenances.view',
            'maintenances.manage',

            'marketing.view',
            'marketing.manage',

            'subscription.view',
            'settings.manage',
            'dental_chart.view',
            'dental_chart.manage',
        ];

        foreach ($permissions as $perm) {
            Permission::firstOrCreate(['name' => $perm, 'guard_name' => 'web']);
        }

        // SVE ROLE
        $roles = [
            'owner', 'manager', 'dentist', 'assistant', 'receptionist', 'cashier', 'inventory', 'marketing'
        ];
        foreach ($roles as $role) {
            Role::firstOrCreate(['name' => $role, 'guard_name' => 'web']);
        }

        // OWNER & MANAGER – SVE!
        Role::findByName('owner')->syncPermissions($permissions);
        Role::findByName('manager')->syncPermissions($permissions);

        // DENTIST (samo osnovni pristup)
        Role::findByName('dentist')->syncPermissions([
            'dashboard.view',
            'appointments.view',
            'appointments.manage',
            'users.view',
            'dental_chart.view',
            'dental_chart.manage',
        ]);

        // ASSISTANT
        Role::findByName('assistant')->syncPermissions([
            'dashboard.view',
            'appointments.view',
            'appointments.manage',
            'users.view',
        ]);

        // RECEPTIONIST
        Role::findByName('receptionist')->syncPermissions([
            'dashboard.view',
            'appointments.view',
            'appointments.manage',
            'users.view',
            'users.manage',
            'employees.view',
        ]);

        // CASHIER
        Role::findByName('cashier')->syncPermissions([
            'dashboard.view',
            'invoices.view',
            'invoices.manage',
        ]);

        // INVENTORY (Premium)
        Role::findByName('inventory')->syncPermissions([
            'dashboard.view',
            'stock.view', 'stock.manage',
            'suppliers.view', 'suppliers.manage',
            'expenses.view', 'expenses.manage',
            'assets.view', 'assets.manage',
            'warranties.view', 'warranties.manage',
            'maintenances.view', 'maintenances.manage',
        ]);

        // MARKETING (Premium)
        Role::findByName('marketing')->syncPermissions([
            'dashboard.view',
            'marketing.view',
            'marketing.manage',
            'pages.view', 'pages.manage',
            'galleries.view', 'galleries.manage',
        ]);
    }
}
