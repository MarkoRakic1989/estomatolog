<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Category;
use App\Models\Salon;
use App\Models\Service;
use Illuminate\Support\Str;
use Carbon\Carbon;

class SalonSeeder extends Seeder
{
    public function run()
    {

        // 2) Kreiraj (ili ažuriraj) salon u tablici `salons`
        //    Pretpostavljamo da salons tablica ima točne kolone koje ste pokazali:
        //    id, user_id, category_id, slug, name, email, phone, logo, primary_color, secondary_color, description, is_active, paid_until, created_at, updated_at.
        $salon = Salon::updateOrCreate(
            ['slug' => 'salon1'],
            [
                'user_id'         => 1, // ili ID postojećeg korisnika ako želite vezu na user
                'category_id'     => 2,
                'name'            => 'Salon1 Hair & Beauty',
                'email'           => 'kontakt@salon1.hr',
                'phone'           => '+385912345678',
                'logo'            => null, // stavite npr. "images/salons/logos/salon1-logo.png" ako imate logo
                'primary_color'   => '#FF69B4',  // jarko roža
                'secondary_color' => '#000000',  // crna kao tekst ili sekundarna
                'description'     => '<p>Salon1 Hair & Beauty je vrhunski frizerski salon smješten u centru grada. Specijalizirani smo za moderne stilove šišanja, bojanja i tretmane kose. Naš stručni tim stoji vam na raspolaganju kako biste izgledali i osjećali se savršeno.</p>',
                'is_active'       => 1,
                'paid_until'      => Carbon::now()->addMonth()->toDateString(),
            ]
        );

        // 3) Kreiraj (ili ažuriraj) usluge za taj salon
        //    Pretpostavljamo da services tablica ima kolone: id, salon_id, name, duration, price, description, icon, capacity, created_at, updated_at.
        $servicesData = [
            [
                'name'        => 'Šišanje (žene)',
                'duration'    => 60,        // trajanje u minutama
                'price'       => 200.00,    // u lokalnoj valuti
                'description' => 'Usluga uključuje konzultaciju, pranje kose, šišanje i završnu stilizaciju. Naši frizeri prate najnovije trendove.',
                'icon'        => null,      // npr. "icons/scissors.png" ako imate ikonicu
                'capacity'    => 1,
            ],
            [
                'name'        => 'Šišanje (muškarci)',
                'duration'    => 30,
                'price'       => 100.00,
                'description' => 'Brz i uredan kroj za muškarce. Uključuje pranje kose i precizno šišanje.',
                'icon'        => null,
                'capacity'    => 1,
            ],
            [
                'name'        => 'Pramenovi',
                'duration'    => 120,
                'price'       => 400.00,
                'description' => 'Profesionalno posvjetljivanje (pramenovi) ili bojanje kose. Uključuje konzultaciju i tretman.',
                'icon'        => null,
                'capacity'    => 1,
            ],
            [
                'name'        => 'Tretman keratinom',
                'duration'    => 90,
                'price'       => 500.00,
                'description' => 'Tretman keratinom zaglađuje i jača kosu, uklanja ispucale vrhove i daje dugotrajan sjaj.',
                'icon'        => null,
                'capacity'    => 1,
            ],
            [
                'name'        => 'Feniranje i stilizacija',
                'duration'    => 45,
                'price'       => 150.00,
                'description' => 'Usluga obuhvaća pranje kose i stilizaciju fenom. Mogućnost dodatnog oblikovanja uvijačem ili peglom.',
                'icon'        => null,
                'capacity'    => 1,
            ],
        ];

        foreach ($servicesData as $data) {
            Service::updateOrCreate(
                [
                    'salon_id' => $salon->id,
                    'name'     => $data['name'],
                ],
                [
                    'duration'    => $data['duration'],
                    'price'       => $data['price'],
                    'description' => $data['description'],
                    'icon'        => $data['icon'],
                    'capacity'    => $data['capacity'],
                ]
            );
        }
    }
}
