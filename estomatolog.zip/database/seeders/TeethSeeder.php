<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Tooth;

class TeethSeeder extends Seeder
{
    public function run()
    {
        $teeth = [
            // 32 stalna zuba (FDI notacija: 11-18, 21-28, 31-38, 41-48)
            // Gornja vilica desno (11-18)
            ['code'=>'11','type'=>'stalni','position'=>'gore-desno', 'name'=>'Centralni sekutić'],
            ['code'=>'12','type'=>'stalni','position'=>'gore-desno', 'name'=>'Bočni sekutić'],
            ['code'=>'13','type'=>'stalni','position'=>'gore-desno', 'name'=>'Očnjak'],
            ['code'=>'14','type'=>'stalni','position'=>'gore-desno', 'name'=>'Prvi premolar'],
            ['code'=>'15','type'=>'stalni','position'=>'gore-desno', 'name'=>'Drugi premolar'],
            ['code'=>'16','type'=>'stalni','position'=>'gore-desno', 'name'=>'Prvi molar'],
            ['code'=>'17','type'=>'stalni','position'=>'gore-desno', 'name'=>'Drugi molar'],
            ['code'=>'18','type'=>'stalni','position'=>'gore-desno', 'name'=>'Treći molar (umnjak)'],
            // Gornja vilica levo (21-28)
            ['code'=>'21','type'=>'stalni','position'=>'gore-levo', 'name'=>'Centralni sekutić'],
            ['code'=>'22','type'=>'stalni','position'=>'gore-levo', 'name'=>'Bočni sekutić'],
            ['code'=>'23','type'=>'stalni','position'=>'gore-levo', 'name'=>'Očnjak'],
            ['code'=>'24','type'=>'stalni','position'=>'gore-levo', 'name'=>'Prvi premolar'],
            ['code'=>'25','type'=>'stalni','position'=>'gore-levo', 'name'=>'Drugi premolar'],
            ['code'=>'26','type'=>'stalni','position'=>'gore-levo', 'name'=>'Prvi molar'],
            ['code'=>'27','type'=>'stalni','position'=>'gore-levo', 'name'=>'Drugi molar'],
            ['code'=>'28','type'=>'stalni','position'=>'gore-levo', 'name'=>'Treći molar (umnjak)'],
            // Donja vilica levo (31-38)
            ['code'=>'31','type'=>'stalni','position'=>'dole-levo', 'name'=>'Centralni sekutić'],
            ['code'=>'32','type'=>'stalni','position'=>'dole-levo', 'name'=>'Bočni sekutić'],
            ['code'=>'33','type'=>'stalni','position'=>'dole-levo', 'name'=>'Očnjak'],
            ['code'=>'34','type'=>'stalni','position'=>'dole-levo', 'name'=>'Prvi premolar'],
            ['code'=>'35','type'=>'stalni','position'=>'dole-levo', 'name'=>'Drugi premolar'],
            ['code'=>'36','type'=>'stalni','position'=>'dole-levo', 'name'=>'Prvi molar'],
            ['code'=>'37','type'=>'stalni','position'=>'dole-levo', 'name'=>'Drugi molar'],
            ['code'=>'38','type'=>'stalni','position'=>'dole-levo', 'name'=>'Treći molar (umnjak)'],
            // Donja vilica desno (41-48)
            ['code'=>'41','type'=>'stalni','position'=>'dole-desno', 'name'=>'Centralni sekutić'],
            ['code'=>'42','type'=>'stalni','position'=>'dole-desno', 'name'=>'Bočni sekutić'],
            ['code'=>'43','type'=>'stalni','position'=>'dole-desno', 'name'=>'Očnjak'],
            ['code'=>'44','type'=>'stalni','position'=>'dole-desno', 'name'=>'Prvi premolar'],
            ['code'=>'45','type'=>'stalni','position'=>'dole-desno', 'name'=>'Drugi premolar'],
            ['code'=>'46','type'=>'stalni','position'=>'dole-desno', 'name'=>'Prvi molar'],
            ['code'=>'47','type'=>'stalni','position'=>'dole-desno', 'name'=>'Drugi molar'],
            ['code'=>'48','type'=>'stalni','position'=>'dole-desno', 'name'=>'Treći molar (umnjak)'],

            // 20 mlečnih zuba (51-55, 61-65, 71-75, 81-85)
            // Gornja vilica desno (51-55)
            ['code'=>'51','type'=>'mlečni','position'=>'gore-desno', 'name'=>'Centralni sekutić (mlečni)'],
            ['code'=>'52','type'=>'mlečni','position'=>'gore-desno', 'name'=>'Bočni sekutić (mlečni)'],
            ['code'=>'53','type'=>'mlečni','position'=>'gore-desno', 'name'=>'Očnjak (mlečni)'],
            ['code'=>'54','type'=>'mlečni','position'=>'gore-desno', 'name'=>'Prvi molar (mlečni)'],
            ['code'=>'55','type'=>'mlečni','position'=>'gore-desno', 'name'=>'Drugi molar (mlečni)'],
            // Gornja vilica levo (61-65)
            ['code'=>'61','type'=>'mlečni','position'=>'gore-levo', 'name'=>'Centralni sekutić (mlečni)'],
            ['code'=>'62','type'=>'mlečni','position'=>'gore-levo', 'name'=>'Bočni sekutić (mlečni)'],
            ['code'=>'63','type'=>'mlečni','position'=>'gore-levo', 'name'=>'Očnjak (mlečni)'],
            ['code'=>'64','type'=>'mlečni','position'=>'gore-levo', 'name'=>'Prvi molar (mlečni)'],
            ['code'=>'65','type'=>'mlečni','position'=>'gore-levo', 'name'=>'Drugi molar (mlečni)'],
            // Donja vilica levo (71-75)
            ['code'=>'71','type'=>'mlečni','position'=>'dole-levo', 'name'=>'Centralni sekutić (mlečni)'],
            ['code'=>'72','type'=>'mlečni','position'=>'dole-levo', 'name'=>'Bočni sekutić (mlečni)'],
            ['code'=>'73','type'=>'mlečni','position'=>'dole-levo', 'name'=>'Očnjak (mlečni)'],
            ['code'=>'74','type'=>'mlečni','position'=>'dole-levo', 'name'=>'Prvi molar (mlečni)'],
            ['code'=>'75','type'=>'mlečni','position'=>'dole-levo', 'name'=>'Drugi molar (mlečni)'],
            // Donja vilica desno (81-85)
            ['code'=>'81','type'=>'mlečni','position'=>'dole-desno', 'name'=>'Centralni sekutić (mlečni)'],
            ['code'=>'82','type'=>'mlečni','position'=>'dole-desno', 'name'=>'Bočni sekutić (mlečni)'],
            ['code'=>'83','type'=>'mlečni','position'=>'dole-desno', 'name'=>'Očnjak (mlečni)'],
            ['code'=>'84','type'=>'mlečni','position'=>'dole-desno', 'name'=>'Prvi molar (mlečni)'],
            ['code'=>'85','type'=>'mlečni','position'=>'dole-desno', 'name'=>'Drugi molar (mlečni)'],
        ];
        foreach ($teeth as $tooth) {
            Tooth::create($tooth);
        }
    }
}
