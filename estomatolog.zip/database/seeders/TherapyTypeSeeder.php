<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\TherapyType;

class TherapyTypeSeeder extends Seeder
{
    public function run()
    {
        $types = [
            ['name'=>'Lokalna anestezija', 'description'=>'Upotreba lokalnog anestetika radi smanjenja bola'],
            ['name'=>'Antibiotska terapija', 'description'=>'Primena antibiotika kod infekcija'],
            ['name'=>'Analgezija', 'description'=>'Terapija protiv bolova'],
            ['name'=>'Endodontska terapija', 'description'=>'Lečenje kanala korena zuba'],
            ['name'=>'Parodontološka terapija', 'description'=>'Lečenje bolesti desni'],
            ['name'=>'Antimikrobna terapija', 'description'=>'Terapija protiv mikroorganizama'],
            ['name'=>'Protivupalna terapija', 'description'=>'Terapija kod upalnih procesa'],
            ['name'=>'Dezinfekcija kanala', 'description'=>'Dezinfekcija pri endodontskoj terapiji'],
            ['name'=>'Fluoridacija', 'description'=>'Terapija fluorisanim preparatima'],
            ['name'=>'Hirurška terapija', 'description'=>'Postoperativna terapija posle vađenja zuba ili intervencija'],
            ['name'=>'Kortikosteroidna terapija', 'description'=>'Kod teških upalnih procesa'],
            ['name'=>'Imunološka terapija', 'description'=>'Kod imunoloških poremećaja'],
            ['name'=>'Alergološka terapija', 'description'=>'Terapija alergijskih reakcija'],
            ['name'=>'Sedacija', 'description'=>'Upotreba sedativa kod anksioznih pacijenata'],
            ['name'=>'Antifungalna terapija', 'description'=>'Terapija gljivičnih infekcija'],
            ['name'=>'Antiviralna terapija', 'description'=>'Kod virusnih infekcija u ustima'],
        ];
        foreach ($types as $type) {
            TherapyType::create($type);
        }
    }
}
