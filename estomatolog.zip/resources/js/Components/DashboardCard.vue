<template>
  <Link
    :href="href"
    class="card bg-base-100 border border-base-200 shadow-lg hover:shadow-xl transition rounded-2xl group cursor-pointer p-0"
  >
    <div class="card-body flex flex-col items-center justify-center py-6">
      <span class="mb-3 flex items-center justify-center h-14 w-14 rounded-full bg-blue-50 border border-blue-200 group-hover:bg-blue-100 transition">
        <!-- SVG ikone iz prethodnog odgovora, copy/paste kao dole -->
        <svg v-if="icon==='user'" width="32" height="32" viewBox="0 0 32 32" fill="none">
          <circle cx="16" cy="12" r="7" stroke="#2563eb" stroke-width="2" fill="#fff"/>
          <ellipse cx="16" cy="24.5" rx="10" ry="5.5" stroke="#2563eb" stroke-width="2" fill="#fff"/>
        </svg>
        <svg v-else-if="icon==='tooth'" width="32" height="32" viewBox="0 0 32 32" fill="none">
          <path d="M16 5C19 5 21.5 7.5 21.5 11.5C21.5 15.5 18 28 16 28C14 28 10.5 15.5 10.5 11.5C10.5 7.5 13 5 16 5Z"
            stroke="#a21caf" stroke-width="2" fill="#fff"/>
          <ellipse cx="16" cy="11" rx="4.5" ry="3.5" stroke="#a21caf" stroke-width="2" fill="#fff"/>
        </svg>
        <svg v-else-if="icon==='history'" width="32" height="32" viewBox="0 0 32 32" fill="none">
          <circle cx="16" cy="16" r="13" stroke="#0ea5e9" stroke-width="2" fill="#fff"/>
          <path d="M16 10V16L21 19" stroke="#0ea5e9" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <svg v-else-if="icon==='clipboard-list'" width="32" height="32" viewBox="0 0 32 32" fill="none">
          <rect x="8" y="6" width="16" height="20" rx="3" stroke="#22c55e" stroke-width="2" fill="#fff"/>
          <rect x="13" y="4" width="6" height="4" rx="2" stroke="#22c55e" stroke-width="2" fill="#fff"/>
          <line x1="12" y1="13" x2="20" y2="13" stroke="#22c55e" stroke-width="2"/>
          <line x1="12" y1="18" x2="20" y2="18" stroke="#22c55e" stroke-width="2"/>
        </svg>
        <svg v-else-if="icon==='activity'" width="32" height="32" viewBox="0 0 32 32" fill="none">
          <polyline points="5,17 13,24 27,8" stroke="#f59e42" stroke-width="2" fill="none"/>
        </svg>
        <svg v-else-if="icon==='stethoscope'" width="32" height="32" viewBox="0 0 32 32" fill="none">
          <circle cx="9" cy="17" r="3" stroke="#eab308" stroke-width="2" fill="#fff"/>
          <circle cx="23" cy="17" r="3" stroke="#eab308" stroke-width="2" fill="#fff"/>
          <path d="M9 20v2a7 7 0 0014 0v-2" stroke="#eab308" stroke-width="2" fill="none"/>
        </svg>
        <svg v-else-if="icon==='image'" width="32" height="32" viewBox="0 0 32 32" fill="none">
          <rect x="6" y="8" width="20" height="16" rx="3" stroke="#a3e635" stroke-width="2" fill="#fff"/>
          <circle cx="11" cy="13" r="2" stroke="#a3e635" stroke-width="2"/>
          <path d="M8 22l5-7 5 7 6-8" stroke="#a3e635" stroke-width="2" fill="none"/>
        </svg>
        <svg v-else-if="icon==='heart'" width="32" height="32" viewBox="0 0 32 32" fill="none">
          <path d="M16 27s-9-5.7-9-13a6 6 0 0 1 12 0 6 6 0 0 1 12 0c0 7.3-9 13-9 13z" stroke="#ef4444" stroke-width="2" fill="#fff"/>
        </svg>
        <svg v-else-if="icon==='file-text'" width="32" height="32" viewBox="0 0 32 32" fill="none">
          <rect x="8" y="6" width="16" height="20" rx="3" stroke="#0ea5e9" stroke-width="2" fill="#fff"/>
          <line x1="12" y1="13" x2="20" y2="13" stroke="#0ea5e9" stroke-width="2"/>
          <line x1="12" y1="18" x2="20" y2="18" stroke="#0ea5e9" stroke-width="2"/>
        </svg>
        <svg v-else-if="icon==='credit-card'" width="32" height="32" viewBox="0 0 32 32" fill="none">
          <rect x="6" y="10" width="20" height="12" rx="3" stroke="#16a34a" stroke-width="2" fill="#fff"/>
          <rect x="9" y="17" width="4" height="2" rx="1" stroke="#16a34a" stroke-width="2"/>
        </svg>
        <svg v-else-if="icon==='package'" width="32" height="32" viewBox="0 0 32 32" fill="none">
          <rect x="8" y="8" width="16" height="16" rx="3" stroke="#fbbf24" stroke-width="2" fill="#fff"/>
          <line x1="16" y1="8" x2="16" y2="24" stroke="#fbbf24" stroke-width="2"/>
        </svg>
        <svg v-else-if="icon==='calendar'" width="32" height="32" viewBox="0 0 32 32" fill="none">
          <rect x="7" y="8" width="18" height="16" rx="3" stroke="#dc2626" stroke-width="2" fill="#fff"/>
          <line x1="11" y1="13" x2="21" y2="13" stroke="#dc2626" stroke-width="2"/>
        </svg>
        <svg v-else-if="icon==='users'" width="32" height="32" viewBox="0 0 32 32" fill="none">
          <circle cx="10" cy="13" r="4" stroke="#2563eb" stroke-width="2" fill="#fff"/>
          <circle cx="22" cy="13" r="4" stroke="#2563eb" stroke-width="2" fill="#fff"/>
          <ellipse cx="16" cy="23" rx="10" ry="5" stroke="#2563eb" stroke-width="2" fill="#fff"/>
        </svg>
        <svg v-else-if="icon==='list'" width="32" height="32" viewBox="0 0 32 32" fill="none">
          <rect x="8" y="9" width="16" height="2" rx="1" fill="#6d28d9"/>
          <rect x="8" y="15" width="16" height="2" rx="1" fill="#6d28d9"/>
          <rect x="8" y="21" width="10" height="2" rx="1" fill="#6d28d9"/>
        </svg>
      </span>
      <span class="text-lg font-semibold text-blue-900 text-center">{{ label }}</span>
    </div>
  </Link>
</template>

<script setup>
import { defineProps } from 'vue'
import { Link } from '@inertiajs/vue3'
const props = defineProps({
  icon: String,
  label: String,
  href: [String, Object]
})
</script>
