<template>
  <PreviewLayout :theme="theme" :salon="salon" :salonSlug="salon.slug">
    <!-- Hero section -->
    <section class="relative w-full h-[70vh] overflow-hidden">
      <div
        v-if="salon.cover_image"
        class="absolute inset-0 bg-cover bg-center brightness-[0.6]"
        :style="{ backgroundImage: `url('${salon.cover_image}')` }"
      ></div>
      <div
        v-else
        class="absolute inset-0 bg-gray-300 flex items-center justify-center text-gray-500"
      >
        <span class="text-2xl">No Cover Image</span>
      </div>

      <div class="relative z-10 flex flex-col items-center justify-center h-full text-center px-4">
        <h1 class="text-5xl font-extrabold text-white mb-4">
          Welcome to {{ salon.name }}
        </h1>
        <p class="text-lg text-white/90 max-w-2xl mb-8">
          Discover our premium services and book your appointment in seconds.
        </p>
        <Link
         href="#"
          class="btn btn-lg btn-primary"
        >
          Book Now
        </Link>
      </div>
    </section>

    <!-- Top Services section -->
    <section class="py-16 bg-base-100">
      <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 class="text-4xl font-bold mb-6">
          Our Top Services
        </h2>
        <p class="text-gray-600 mb-12">
          We offer a range of high-quality services to meet your needs. Here are a few highlights:
        </p>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          <div
            v-for="service in topServices"
            :key="service.id"
            class="card shadow hover:shadow-lg transition"
          >
            <figure>
              <img
                :src="service.image || `https://via.placeholder.com/400x300?text=${encodeURIComponent(service.name)}`"
                alt="Service image"
                class="h-48 w-full object-cover"
              />
            </figure>
            <div class="card-body">
              <h3 class="card-title">{{ service.name }}</h3>
              <p class="text-gray-600">{{ service.short_desc }}</p>
              <div class="mt-4 flex justify-between items-center">
                <span class="text-xl font-bold">
                  ${{ service.price }}
                </span>
                <span class="badge badge-outline">{{ service.duration }} min</span>
              </div>
              <Link
               href="#"
                class="btn btn-sm btn-secondary mt-4"
                
              >
                Book It
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- CTA Section -->
    <section class="py-20 bg-secondary/10">
      <div class="max-w-4xl mx-auto px-4 text-center">
        <h2 class="text-3xl font-extrabold mb-4">
          Ready for Your Transformation?
        </h2>
        <p class="text-gray-700 mb-8">
          Join hundreds of happy clients who have experienced our top-notch services.  
          Scheduling is quick and easy!
        </p>
        <Link
          href="#"
          class="btn btn-lg"
          
        >
          Schedule Now
        </Link>
      </div>
    </section>

    <!-- Optional Testimonials Section -->
    <section class="py-16 bg-base-200">
      <div class="max-w-5xl mx-auto px-4 text-center">
        <h2 class="text-3xl font-bold mb-8">
          What Our Clients Say
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div v-for="i in 3" :key="i" class="p-6 bg-white rounded-lg shadow">
            <p class="text-gray-600 mb-4">
              “Excellent service, friendly staff, and a relaxing atmosphere. I’ll be back!”
            </p>
            <div class="font-semibold">— Client {{ i }}</div>
          </div>
        </div>
      </div>
    </section>
  </PreviewLayout>
</template>

<script setup>
import PreviewLayout from '@/Components/PreviewLayout.vue'
import { Link } from '@inertiajs/vue3'
import Layout from '@/Pages/Public/Layout.vue'
const placeholder = 'https://via.placeholder.com/400x240?text=No+Image'
const props = defineProps({
  salonSlug:    String,
  salon:        Object,
  currentRoute: String,
  topServices:  Array,
  theme:      String,
})

function capitalize(s) {
  return s.charAt(0).toUpperCase() + s.slice(1)
}
</script>

<style scoped>
/* Home-specific overrides if needed */
</style>
