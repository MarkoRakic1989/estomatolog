<template>
  <div :data-theme="theme" class="flex flex-col sticky top-[100px] right-0 bg-base-100">
    <!-- Header -->
    <header class="w-full shadow-md bg-base-200">
      <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
        <h1 class="text-xl font-bold">
          <!-- невежући link -->
          <a href="#" class="hover:underline">{{ salon.name || salonSlug }}</a>
        </h1>
        <!-- Desktop navigacija -->
        <nav class="hidden md:flex space-x-6">
          <a href="#" class="hover:underline">Home</a>
          <a href="#" class="hover:underline">Services</a>
          <a href="#" class="hover:underline">About</a>
          <a href="#" class="hover:underline">Contact</a>
        </nav>
        <!-- Mobile gumbovi -->
        <div class="flex items-center space-x-4 md:hidden">
          <button class="btn btn-sm">Install App</button>
          <button class="btn btn-square btn-ghost p-2">
            <!-- иконица hamburger -->
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24"
              stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
      </div>
    </header>

    <!-- Main content -->
    <main class="flex-1 overflow-auto">
      <slot />
    </main>

    <!-- Footer -->
    <footer class="border-t bg-base-200">
      <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 text-center text-sm">
        &copy; {{ new Date().getFullYear() }} {{ salon.name || salonSlug }}. All rights reserved.
      </div>
    </footer>
  </div>
</template>

<script setup>
defineProps({
  theme: String,
  salon: Object,
  topServices: Array,
  salonSlug: String,
})
</script>

<style scoped>
/* по потреби додатне прилагођавања */
</style>
