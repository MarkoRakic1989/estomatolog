<script setup>
import { ref, watch, onMounted } from 'vue'
import { Link, usePage } from '@inertiajs/vue3'
import ApplicationLogo from '@/Components/ApplicationLogo.vue'
import Dropdown from '@/Components/Dropdown.vue'
import DropdownLink from '@/Components/DropdownLink.vue'
import NavLink from '@/Components/NavLink.vue'
import ResponsiveNavLink from '@/Components/ResponsiveNavLink.vue'
import { useToast } from 'vue-toastification'

const showingNavigationDropdown = ref(false)
const page = usePage()
const toast = useToast()

// Uzimamo prvu ulogu iz array-a roles
const userRole = 'superadmin'

// Flash i error toasts
watch(
  () => page.props.flash,
  flash => {
    if (flash?.success) toast.success(flash.success)
    if (flash?.error) toast.error(flash.error)
  },
  { immediate: true }
)
watch(
  () => page.props.errors,
  errors => {
    if (!errors) return
    Object.values(errors).flat().forEach(msg => toast.error(msg))
  },
  { immediate: true }
)

// Theme switcher
const isDark = ref(false)

function applyTheme(dark) {
  document.documentElement.dataset.theme = dark ? 'dark' : 'light'
  localStorage.setItem('theme', dark ? 'dark' : 'light')
}

onMounted(() => {
  const saved = localStorage.getItem('theme') === 'dark'
  isDark.value = saved
  applyTheme(saved)
})

watch(isDark, val => applyTheme(val))
</script>

<template>
  <div class="min-h-screen bg-base-200">
    <nav class="bg-base-100 border-b border-base-300">
      <div class="container mx-auto px-4 py-3 flex justify-between items-center">
        <div class="flex items-center space-x-4">
          <!-- Logo -->
          <Link href="/">
          <ApplicationLogo class="h-8 w-auto text-primary" />
          </Link>

          <!-- Glavni linkovi -->
          <div class="hidden md:flex space-x-2">
            <NavLink v-if="userRole === 'superadmin'" :href="route('superadmin.salons.index')"
              class="btn btn-ghost btn-sm" :active="route().current('superadmin.salons.index')">All Salons</NavLink>

            <NavLink v-if="userRole === 'superadmin'" :href="route('superadmin.users.index')"
              class="btn btn-ghost btn-sm" :active="route().current('superadmin.users.index')">Users</NavLink>

            <NavLink v-if="userRole === 'superadmin'" :href="route('superadmin.roles.index')"
              class="btn btn-ghost btn-sm" :active="route().current('superadmin.roles.*')">Roles</NavLink>

            <NavLink v-if="userRole === 'superadmin'" :href="route('superadmin.permissions.index')"
              class="btn btn-ghost btn-sm" :active="route().current('superadmin.permissions.*')">Permissions</NavLink>

            <NavLink v-if="userRole === 'superadmin'" :href="route('superadmin.packages.index')"
              class="btn btn-ghost btn-sm" :active="route().current('superadmin.packages.*')">Packages</NavLink>

            <NavLink v-if="userRole === 'superadmin'" :href="route('superadmin.subscriptions.index')"
              class="btn btn-ghost btn-sm" :active="route().current('superadmin.subscriptions.*')">Subscriptions
            </NavLink>
          </div>
        </div>

        <div class="flex items-center space-x-4">
          <!-- Theme switcher -->
          <label class="swap swap-rotate">
            <input type="checkbox" v-model="isDark" />
            <!-- sun icon -->
            <svg class="swap-on h-6 w-6 text-yellow-500" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
              viewBox="0 0 24 24">
              <path
                d="M5.64 17.657l-.707.707a1 1 0 001.414 1.414l.707-.707a1 1 0 10-1.414-1.414zM4 12a1 1 0 01-1-1H2a1 1 0 100 2h1a1 1 0 011-1zm12 7a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zm6.364-1.343a1 1 0 10-1.414 1.414l.707.707a1 1 0 001.414-1.414l-.707-.707zM12 4a1 1 0 011-1V2a1 1 0 10-2 0v1a1 1 0 011 1zm7.657 1.343l.707-.707a1 1 0 10-1.414-1.414l-.707.707a1 1 0 101.414 1.414zM17.657 19.656l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 10-1.414 1.414zM12 6a6 6 0 100 12 6 6 0 000-12z" />
            </svg>
            <!-- moon icon -->
            <svg class="swap-off h-6 w-6 text-gray-800" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
              viewBox="0 0 24 24">
              <path d="M21.752 15.002A9 9 0 1112.998 2.248a7 7 0 108.754 12.754z" />
            </svg>
          </label>

          <!-- User dropdown -->
          <Dropdown align="right" width="56">
            <template #trigger>
              <button class="btn btn-ghost btn-circle flex items-center space-x-2">
                <span>{{ page.props.auth.user.name }}</span>
                <svg class="h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                  <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 
                       1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                </svg>
              </button>
            </template>
            <template #content>
              <DropdownLink :href="route('logout')" method="post" as="button" class="justify-start">
                Log Out
              </DropdownLink>
            </template>
          </Dropdown>

          <!-- Hamburger on mobile -->
          <button @click="showingNavigationDropdown = !showingNavigationDropdown" class="btn btn-ghost lg:hidden">
            <svg class="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor"
              viewBox="0 0 24 24">
              <path v-if="!showingNavigationDropdown" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M4 6h16M4 12h16M4 18h16" />
              <path v-else stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <!-- Mobile menu -->
        <div class="lg:hidden" :class="{ block: showingNavigationDropdown, hidden: !showingNavigationDropdown }">
          <div class="space-y-1 px-2 pt-2 pb-3">
            <ResponsiveNavLink v-if="userRole === 'superadmin'" :href="route('superadmin.salons.index')"
              :active="route().current('superadmin.salons.index')">All Salons</ResponsiveNavLink>
            <ResponsiveNavLink v-if="userRole === 'superadmin'" :href="route('superadmin.users.index')"
              :active="route().current('superadmin.users.index')">Users</ResponsiveNavLink>
            <ResponsiveNavLink v-if="userRole === 'superadmin'" :href="route('superadmin.roles.index')"
              :active="route().current('superadmin.roles.*')">Roles</ResponsiveNavLink>
            <ResponsiveNavLink v-if="userRole === 'superadmin'" :href="route('superadmin.permissions.index')"
              :active="route().current('superadmin.permissions.*')">Permissions</ResponsiveNavLink>
            <ResponsiveNavLink v-if="userRole === 'superadmin'" :href="route('superadmin.packages.index')"
              :active="route().current('superadmin.packages.*')">Packages</ResponsiveNavLink>
            <ResponsiveNavLink v-if="userRole === 'superadmin'" :href="route('superadmin.subscriptions.index')"
              :active="route().current('superadmin.subscriptions.*')">Subscriptions</ResponsiveNavLink>
          </div>
        </div>
      </div>
    </nav>

    <!-- Opcioni Page Heading slot -->
    <header v-if="$slots.header" class="bg-base-100 shadow">
      <div class="container mx-auto px-4 py-4">
        <slot name="header" />
      </div>
    </header>

    <!-- Content -->
    <main class="container mx-auto px-4 py-6">
      <slot />
    </main>
  </div>
</template>
