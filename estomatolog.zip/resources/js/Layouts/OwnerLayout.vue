<template>
  <div :data-theme="isDark ? 'dark' : 'light'" class="h-screen flex flex-col">
    <!-- Mobile Header -->
    <header class="flex lg:hidden items-center justify-between h-16 px-4 bg-base-100 border-b fixed inset-x-0 z-20">
      <button @click="mobileOpen = true" class="btn btn-ghost btn-square">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      </button>
      <div class="font-bold text-lg">SalonApp</div>
      <div class="flex items-center gap-2">
        <button @click="toggleTheme" class="btn btn-ghost btn-circle">
          <span v-if="!isDark">🌞</span><span v-else>🌜</span>
        </button>
        <div class="dropdown dropdown-end">
          <label tabindex="0" class="btn btn-ghost btn-circle avatar">
            <div class="w-10 h-10 rounded-full bg-neutral-focus text-neutral-content flex items-center justify-center">
              <span v-if="!user.photo">{{ initials }}</span>
              <img v-else :src="user.photo" alt="Avatar" />
            </div>
          </label>
          <ul tabindex="0" class="mt-3 p-2 shadow menu menu-compact dropdown-content bg-base-100 rounded-box w-52">
            <li>
              <NavLink href="#">Profile</NavLink>
            </li>
            <li><button @click="logout" class="w-full text-left">Logout</button></li>
          </ul>
        </div>
      </div>
    </header>

    <!-- Desktop Header -->
    <header
      class="hidden lg:flex items-center justify-between fixed top-0 left-64 right-0 h-16 px-6 bg-base-100 border-b z-20">
      <div class="font-bold text-lg">SalonApp</div>
      <div class="flex items-center space-x-4">
        <button @click="toggleTheme" class="btn btn-ghost btn-circle">
          <span v-if="!isDark">🌞</span><span v-else>🌜</span>
        </button>
        <div class="dropdown dropdown-end">
          <label tabindex="0" class="btn btn-ghost btn-circle avatar">
            <div class="w-10 h-10 rounded-full bg-neutral-focus text-neutral-content flex items-center justify-center">
              <span v-if="!user.photo">{{ initials }}</span>
              <img v-else :src="user.photo" alt="Avatar" />
            </div>
          </label>
          <ul tabindex="0" class="mt-3 p-2 shadow menu menu-compact dropdown-content bg-base-100 rounded-box w-52">
            <li>
              <NavLink href="#">Profile</NavLink>
            </li>
            <li><button @click="logout" class="w-full text-left">Logout</button></li>
          </ul>
        </div>
      </div>
    </header>

    <div class="flex flex-1 overflow-hidden pt-16 lg:pt-0">
      <!-- Desktop Sidebar -->
      <aside class="hidden lg:flex flex-col w-64 bg-base-100 border-r fixed top-16 bottom-0">
        <nav class="flex-1 overflow-y-auto p-4 space-y-1">
          <ul class="menu w-full">
            <!-- Dashboard -->
            <li :class="getSidebarClass('dashboard.view')">
              <NavLink :href="getNavHref('dashboard.view', route('owner.dashboard'))" class="flex items-center gap-3"
                :tabindex="getTab('dashboard.view')" :aria-disabled="isLocked('dashboard.view')">
                <span v-html="icons.home" />
                Dashboard
                <span v-if="isLocked('dashboard.view')" class="ml-2" title="Nemate dozvolu">🔒</span>
              </NavLink>
            </li>
            <!-- Categories -->
            <li>
              <NavLink :href="route('owner.service-categories.index')" class="flex items-center gap-3"
                :class="{ 'active': route().current('owner.service-categories.*') }">
                <span v-html="icons.scissors" />Categories
              </NavLink>
            </li>
            <!-- Services -->
            <li :class="getSidebarClass('services.view')">
              <NavLink :href="getNavHref('services.view', route('owner.services.index'))"
                class="flex items-center gap-3" :tabindex="getTab('services.view')"
                :aria-disabled="isLocked('services.view')">
                <span v-html="icons.fileText" />
                Services
                <span v-if="isLocked('services.view')" class="ml-2" title="Nemate dozvolu">🔒</span>
              </NavLink>
            </li>
            <!-- Employees -->
            <li :class="getSidebarClass('employees.view')">
              <NavLink :href="getNavHref('employees.view', route('owner.employees.index'))"
                class="flex items-center gap-3" :tabindex="getTab('employees.view')"
                :aria-disabled="isLocked('employees.view')">
                <span v-html="icons.users" />
                Employees
                <span v-if="isLocked('employees.view')" class="ml-2" title="Nemate dozvolu">🔒</span>
              </NavLink>
            </li>
            <!-- Appointments -->
            <li :class="getSidebarClass('appointments.view')">
              <NavLink :href="getNavHref('appointments.view', route('owner.appointments.index'))"
                class="flex items-center gap-3" :tabindex="getTab('appointments.view')"
                :aria-disabled="isLocked('appointments.view')">
                <span v-html="icons.calendar" />
                Appointments
                <span v-if="isLocked('appointments.view')" class="ml-2" title="Nemate dozvolu">🔒</span>
              </NavLink>
            </li>
            <!-- Work Times -->
            <li :class="getSidebarClass('worktime.view')">
              <NavLink :href="getNavHref('worktime.view', route('owner.worktimes.index'))"
                class="flex items-center gap-3" :tabindex="getTab('worktime.view')"
                :aria-disabled="isLocked('worktime.view')">
                <span v-html="icons.clock" />
                Work Times
                <span v-if="isLocked('worktime.view')" class="ml-2" title="Nemate dozvolu">🔒</span>
              </NavLink>
            </li>
            <!-- Design -->
            <li :class="getSidebarClass('design.view', 'files')">
              <NavLink :href="getNavHref('design.view', route('owner.design.edit'), 'files')"
                class="flex items-center gap-3" :tabindex="getTab('design.view', 'files')"
                :aria-disabled="isLocked('design.view', 'files')">
                <span v-html="icons.palette" />
                Design
                <span v-if="isLocked('design.view', 'files')" class="ml-2"
                  title="Dostupno samo u Standard/Premium paketu">🔒</span>
              </NavLink>
            </li>
            <!-- Salon Settings -->
            <li :class="getSidebarClass('settings.manage')">
              <NavLink :href="getNavHref('settings.manage', route('owner.settings.roles.index'))"
                class="flex items-center gap-3" :tabindex="getTab('settings.manage')"
                :aria-disabled="isLocked('settings.manage')">
                <span v-html="icons.settings" />
                Salon Settings
                <span v-if="isLocked('settings.manage')" class="ml-2" title="Nemate dozvolu">🔒</span>
              </NavLink>
            </li>

            <!-- Pages -->
            <li :class="getSidebarClass('pages.view', 'files')">
              <NavLink :href="getNavHref('pages.view', route('owner.pages.index'), 'files')"
                class="flex items-center gap-3" :tabindex="getTab('pages.view', 'files')"
                :aria-disabled="isLocked('pages.view', 'files')">
                <span v-html="icons.book" />
                Pages
                <span v-if="isLocked('pages.view', 'files')" class="ml-2" title="Samo za Standard/Premium">🔒</span>
              </NavLink>
            </li>
            <!-- Galleries -->
            <li :class="getSidebarClass('galleries.view', 'files')">
              <NavLink :href="getNavHref('galleries.view', route('owner.galleries.index'), 'files')"
                class="flex items-center gap-3" :tabindex="getTab('galleries.view', 'files')"
                :aria-disabled="isLocked('galleries.view', 'files')">
                <span v-html="icons.image" />
                Galleries
                <span v-if="isLocked('galleries.view', 'files')" class="ml-2" title="Samo za Standard/Premium">🔒</span>
              </NavLink>
            </li>
            <!-- Marketing -->
            <li :class="getSidebarClass('marketing.manage', 'premium')">
              <NavLink :href="getNavHref('marketing.manage', route('owner.marketing.email.form'), 'premium')"
                class="flex items-center gap-3" :tabindex="getTab('marketing.manage', 'premium')"
                :aria-disabled="isLocked('marketing.manage', 'premium')">
                <span v-html="icons.mail" />
                Marketing
                <span v-if="isLocked('marketing.manage', 'premium')" class="ml-2" title="Samo za Premium">🔒</span>
              </NavLink>
            </li>
            <!-- Users -->
            <li :class="getSidebarClass('users.view')">
              <NavLink :href="getNavHref('users.view', route('owner.users.index'))" class="flex items-center gap-3"
                :tabindex="getTab('users.view')" :aria-disabled="isLocked('users.view')">
                <span v-html="icons.user" />
                Users
                <span v-if="isLocked('users.view')" class="ml-2" title="Nemate dozvolu">🔒</span>
              </NavLink>
            </li>
            <!-- Subscription -->
            <li :class="getSidebarClass('subscription.view')">
              <NavLink :href="getNavHref('subscription.view', route('owner.subscription.index'))"
                class="flex items-center gap-3" :tabindex="getTab('subscription.view')"
                :aria-disabled="isLocked('subscription.view')">
                <span v-html="icons.creditCard" />
                Subscription
                <span v-if="isLocked('subscription.view')" class="ml-2" title="Nemate dozvolu">🔒</span>
              </NavLink>
            </li>
          </ul>
        </nav>
      </aside>

      <!-- Content -->
      <main class="flex-1 overflow-y-auto bg-base-200 p-4 mt-16 lg:mt-0 ml-0 lg:ml-64">
        <slot />
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { usePage, router } from '@inertiajs/vue3'
import NavLink from '@/Components/NavLink.vue'
import { useToast } from 'vue-toastification'
import { watch } from 'vue'

const toast = useToast()
const page = usePage()
watch(() => page.props.flash, flash => {
  if (flash?.success) toast.success(flash.success)
  if (flash?.error) toast.error(flash.error)
}, { immediate: true })
watch(() => page.props.errors, errors => {
  if (!errors) return
  Object.values(errors).flat().forEach(msg => toast.error(msg))
}, { immediate: true })

const isDark = ref(false)
onMounted(() => {
  isDark.value = localStorage.getItem('theme') === 'dark'
})
function toggleTheme() {
  isDark.value = !isDark.value
  localStorage.setItem('theme', isDark.value ? 'dark' : 'light')
}
const mobileOpen = ref(false)

const { auth, permissions, package_code } = usePage().props
const user = auth.user || {}
const initials = computed(() =>
  (user.name || '').split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()
)
function logout() {
  router.post(route('logout'))
}
function hasFeature(feature) {
  if (feature === 'premium') return package_code === 'premium'
  if (feature === 'files') return ['standard', 'premium'].includes(package_code)
  return false
}
function isLocked(permission, feature = null) {
  if (feature === 'premium' && !hasFeature('premium')) return true
  if (feature === 'files' && !hasFeature('files')) return true
  if (!permissions.includes(permission)) return true
  return false
}
function getSidebarClass(permission, feature = null) {
  return isLocked(permission, feature) ? 'opacity-50 pointer-events-none' : ''
}
function getNavHref(permission, href, feature = null) {
  return isLocked(permission, feature) ? '#' : href
}
function getTab(permission, feature = null) {
  return isLocked(permission, feature) ? -1 : 0
}
const icons = {
  home: `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 12l9-9 9 9M4 10v10a1 1 0 001 1h3a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1h3a1 1 0 001-1V10"></path></svg>`,
  scissors: `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/></svg>`,
  fileText: `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 17v-6a2 2 0 012-2h4a2 2 0 012 2v6"/><path d="M9 5v2a2 2 0 002 2h4a2 2 0 002-2V5"/></svg>`,
  users: `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M17 20h5v-2a4 4 0 00-3-3.87"/><path d="M9 20H4v-2a4 4 0 013-3.87"/><circle cx="9" cy="7" r="4"/><circle cx="17" cy="7" r="4"/></svg>`,
  calendar: `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>`,
  clock: `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,
  palette: `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="7" r="1"/><circle cx="7" cy="12" r="1"/><circle cx="17" cy="12" r="1"/><circle cx="12" cy="17" r="1"/></svg>`,
  settings: `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 01-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09a1.65 1.65 0 00-1-1.51 1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82z"/></svg>`,
  user: `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="7" r="4"/><path d="M5.5 21a7.5 7.5 0 0113 0"/></svg>`,
  creditCard: `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/></svg>`,
  package: `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="7" width="18" height="13" rx="2"/><path d="M16 3v4M8 3v4"/></svg>`,
  truck: `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="1" y="3" width="15" height="13" rx="2"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/></svg>`,
  mail: `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><polyline points="3 7 12 13 21 7"/></svg>`,
  book: `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 19V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14M7 19a2 2 0 01-2-2V5m2 14V5a2 2 0 012-2h10a2 2 0 012 2v14"/></svg>`,
  image: `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>`,
  briefcase: `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 3v4M8 3v4"/></svg>`,
  award: `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 21 12 18 17 21 15.79 13.88"/></svg>`,
  tool: `<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M14.7 13.29a1 1 0 00-1.42 0l-8.3 8.29a2 2 0 002.83 2.83l8.29-8.29a1 1 0 000-1.42z"/><path d="M14 8a6 6 0 00-8.48 8.48"/></svg>`,
}
</script>
