<template>
  <Layout :salonSlug="salonSlug" :salon="salon" :currentRoute="salon.currentRoute">
    <div class="py-12">
      <div class="max-w-6xl mx-auto px-4 space-y-8">
        <!-- Next Appointment -->
        <div v-if="nextAppointment" class="space-y-4">
          <h2 class="text-3xl font-bold">Sledeći termin</h2>
          <div class="card card-side bg-base-200 shadow-lg rounded-lg overflow-hidden">
            <figure class="w-32">
              <img :src="getServiceImage(nextAppointment)" alt="Service" class="object-cover h-full w-full" />
            </figure>
            <div class="card-body">
              <h3 class="card-title">{{ nextAppointment.services[0]?.name }}</h3>
              <p class="text-sm text-gray-600">
                {{ formatDateTime(nextAppointment.date, nextAppointment.start_time) }}
                sa {{ nextAppointment.employeeName }}
              </p>
              <div class="flex items-baseline space-x-2 mt-4">
                <span class="text-4xl font-mono">{{ countdown }}</span>
                <span class="text-sm">preostalo</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Tabs -->
        <div class="tabs">
          <a class="tab tab-lg" :class="{ 'tab-active': activeTab === 'upcoming' }" @click="activeTab = 'upcoming'">
            Budući termini
          </a>
          <a class="tab tab-lg" :class="{ 'tab-active': activeTab === 'past' }" @click="activeTab = 'past'">
            Prošli termini
          </a>
        </div>

        <!-- Upcoming -->
        <div v-if="activeTab === 'upcoming'">
          <div v-if="upcomingAppointments.length === 0" class="text-center text-gray-500 py-8">
            Trenutno nema budućih termina.
          </div>
          <div v-else class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div v-for="appointmentsId in upcomingAppointments" :key="appointmentsId.id"
              class="card bg-base-100 shadow-md rounded-lg overflow-hidden hover:shadow-xl transition">
              <figure>
                <img :src="getServiceImage(appointmentsId)" alt="Service" class="h-40 w-full object-cover" />
              </figure>
              <div class="card-body">
                <h4 class="font-semibold text-lg">{{ appointmentsId.services[0]?.name }}</h4>
                <p class="text-sm text-gray-600">
                  {{ formatDateTime(appointmentsId.date, appointmentsId.start_time) }}
                </p>
                <p class="text-sm text-gray-600">Zaposleni: {{ appointmentsId.employeeName }}</p>
                <div class="card-actions justify-end mt-4 space-x-2">
                  <button v-if="appointmentsId.status === 'pending'"
                    @click="confirmAppointment(appointmentsId.id, salonSlug)" :disabled="processing"
                    class="btn btn-sm bg-green-600 text-white hover:bg-green-700">
                    Potvrdi
                  </button>
                  <button @click="cancelAppointment(salonSlug, appointmentsId)" :disabled="processing"
                    class="btn btn-sm btn-outline text-red-600 border-red-600 hover:bg-red-50">
                    Otkaži
                  </button>
                  <button @click="openDetails(appointmentsId)" class="btn btn-sm btn-outline btn-primary">
                    Detalji
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Past -->
        <div v-else>
          <div v-if="pastAppointments.length === 0" class="text-center text-gray-500 py-8">
            Nema prošlih termina.
          </div>
          <div v-else class="space-y-4">
            <div v-for="appt in pastAppointments" :key="appt.id"
              class="collapse collapse-arrow border border-base-300 bg-base-100 rounded-lg">
              <input type="checkbox" />
              <div class="collapse-title flex items-center space-x-4">
                <img :src="getServiceImage(appt)" alt="Service" class="w-12 h-12 object-cover rounded" />
                <div>
                  <div class="font-medium">{{ appt.services[0]?.name }}</div>
                  <div class="text-sm text-gray-400">
                    {{ formatDateTime(appt.date, appt.start_time) }} sa
                    {{ appt.employeeName }}
                  </div>
                </div>
              </div>
              <div class="collapse-content">
                <ul class="mt-2 space-y-2">
                  <li v-for="svc in appt.services" :key="svc.id" class="flex items-center space-x-3">
                    <img :src="svc.image_url || placeholder" alt="" class="w-10 h-10 object-cover rounded" />
                    <div>
                      <p class="font-medium">{{ svc.name }}</p>
                      <p class="text-xs text-gray-500">
                        {{ svc.duration }} min | {{ svc.price }}€
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Details Modal -->
      <transition name="fade">
        <div v-if="showModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div class="bg-base-100 rounded-lg shadow-xl w-11/12 md:w-2/3 lg:w-1/2 overflow-hidden">
            <div class="px-6 py-4 border-b flex justify-between items-center">
              <h3 class="text-lg font-semibold">Detalji termina</h3>
              <button @click="closeModal" class="btn btn-sm btn-circle">✕</button>
            </div>
            <div class="p-6 space-y-4">
              <p>
                <span class="font-semibold">Datum i vreme:</span>
                {{ formatDateTime(selectedAppointment.date, selectedAppointment.start_time) }}
              </p>
              <p>
                <span class="font-semibold">Zaposleni:</span>
                {{ selectedAppointment.employeeName }}
              </p>
              <div>
                <span class="font-semibold">Usluge:</span>
                <ul class="menu bg-base-200 p-4 rounded-box space-y-3">
                  <li v-for="svc in selectedAppointment.services" :key="svc.id" class="flex items-center space-x-3">
                    <img :src="svc.image_url || placeholder" alt="" class="w-12 h-12 object-cover rounded" />
                    <div>
                      <div class="font-medium">{{ svc.name }}</div>
                      <div class="text-sm text-gray-600">
                        Cena: {{ svc.price }}€
                      </div>
                      <div class="text-sm text-gray-600">
                        Trajanje: {{ svc.duration }} min
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            <div class="px-6 py-4 border-t text-right">
              <button @click="closeModal" class="btn btn-outline">Zatvori</button>
            </div>
          </div>
        </div>
      </transition>
    </div>
  </Layout>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useForm, usePage } from '@inertiajs/vue3'
import Layout from '@/Pages/Public/Layout.vue'

const page = usePage()
const { salon, appointments, salonSlug } = page.props

const list = computed(() => appointments.data || [])
const now = new Date()
const sorted = computed(() =>
  [...list.value].sort((a, b) =>
    new Date(a.date + ' ' + a.start_time) - new Date(b.date + ' ' + b.start_time)
  )
)
const upcomingAll = computed(() =>
  sorted.value.filter(a => new Date(a.date + ' ' + a.start_time) >= now)
)
const pastAppointments = computed(() =>
  sorted.value.filter(a => new Date(a.date + ' ' + a.start_time) < now)
)
const nextAppointment = computed(() =>
  upcomingAll.value.length ? upcomingAll.value[0] : null
)
const upcomingAppointments = computed(() =>
  upcomingAll.value.slice(1)
)
console.log(salonSlug)
// form + processing
const form = useForm()
const processing = ref(false)

// countdown
const countdown = ref('')
let intervalId = null
function updateCountdown() {
  if (!nextAppointment.value) return
  const target = new Date(nextAppointment.value.date + ' ' + nextAppointment.value.start_time)
  const diff = target - new Date()
  if (diff <= 0) {
    countdown.value = '00:00:00'
    clearInterval(intervalId)
    return
  }
  const h = Math.floor(diff / 1000 / 60 / 60)
  const m = Math.floor((diff / 1000 / 60) % 60)
  const s = Math.floor((diff / 1000) % 60)
  countdown.value = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
}
onMounted(() => {
  updateCountdown()
  intervalId = setInterval(updateCountdown, 1000)
})
onUnmounted(() => clearInterval(intervalId))

function formatDateTime(date, time) {
  const d = new Date(date)
  const opts = { year: 'numeric', month: 'long', day: 'numeric' }
  return d.toLocaleDateString(undefined, opts) + ' u ' + time
}

function getServiceImage(appt) {
  return appt.services?.[0]?.image_url || placeholder
}

// modal
const showModal = ref(false)
const selectedAppointment = ref({})
function openDetails(a) {
  selectedAppointment.value = a
  showModal.value = true
}
function closeModal() {
  showModal.value = false
  selectedAppointment.value = {}
}

// actions
function confirmAppointment(appointmentId, salonSlug) {
  console.log(appointmentId, salonSlug)
  processing.value = true
  form.put(route('booking.confirm.status', { salonSlug, appointmentId }), {
    onFinish: () => (processing.value = false)
  })
}
function cancelAppointment(salonSlug, appointmentId) {
  console.log(appointmentId, salonSlug)
  processing.value = true
  form.put(
    route('client.appointment.cancel', {
      salonSlug: salonSlug,
      appointmentId: appointmentId,
    }), {
    onFinish: () => (processing.value = false)
  })
}

const activeTab = ref('upcoming')
const placeholder = 'https://via.placeholder.com/96'
</script>

<style scoped>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
