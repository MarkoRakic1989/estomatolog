<template>
  <Layout :salonSlug="salonSlug" :salon="salon" :currentRoute="currentRoute">
    <section class="py-16 bg-base-200">
      <div class="max-w-4xl mx-auto px-4">
        <!-- Invoice Card -->
        <div class="card bg-base-100 shadow-lg p-6">
          <!-- Header -->
          <div class="flex justify-between items-center mb-8">
            <h2 class="text-2xl font-bold" :style="{ color: salon.secondary_color }">
              Booking Confirmation
            </h2>
            <span class="text-sm text-gray-500">
              Appointment #{{ appointmentId }}
            </span>
          </div>

          <!-- Services Table -->
          <div class="overflow-x-auto mb-6">
            <table class="table w-full">
              <thead>
                <tr class="bg-base-200">
                  <th>Service</th>
                  <th>Duration</th>
                  <th>Price</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="svc in selectedServicesDetails" :key="svc.id">
                  <td class="flex items-center space-x-4">
                    <img :src="svc.image_url || placeholder" alt="" class="w-12 h-12 object-cover rounded" />
                    <span class="font-medium">{{ svc.name }}</span>
                  </td>
                  <td>{{ svc.duration }} min</td>
                  <td>\${{ parseFloat(svc.price).toFixed(2) }}</td>
                </tr>
              </tbody>
            </table>
          </div>

          <!-- Employee & Schedule -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div class="flex items-center space-x-4">
              <img :src="selectedEmployee.photo_url || placeholder" alt="" class="w-16 h-16 object-cover rounded" />
              <div>
                <h3 class="font-semibold">Employee</h3>
                <p class="text-gray-700">{{ selectedEmployee.name }}</p>
              </div>
            </div>
            <div>
              <h3 class="font-semibold">Schedule</h3>
              <p class="text-gray-700">
                {{ formatDate(selectedDate) }} at {{ selectedSlot }}
              </p>
            </div>
          </div>

          <!-- Total -->
          <div class="flex justify-end mb-6">
            <div class="space-y-1 text-right">
              <div class="flex justify-between">
                <span>Subtotal:</span>
                <span>\${{ subtotal.toFixed(2) }}</span>
              </div>
              <div class="flex justify-between font-bold text-lg" :style="{ color: salon.secondary_color }">
                <span>Total:</span>
                <span>\${{ subtotal.toFixed(2) }}</span>
              </div>
            </div>
          </div>

          <!-- Confirm Button -->
          <div class="text-center">
            <button @click="confirmBooking" class="btn px-8 py-3 rounded-full text-lg font-semibold"
              :style="{ backgroundColor: salon.secondary_color, color: salon.primary_color }"
              :disabled="form.processing">
              <span v-if="!form.processing">Confirm & Book</span>
              <span v-else>Booking...</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  </Layout>
</template>

<script setup>
import { computed } from 'vue'
import { useForm } from '@inertiajs/vue3'
import Layout from '@/Pages/Public/Layout.vue'

const props = defineProps({
  salonSlug: String,
  salon: Object,
  appointmentId: Number,
  selectedServices: Array,
  servicesAll: Array,
  currentRoute: String,
  selectedEmployee: Object,
  selectedDate: String,
  selectedSlot: String,
})

const {
  salonSlug,
  salon,
  appointmentId,
  selectedServices,
  servicesAll,
  selectedEmployee,
  selectedDate,
  selectedSlot,
  currentRoute,
} = props

// Prepare services details
const selectedServicesDetails = computed(() =>
  servicesAll.filter((svc) => selectedServices.includes(svc.id))
)

// Calculate subtotal
const subtotal = computed(() =>
  selectedServicesDetails.value.reduce((sum, svc) => {
    return sum + parseFloat(svc.price)
  }, 0)
)

const form = useForm({})

function formatDate(dateString) {
  const d = new Date(dateString)
  return d.toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  })
}
console.log(salonSlug)
function confirmBooking() {
  form.patch(
    route('booking.confirm.status', {
      salonSlug,
      appointmentId,
    })
  )
}

const placeholder = 'https://via.placeholder.com/96'
</script>

<style scoped>
/* No additional styles needed */
</style>
