<template>
  <Layout :salonSlug="salonSlug" :salon="salon" :currentRoute="currentRoute">
    <section class="py-16 bg-base-200">
      <div class="max-w-4xl mx-auto px-4">
        <!-- Заглавље -->
        <h2 class="text-4xl font-bold text-center mb-6" :style="{ color: salon.secondary_color }">
          Choose Your Services
        </h2>
        <p class="text-center text-gray-400 mb-10">
          Select which services you want to book. You can pick more than one.
        </p>

        <form @submit.prevent="submitStep1" class="space-y-8">
          <!-- Services grid: 1 / 2 / 3 columns -->
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <label v-for="service in services" :key="service.id" class="relative cursor-pointer">
              <!-- Hidden checkbox to hold state -->
              <input type="checkbox" v-model="form.service_ids" :value="service.id" class="peer hidden" />

              <!-- Checkmark circle, only visible when checked -->
              <span
                class="indicator-item absolute top-4 right-4 hidden peer-checked:flex items-center justify-center bg-primary text-primary-content w-8 h-8 rounded-full z-10">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" stroke="currentColor"
                  stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              </span>

              <!-- Card -->
              <div class="card w-full bg-base-100 border-2 shadow" :class="form.service_ids.includes(service.id)
                ? 'border-primary'
                : 'border-base-200'" style="min-height: 20rem;">
                <!-- Image full width -->
                <div class="h-40 bg-base-300 animate-pulse"></div>

                <!-- Content -->
                <div class="p-6 flex flex-col h-full">
                  <h3 class="text-xl font-semibold mb-2">{{ service.name }}</h3>
                  <p class="text-sm text-gray-500 mb-4 line-clamp-3">
                    {{ service.description }}
                  </p>
                  <div class="mt-auto">
                    <span class="badge badge-outline text-lg font-semibold" :style="{
                      borderColor: salon.secondary_color,
                      color: salon.secondary_color
                    }">
                      ${{ service.price }}
                    </span>
                  </div>
                </div>
              </div>
            </label>
          </div>

          <!-- Validation error -->
          <p v-if="form.errors.service_ids" class="text-red-600 text-center text-sm">
            {{ form.errors.service_ids }}
          </p>

          <!-- Submit button -->
          <div class="text-center">
            <button type="submit" class="btn px-8 py-3 rounded-full text-lg font-semibold"
              :style="{ backgroundColor: salon.secondary_color, color: salon.primary_color }"
              :disabled="form.processing || form.service_ids.length === 0">
              <span v-if="!form.processing">Next: Choose Employee</span>
              <span v-else>Loading...</span>
            </button>
          </div>
        </form>
      </div>
    </section>
  </Layout>
</template>

<script setup>
import { useForm } from '@inertiajs/vue3'
import Layout from '@/Pages/Public/Layout.vue'

const props = defineProps({
  salonSlug: String,
  salon: Object,
  services: Array,
  currentRoute: String,
  selectedServices: Array,
})

console.log(props.selectedServices)
const form = useForm({
  service_ids: props.selectedServices,
})

function submitStep1() {
  form.post(route('booking.step2', { salonSlug: props.salonSlug }), {
    preserveState: true,
  })
}
</script>

<style scoped>
.line-clamp-3 {
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
</style>
