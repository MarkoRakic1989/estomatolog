<template>
  <Layout :salonSlug="salonSlug" :salon="salon" :currentRoute="currentRoute">
    <section class="py-16 bg-base-200">
      <div class="max-w-4xl mx-auto px-4">
        <!-- Header -->
        <h2 class="text-4xl font-bold text-center mb-6" :style="{ color: salon.secondary_color }">
          Choose Your Employee
        </h2>
        <p class="text-center text-gray-400 mb-10">
          Select one employee to proceed.
        </p>

        <!-- Employees grid: 2 columns -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <label v-for="emp in employees" :key="emp.id" class="relative cursor-pointer">
            <!-- hidden radio to hold state -->
            <input type="radio" class="peer hidden" v-model="selectedEmployeeId" :value="emp.id" />

            <!-- check icon, only when selected -->
            <span
              class="indicator-item absolute top-4 right-4 hidden peer-checked:flex items-center justify-center bg-primary text-primary-content w-8 h-8 rounded-full z-10">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2"
                viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
              </svg>
            </span>

            <!-- card -->
            <div class="card bg-base-100 border-2 shadow transition" :class="{
              'border-primary shadow-lg': selectedEmployeeId === emp.id,
              'border-base-200': selectedEmployeeId !== emp.id
            }">
              <div class="flex items-center p-6">
                <!-- employee image -->
                <img :src="emp.photo_url || placeholder" alt="" class="w-24 h-24 object-cover rounded-md" />
                <div class="ml-6 flex-1 text-left">
                  <h3 class="text-xl font-semibold">{{ emp.name }}</h3>
                  <p class="text-sm text-gray-500 mt-1">
                    Services: {{ emp.service_names.join(', ') }}
                  </p>
                </div>
              </div>
            </div>
          </label>
        </div>

        <p v-if="error" class="text-red-600 text-center mb-4">{{ error }}</p>

        <!-- Navigation buttons -->
        <div class="flex justify-between">
          <Link :href="route('booking.step1', { salonSlug })" class="px-6 py-3 rounded-md font-medium border"
            :style="{ color: salon.secondary_color, borderColor: salon.secondary_color }">
          Back: Services
          </Link>
          <button @click="goToStep3" class="px-6 py-3 rounded-md font-semibold shadow"
            :style="{ backgroundColor: salon.secondary_color, color: salon.primary_color }"
            :disabled="!selectedEmployeeId">
            Next: Select Date & Time
          </button>
        </div>
      </div>
    </section>
  </Layout>
</template>

<script setup>
import { ref } from 'vue'
import { Link, router } from '@inertiajs/vue3'
import Layout from '@/Pages/Public/Layout.vue'

const props = defineProps({
  salonSlug: String,
  salon: Object,
  currentRoute: String,
  selectedServices: Array,
  employees: Array,
})

const { salonSlug, salon, employees } = props

const selectedEmployeeId = ref(null)
const error = ref(null)
const placeholder = 'https://via.placeholder.com/96'
console.log(props.selectedServices)
function goToStep3() {
  if (!selectedEmployeeId.value) {
    error.value = 'Please select an employee.'
    return
  }

  router.get(
    route('booking.step3.form', { salonSlug }),
    {
      service_ids: props.selectedServices,
      employee_id: selectedEmployeeId.value,
    },
    {
      preserveState: true,
      preserveScroll: true,
    }
  )
}
</script>

<style scoped></style>
