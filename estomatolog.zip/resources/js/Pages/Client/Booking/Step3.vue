<template>
  <Layout :salonSlug="salonSlug" :salon="salon" :currentRoute="currentRoute">
    <section class="py-16 bg-base-200">
      <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Header -->
        <h2 class="text-3xl font-bold text-center mb-6" :style="{ color: salon.secondary_color }">
          Choose Date & Time
        </h2>

        <!-- Date Swiper -->
        <Swiper :modules="[Scrollbar]" :slides-per-view="7"
          :breakpoints="{ 0: { slidesPerView: 3 }, 640: { slidesPerView: 5 }, 1024: { slidesPerView: 5 } }" scrollbar
          space-between="16" class="mb-8">
          <SwiperSlide v-for="date in availableDates" class="min-w-[200px]" :key="date">
            <label class="indicator flex items-center cursor-pointer min-w-[200px]">
              <!-- hidden radio to bind -->
              <input type="radio" class="peer sr-only" v-model="selectedDate" :value="date" @change="loadSlots" />
              <!-- check badge -->
              <span
                class="indicator-item absolute top-4 right-4 hidden peer-checked:flex items-center justify-center bg-primary text-primary-content w-4 h-4 rounded-full z-10">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" stroke="currentColor"
                  stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              </span>
              <!-- card -->
              <div class="card card-compact bg-base-100 border-2  min-w-[200px] p-6 text-center transition" :class="selectedDate === date
                ? 'border-primary'
                : 'border-base-200'">
                <div class="font-medium">{{ formatDate(date) }}</div>
              </div>
            </label>
          </SwiperSlide>
        </Swiper>

        <!-- Time Slots -->
        <div v-if="availableSlots.length" class="mb-8">
          <h3 class="text-lg font-medium mb-4" :style="{ color: salon.secondary_color }">
            Select Time Slot
          </h3>
          <div class="grid grid-cols-4 sm:grid-cols-6 gap-6">
            <label v-for="slot in availableSlots" :key="slot" class="indicator cursor-pointer">
              <input type="radio" class="peer sr-only" v-model="selectedSlot" :value="slot" />
              <span
                class="indicator-item absolute top-4 right-4 hidden peer-checked:flex items-center justify-center bg-primary text-primary-content w-4 h-4 rounded-full z-10">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" stroke="currentColor"
                  stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              </span>
              <div class="card card-compact bg-base-100 border-2 text-center transition
           min-w-[100px]
           w-full            <!-- dodaj ovo -->
           py-4              <!-- horizontalni padding gore-dole -->
           flex items-center justify-center  <!-- centriranje teksta -->
          " :class="{
            'border-primary': selectedSlot === slot,
            'border-base-200': selectedSlot !== slot
          }">
                {{ slot }}
              </div>
            </label>
          </div>
        </div>

        <!-- Validation errors -->
        <p v-if="form.errors.date || form.errors.start_time" class="text-red-600 text-center mb-4">
          {{ form.errors.date || form.errors.start_time }}
        </p>

        <!-- Navigation Buttons -->
        <div class="flex justify-between">
          <Link :href="route('booking.step2', { salonSlug })" class="btn btn-outline"
            :style="{ borderColor: salon.secondary_color, color: salon.secondary_color }">
          Back: Employee
          </Link>
          <button @click="submitStep3" class="btn"
            :style="{ backgroundColor: salon.secondary_color, color: salon.primary_color }"
            :disabled="form.processing || !selectedDate || !selectedSlot">
            <span v-if="!form.processing">Next: Confirm</span>
            <span v-else>Loading...</span>
          </button>
        </div>
      </div>
    </section>
  </Layout>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { Link, useForm } from '@inertiajs/vue3'
import { Swiper, SwiperSlide } from 'swiper/vue'
import { Scrollbar } from 'swiper/modules';
import 'swiper/css'
import 'swiper/css/scrollbar'
import Layout from '@/Pages/Public/Layout.vue'

const props = defineProps({
  salonSlug: String,
  salon: Object,
  currentRoute: String,
  selectedServices: Array,
  selectedEmployee: Object,
  availableDates: Array,
  availableSlots: Array,
})

const { salonSlug, salon, selectedServices, selectedEmployee, currentRoute } = props
console.log(currentRoute)
// reactive state
const availableDates = ref(props.availableDates || [])
const availableSlots = ref(props.availableSlots || [])
const selectedDate = ref(availableDates.value[0] || '')
const selectedSlot = ref('')

// form for submission
const form = useForm({
  service_ids: selectedServices,
  employee_id: selectedEmployee.id,
  date: '',
  start_time: '',
})

// format date
function formatDate(dateString) {
  const d = new Date(dateString)
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })
}

// load slots when date changes
async function loadSlots() {
  if (!selectedDate.value) return
  try {
    const res = await fetch(route('api.calendar.slots', {
      salonSlug,
      employee_id: selectedEmployee.id,
      service_ids: selectedServices,
      date: selectedDate.value,
    }))
    const json = await res.json()
    availableSlots.value = json.slots || []
    selectedSlot.value = ''
  } catch {
    availableSlots.value = []
    selectedSlot.value = ''
  }
}

onMounted(() => {
  if (selectedDate.value) loadSlots()
})

console.log(props.selectedServices)
// submit to confirm
function submitStep3() {
  form.date = selectedDate.value
  form.start_time = selectedSlot.value
  form.post(route('booking.confirm', { salonSlug }), { preserveState: false })
}
</script>

<style scoped>
/* no extra custom styles needed */
</style>
