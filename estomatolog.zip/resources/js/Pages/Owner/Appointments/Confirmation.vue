<template>
    <OwnerLayout>
        <div class="container mx-auto px-4 pt-20">
            <div class="card bg-green-50 shadow p-6 max-w-md mx-auto">
                <h2 class="text-2xl font-bold text-green-700 mb-4">Uspešno zakazano!</h2>
                <p><strong>ID:</strong> {{ appt.id }}</p>
                <p><strong>Korisnik:</strong> {{ appt.user.name }}</p>
                <p><strong>Datum:</strong> {{ appt.date }}</p>
                <p><strong>Vreme:</strong> {{ appt.start_time }} – {{ appt.end_time }}</p>
                <Link :href="route('owner.appointments.index')" class="btn btn-ghost w-full mt-6">
                Nazad na listu
                </Link>
            </div>
        </div>
    </OwnerLayout>
</template>

<script setup>
import { usePage } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'

const { appointment: appt } = usePage().props
</script>
