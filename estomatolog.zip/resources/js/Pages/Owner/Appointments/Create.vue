<template>
  <OwnerLayout>

    <Head title="Novi termin – Korak 1: Klijent" />

    <div class="container mx-auto px-4 pt-20">
      <div class="card bg-base-100 shadow-lg p-6 max-w-md mx-auto">
        <h2 class="text-2xl font-bold mb-4">1. Pronađi ili kreiraj klijenta</h2>

        <!-- Input za pretragu -->
        <div class="form-control mb-4">
          <label class="label"><span class="label-text">Email ili telefon</span></label>
          <input v-model="query" @input="onSearch" type="text" placeholder="Počni da kucaš..."
            class="input input-bordered w-full" />
        </div>

        <!-- Predlozi iz servera -->
        <div v-if="suggestions.length" class="space-y-2 mb-4">
          <div v-for="u in suggestions" :key="u.id" @click="selectUser(u)"
            class="card bg-base-200 shadow p-3 cursor-pointer hover:bg-base-300">
            <p class="font-semibold">{{ u.name }}</p>
            <p class="text-sm">{{ u.email }} / {{ u.phone }}</p>
          </div>
        </div>

        <!-- Ako nema predloga i query >=3 -->
        <div v-else-if="query.length >= 3" class="mb-4">
          <p class="text-error">Korisnik nije pronađen. Popuni dole za kreiranje:</p>
        </div>

        <!-- Forma za kreiranje novog -->
        <form v-if="query.length >= 3 && !suggestions.length" @submit.prevent="createUser" class="space-y-4">
          <div class="form-control">
            <label class="label"><span class="label-text">Ime i prezime</span></label>
            <input v-model="form.name" type="text" class="input input-bordered w-full" />
            <p v-if="form.errors.name" class="text-error text-sm">{{ form.errors.name }}</p>
          </div>

          <div class="form-control">
            <label class="label"><span class="label-text">Email</span></label>
            <input v-model="form.email" type="email" class="input input-bordered w-full" />
            <p v-if="form.errors.email" class="text-error text-sm">{{ form.errors.email }}</p>
          </div>

          <div class="form-control">
            <label class="label"><span class="label-text">Telefon</span></label>
            <input v-model="form.phone" type="text" class="input input-bordered w-full" />
            <p v-if="form.errors.phone" class="text-error text-sm">{{ form.errors.phone }}</p>
          </div>

          <button type="submit" class="btn btn-primary w-full" :disabled="form.processing">
            {{ form.processing ? 'Kreiram...' : 'Kreiraj i nastavi' }}
          </button>
        </form>
      </div>
    </div>
  </OwnerLayout>
</template>

<script setup>
import { ref, watch } from 'vue'
import { useForm, usePage, router, Head } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'

const page = usePage()
const { suggestions: initialSuggestions, query: initialQuery } = page.props

// reaktivni query i suggestions iz propsa
const query = ref(initialQuery || '')
const suggestions = ref(initialSuggestions || [])

// Inertia form za kreiranje usera
const form = useForm({
  query: query.value,
  name: '',
  email: '',
  phone: '',
})

// kad se query menja, radi GET na isti endpoint
let timer
function onSearch() {
  clearTimeout(timer)
  form.query = query.value
  if (query.value.length < 3) {
    suggestions.value = []
    return
  }
  timer = setTimeout(() => {
    router.get(
      route('owner.appointments.create'),
      { query: query.value },
      { preserveState: true, replace: true, preserveScroll: true }
    )
  }, 300)
}

// kad korisnik izabere predlog
function selectUser(user) {
  console.log(user.email)
  router.post(
    route('owner.appointments.storeUser'),
    { email: user.email, phone: user.phone, name: user.name },
    { preserveState: true, replace: true }
  )
}

// kreiranje novog korisnika
function createUser() {
  form.post(
    route('owner.appointments.storeUser'),
    {},
    { preserveState: true }
  )
}

// watch za nove sugestije iz servera
watch(() => page.props.suggestions, v => {
  suggestions.value = v || []
})
</script>
