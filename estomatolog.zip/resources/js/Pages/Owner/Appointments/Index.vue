<template>
  <OwnerLayout>
    <div class="container mx-auto px-4 pt-20">
      <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">Termini</h1>
        <Link :href="route('owner.appointments.create')" class="btn btn-primary">
        Novi termin
        </Link>
      </div>

      <div class="overflow-x-auto card bg-base-100 shadow-lg rounded-lg p-4">
        <table class="table table-zebra w-full">
          <thead>
            <tr>
              <th>ID</th>
              <th>Korisnik</th>
              <th>Zaposleni</th>
              <th>Datum</th>
              <th>Vreme</th>
              <th>Status</th>
              <th class="text-right">Akcije</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="appt in appointments.data" :key="appt.id">
              <td>{{ appt.id }}</td>
              <td>{{ appt.user.name }}</td>
              <td>{{ appt.employee.name }}</td>
              <td>{{ appt.date }}</td>
              <td>{{ appt.start_time }} - {{ appt.end_time }}</td>
              <td>
                <span :class="{
                  'badge badge-warning': appt.status === 'pending',
                  'badge badge-success': appt.status === 'confirmed',
                  'badge badge-error': appt.status === 'cancelled'
                }">
                  {{ appt.status }}
                </span>
              </td>
              <td class="text-right space-x-2">
                <Link :href="route('owner.appointments.confirmation', appt.id)" class="btn btn-sm btn-outline">
                Pogledaj
                </Link>
                <button @click="destroy(appt.id)" class="btn btn-sm btn-error btn-outline">
                  Obriši
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="mt-4 flex justify-center">
        <button v-for="link in appointments.links" :key="link.label" :disabled="!link.url" v-html="link.label" :class="[
          'btn btn-sm',
          link.active ? 'btn-primary' : 'btn-outline'
        ]" @click="goTo(link.url)" />
      </div>
    </div>
  </OwnerLayout>
</template>

<script setup>
import { Link, router } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'
import { usePage } from '@inertiajs/vue3'

const { appointments } = usePage().props

function destroy(id) {
  if (confirm('Obrisati termin?')) {
    router.delete(route('owner.appointments.destroy', id))
  }
}

function goTo(url) {
  router.get(url, {}, { preserveState: true })
}
</script>
