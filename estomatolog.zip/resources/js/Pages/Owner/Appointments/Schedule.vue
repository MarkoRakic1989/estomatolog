<template>
    <OwnerLayout>

        <Head title="3. Izbor termina" />

        <section class="py-16 bg-base-200">
            <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
                <!-- Header -->
                <h2 class="text-3xl font-bold text-center mb-6">
                    Izbor datuma i vremena
                </h2>

                <!-- Nearest Suggestions -->
                <div v-if="nearestSlots.length" class="mb-6">
                    <h3 class="text-lg font-medium mb-2">Preporučeni termini</h3>
                    <div class="flex flex-wrap gap-2">
                        <button v-for="slot in nearestSlots" :key="slot.date + slot.time" @click="selectNearest(slot)"
                            :class="['btn', isSelected(slot) ? 'btn-primary' : 'btn-outline']">
                            {{ formatDate(slot.date) }} {{ slot.time }}
                        </button>
                    </div>
                </div>

                <!-- Date Swiper -->
                <Swiper :modules="[Scrollbar]" :slides-per-view="7"
                    :breakpoints="{ 0: { slidesPerView: 3 }, 640: { slidesPerView: 5 }, 1024: { slidesPerView: 7 } }"
                    scrollbar space-between="16" class="mb-8">
                    <SwiperSlide v-for="date in availableDates" :key="date" class="min-w-[200px]">
                        <label class="indicator flex items-center cursor-pointer min-w-[200px]">
                            <input type="radio" v-model="selectedDate" :value="date" @change="onDateChange"
                                class="hidden peer" />
                            <span
                                class="indicator-item absolute top-4 right-4 hidden peer-checked:flex items-center justify-center bg-primary text-primary-content w-4 h-4 rounded-full z-10">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none"
                                    stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                                </svg>
                            </span>
                            <div class="card card-compact bg-base-100 border-2 p-6 text-center transition"
                                :class="selectedDate === date ? 'border-primary' : 'border-base-200'">
                                <div class="font-medium">{{ formatDate(date) }}</div>
                            </div>
                        </label>
                    </SwiperSlide>
                </Swiper>

                <!-- Time Slots -->
                <div v-if="availableSlots.length">
                    <h3 class="text-lg font-medium mb-4">Slobodni termini</h3>
                    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                        <label v-for="slot in availableSlots" :key="slot"
                            class="indicator flex items-center cursor-pointer">
                            <input type="radio" v-model="selectedSlot" :value="slot" class="hidden peer" />
                            <span
                                class="indicator-item absolute top-2 right-2 hidden peer-checked:flex items-center justify-center bg-primary text-primary-content w-4 h-4 rounded-full z-10">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none"
                                    stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                                </svg>
                            </span>
                            <div class="card bg-base-100 border-2 p-4 text-center transition"
                                :class="selectedSlot === slot ? 'border-primary' : 'border-base-200'">
                                {{ slot }}
                            </div>
                        </label>
                    </div>
                </div>

                <div v-else class="text-center text-gray-500">
                    Nema dostupnih termina za izabrani datum.
                </div>

                <!-- Navigation Buttons -->
                <div class="flex justify-between mt-8">
                    <Link :href="route('owner.appointments.services.index')" class="btn btn-outline">
                    ← Nazad: Usluge
                    </Link>
                    <button @click="submitSchedule" class="btn btn-primary"
                        :disabled="!selectedDate || !selectedSlot || form.processing">
                        {{ form.processing ? '...' : 'Potvrdi termin' }}
                    </button>
                </div>
            </div>
        </section>
    </OwnerLayout>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { Head, Link, useForm } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'
import { Swiper, SwiperSlide } from 'swiper/vue'
import { Scrollbar } from 'swiper/modules'
import 'swiper/css'
import 'swiper/css/scrollbar'
import dayjs from 'dayjs'

const props = defineProps({
    salonSlug: String,
    salon: Object,
    availableDates: Array,
    availableSlots: Array,
    selectedEmployee: Object,
    selectedServices: Array,
})

// Inertia form state
const form = useForm({
    service_ids: props.selectedServices,
    employee_id: props.selectedEmployee.id,
    date: '',
    start_time: '',
})

const selectedDate = ref(props.availableDates[0] || '')
const selectedSlot = ref('')
const availableSlots = ref(props.availableSlots || [])

// Compute nearest (first 3) slots with date & time
const nearestSlots = computed(() =>
    availableSlots.value.slice(0, 3).map(time => ({ date: selectedDate.value, time }))
)

function selectNearest(slot) {
    selectedDate.value = slot.date
    selectedSlot.value = slot.time
}

function isSelected(slot) {
    return selectedDate.value === slot.date && selectedSlot.value === slot.time
}

function formatDate(date) {
    return dayjs(date).format('DD.MM.YYYY')
}

async function onDateChange() {
    form.date = selectedDate.value
    // fetch new slots for this date
    const response = await fetch(
        route('api.calendar.slots', {
            salonSlug: props.salon.slug,
            employee_id: props.selectedEmployee.id,
            service_ids: props.selectedServices,
            date: selectedDate.value,
        })
    )
    const json = await response.json()
    availableSlots.value = json.slots || []
    selectedSlot.value = ''
}

function submitSchedule() {
    form.date = selectedDate.value
    form.start_time = selectedSlot.value
    form.post(route('owner.appointments.store'), { preserveState: true })
}

onMounted(() => {
    if (selectedDate.value) onDateChange()
})
</script>

<style scoped>
/* No extra styles needed */
</style>
