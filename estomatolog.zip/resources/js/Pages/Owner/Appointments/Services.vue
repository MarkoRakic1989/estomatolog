<template>
    <OwnerLayout>

        <Head title="2. Izbor usluga i zaposlenog" />

        <div class="container mx-auto px-4 pt-20">
            <h2 class="text-2xl font-bold mb-4">2. Izbor usluga i zaposlenog</h2>

            <!-- top 5 -->
            <div class="flex flex-wrap gap-2 mb-6">
                <button v-for="t in topServices" :key="t.id" @click="toggleTop(t.id)"
                    :class="['badge', form.service_ids.includes(t.id) ? 'badge-primary' : 'badge-outline']">
                    {{ t.name }}
                </button>
            </div>

            <form @submit.prevent="submit" class="space-y-6">
                <!-- po kategorijama -->
                <div v-for="parent in parents" :key="parent.id" class="mb-4">
                    <h3 class="font-semibold mb-2">{{ parent.name }}</h3>
                    <div class="grid grid-cols-2 gap-2">
                        <!-- roditeljske usluge -->
                        <label v-for="svc in parent.services" :key="svc.id" class="flex items-center space-x-2">
                            <input type="checkbox" :value="svc.id" v-model="form.service_ids"
                                class="checkbox checkbox-primary"
                                :disabled="conflicts(svc.id).some(c => form.service_ids.includes(c))" />
                            <span>{{ svc.name }}</span>
                        </label>
                        <!-- usluge potkategorija -->
                        <template v-for="child in children[parent.id] || []" :key="child.id">
                            <label v-for="svc in child.services" :key="svc.id" class="flex items-center space-x-2">
                                <input type="checkbox" :value="svc.id" v-model="form.service_ids"
                                    class="checkbox checkbox-primary"
                                    :disabled="conflicts(svc.id).some(c => form.service_ids.includes(c))" />
                                <span>— {{ svc.name }}</span>
                            </label>
                        </template>
                    </div>
                </div>

                <!-- Izbor zaposlenog koji radi sve odabrane usluge -->
                <div>
                    <label class="label"><span class="label-text">Zaposleni</span></label>
                    <div v-if="!form.service_ids.length" class="text-gray-500 italic mb-2">
                        Molimo izaberite bar jednu uslugu prvo.
                    </div>
                    <select v-model="form.employee_id" class="select select-bordered w-full"
                        :disabled="!form.service_ids.length || !filteredEmployees.length">
                        <option value="">— izaberite —</option>
                        <option v-for="e in filteredEmployees" :key="e.id" :value="e.id">
                            {{ e.name }}
                        </option>
                    </select>
                    <p v-if="!filteredEmployees.length && form.service_ids.length" class="text-error mt-1">
                        Nema zaposlenih za izabrane usluge.
                    </p>
                </div>

                <button type="submit" class="btn btn-primary w-full"
                    :disabled="loading || !form.service_ids.length || !form.employee_id">
                    {{ loading ? '...' : 'Nastavi' }}
                </button>
            </form>
        </div>
    </OwnerLayout>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useForm, usePage, Head } from '@inertiajs/vue3'

const { categories, topServices, employees } = usePage().props

// Flat lista kategorija -> roditelji + deca
const parents = computed(() => categories.filter(c => !c.parent_id))
const children = computed(() => {
    const map = {}
    categories.forEach(c => {
        if (c.parent_id) {
            (map[c.parent_id] ??= []).push(c)
        }
    })
    return map
})

// Forma
const form = useForm({ service_ids: [], employee_id: '' })
const loading = ref(false)

// Konflikti (popuni po potrebi)
const conflictMap = {}
function conflicts(id) {
    return conflictMap[id] || []
}

// Filter: zaposleni koji rade sve odabrane usluge
const filteredEmployees = computed(() => {
    if (!form.service_ids.length) return []
    return employees.filter(e =>
        form.service_ids.every(svcId => e.service_ids.includes(svcId))
    )
})

function toggleTop(id) {
    const idx = form.service_ids.indexOf(id)
    if (idx >= 0) form.service_ids.splice(idx, 1)
    else form.service_ids.push(id)
}

async function submit() {
    loading.value = true
    await form.post(route('owner.appointments.services.store'))
    loading.value = false
}
</script>

<style scoped>
/* nema dodatnih */
</style>
