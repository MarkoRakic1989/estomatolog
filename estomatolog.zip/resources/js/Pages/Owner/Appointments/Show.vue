<!-- resources/js/Pages/Owner/Appointments/Show.vue -->
<template>
    <OwnerLayout>
        <template #header>
            <h2>Detalji termina</h2>
        </template>
        <!-- ... osnovni podaci termina ... -->
        <div class="mt-6 p-4 bg-white rounded shadow">
            <h3 class="font-bold">Izveštaji</h3>
            <ul>
                <li v-for="r in appointment.reports" :key="r.id" class="mb-2">
                    <div class="text-sm text-gray-600">{{ r.created_at }}</div>
                    <div>{{ r.content }}</div>
                </li>
            </ul>
            <form @submit.prevent="save">
                <textarea v-model="content" class="textarea w-full" rows="3"
                    placeholder="Unesite izveštaj..."></textarea>
                <button type="submit" class="btn btn-primary mt-2">Sačuvaj izveštaj</button>
            </form>
        </div>
    </OwnerLayout>
</template>

<script setup>
import { ref } from 'vue'
import { useForm, usePage } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'

const { appointment } = usePage().props
const form = useForm({ content: '' })

function save() {
    form.post(route('owner.appointments.reports.store', appointment.id))
}
</script>
