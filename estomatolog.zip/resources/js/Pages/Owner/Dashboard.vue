<template>
  <OwnerLayout>
    <!-- Header Slot -->
    <template #header>
      <h2 class="text-2xl font-semibold">Dashboard</h2>
    </template>

    <!-- Stats Cards -->
    <div class="container mx-auto px-4 lg:px-8 pt-6 lg:pt-20">
      <div class="stats stats-vertical lg:stats-horizontal shadow">
        <div class="stat">
          <div class="stat-title">Appointments Today</div>
          <div class="stat-value text-primary">{{ countToday }}</div>
        </div>
        <div class="stat">
          <div class="stat-title">This Week</div>
          <div class="stat-value text-secondary">{{ countWeek }}</div>
        </div>
        <div class="stat">
          <div class="stat-title">This Month</div>
          <div class="stat-value text-accent">{{ countMonth }}</div>
        </div>
      </div>

      <!-- Top Services -->
      <div class="card bg-base-100 shadow-xl mt-6">
        <div class="card-body">
          <h3 class="card-title">Top Services</h3>
          <ul class="list-disc list-inside mt-2">
            <li v-for="svc in topServices" :key="svc.id">
              {{ svc.name }} ({{ svc.appointments_count }})
            </li>
          </ul>
        </div>
      </div>

      <!-- Today's Appointments Table -->
      <div class="card bg-base-100 shadow-xl mt-6">
        <div class="card-body">
          <div class="flex justify-between items-center mb-4">
            <h3 class="card-title">Today's Appointments</h3>
            <button @click="exportPdf" class="btn btn-primary">Export PDF</button>
          </div>
          <div class="overflow-x-auto">
            <table class="table table-zebra w-full">
              <thead>
                <tr>
                  <th>Time</th>
                  <th>Service</th>
                  <th>Employee</th>
                  <th>Client</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="appt in todaysAppointmentsList" :key="appt.id">
                  <td>{{ appt.start_time }} - {{ appt.end_time }}</td>
                  <td>
                    <button @click="openDetails(appt)" class="link link-primary">Details</button>
                  </td>
                  <td>{{ appt.employeeName }}</td>
                  <td>{{ appt.clientName }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Details Modal -->
      <Modal v-model:show="showModal">
        <template #header>
          <h3 class="font-semibold text-lg">Appointment Details</h3>
        </template>
        <template #body>
          <div class="space-y-3">
            <div><strong>Salon:</strong> {{ selectedAppointment?.salonName }}</div>
            <div><strong>Employee:</strong> {{ selectedAppointment?.employeeName }}</div>
            <div><strong>Date:</strong> {{ formatDate(selectedAppointment?.date) }}</div>
            <div><strong>Time:</strong> {{ selectedAppointment?.start_time }} - {{ selectedAppointment?.end_time }}
            </div>
            <div>
              <strong>Services:</strong>
              <div class="mt-2 space-y-2">
                <div v-for="svc in selectedAppointment?.services" :key="svc.id" class="card bg-base-200 p-4">
                  <div class="font-semibold">{{ svc.name }}</div>
                  <div class="text-sm text-gray-600">Duration: {{ svc.duration }} min</div>
                  <div class="text-sm text-gray-600">Price: ${{ svc.price }}</div>
                  <div class="text-sm text-gray-600 mt-1">{{ svc.description }}</div>
                </div>
              </div>
            </div>
          </div>
        </template>
        <template #footer>
          <button @click="closeModal" class="btn btn-secondary">Close</button>
        </template>
      </Modal>
    </div>
  </OwnerLayout>
</template>

<script setup>
import { ref, computed } from 'vue'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'
import Modal from '@/Components/Modal.vue'

const props = defineProps({
  countToday: Number,
  countWeek: Number,
  countMonth: Number,
  topServices: Array,
  todaysAppointments: Object
})

const todaysAppointmentsList = computed(() => props.todaysAppointments.data || [])

const showModal = ref(false)
const selectedAppointment = ref(null)

function formatDate(dateString) {
  return new Date(dateString).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })
}

function openDetails(appointment) {
  selectedAppointment.value = appointment
  showModal.value = true
}

function closeModal() {
  showModal.value = false
}

function exportPdf() {
  window.location.href = route('owner.dashboard.exportPdf')
}
</script>

<style scoped></style>