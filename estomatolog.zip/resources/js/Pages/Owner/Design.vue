<template>
  <OwnerLayout>
    <div class="flex flex-col lg:flex-row gap-8">
      <!-- Лева колона: форма и избор теме -->
      <div class="w-full lg:w-1/2 space-y-6">
        <h1 class="text-2xl font-bold">Prilagodba dizajna</h1>

        <form @submit.prevent="submit" class="space-y-6">
          <!-- Logo Upload -->
          <div>
            <label class="block font-medium mb-1">Logo</label>
            <input type="file" @change="onLogoChange" accept="image/*"
              class="file-input file-input-bordered w-full max-w-xs" />
            <img v-if="form.logoPreview" :src="form.logoPreview" alt="Logo preview" class="mt-2 h-20 object-contain" />
          </div>

          <!-- Color pickers -->
          <div class="flex space-x-4">
            <div>
              <label class="block font-medium mb-1">Primary Color</label>
              <input type="color" v-model="form.primary_color" class="w-12 h-12 p-0 border-0 cursor-pointer" />
            </div>
            <div>
              <label class="block font-medium mb-1">Secondary Color</label>
              <input type="color" v-model="form.secondary_color" class="w-12 h-12 p-0 border-0 cursor-pointer" />
            </div>
          </div>

          <!-- Theme picker -->
          <div>
            <label class="block font-medium mb-2">Tema</label>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              <div v-for="t in themes" :key="t"
                class="rounded-lg overflow-hidden shadow cursor-pointer transition-transform hover:scale-105"
                :class="form.theme === t ? 'ring-2 ring-primary' : 'ring ring-gray-200'" @click="selectTheme(t)">
                <!-- DATA-THEME wrapper: sad bg-primary se примењује -->
                <div :data-theme="t" class="flex flex-col">
                  <!-- светли panel -->
                  <div class="bg-base-100 p-3 flex justify-between items-center">
                    <span class="font-semibold capitalize">{{ t }}</span>
                    <div class="flex space-x-1">
                      <div class="w-4 h-4 rounded bg-primary"></div>
                      <div class="w-4 h-4 rounded bg-secondary"></div>
                      <div class="w-4 h-4 rounded bg-accent"></div>
                    </div>
                  </div>
                  <!-- тамни panel -->
                  <div class="bg-base-200 p-3 flex justify-end items-center">
                    <div class="flex space-x-1">
                      <div class="w-4 h-4 rounded bg-primary"></div>
                      <div class="w-4 h-4 rounded bg-secondary"></div>
                      <div class="w-4 h-4 rounded bg-accent"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Сакривени input за тему да InertiaForms ухвати вредност -->
          <input type="hidden" name="theme" :value="form.theme" />

          <PrimaryButton>Sačuvaj promene</PrimaryButton>
        </form>
      </div>

      <!-- Десна колона: живи preview public home -->
      <div class="w-full lg:w-1/2 h-[90vh] border rounded-lg  overflow-auto">
        <HomePreview :salon="salon" :top-services="topServices" :theme="form.theme" />
      </div>
    </div>
  </OwnerLayout>
</template>

<script setup>
import HomePreview from '@/Components/HomePreview.vue'
import { ref, watch } from 'vue'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'
import PrimaryButton from '@/Components/PrimaryButton.vue'
import { useForm } from '@inertiajs/vue3'
import { usePage } from '@inertiajs/vue3'

// Узимаш салон и теме из Inertia props
const { salon, themes, salonSlug } = usePage().props

// Иницијализујеш useForm са почетним вредностима
const form = useForm({
  logo: null,
  primary_color: salon.primary_color,
  secondary_color: salon.secondary_color,
  theme: salon.theme,
})

// Функција за upload preview
function onLogoChange(e) {
  const file = e.target.files[0]
  if (!file) return
  form.logo = file        // useForm ће сами руковати фајлом
  form.setData('logo', file)
  form.logoPreview = URL.createObjectURL(file)
}

// Када корисник кликне на тему
function selectTheme(t) {
  form.theme = t
}

// Submit шаље `form.post` ка именованој рути
function submit() {
  form.patch(route('owner.design.update', { salonSlug }), {
    preserveScroll: true,
    onSuccess: () => {
      // по жељи можеш приказати notifikaciju
    },
  })
}
function applyThemeToIframe(theme) {
  const iframe = previewUrl.value
  if (!iframe?.contentWindow) return

  try {
    // Сетовање data-theme на <html> unutar iframe-а
    iframe.contentWindow.document.documentElement.setAttribute('data-theme', theme)
  } catch (e) {
    console.warn('Cannot set theme on iframe (cross-origin?)', e)
  }
}
// Иframe URL на бази named руте
const previewUrl = ref(
  route('public.home', { salonSlug, previewTheme: form.theme })
)
watch(
  () => form.theme,
  (t) => {
    previewUrl.value = route('public.home', { salonSlug, previewTheme: t })
    applyThemeToIframe(t)
  }
)
</script>

<style scoped>
/* Оивица за изабрану тему */
.ring-primary {
  --tw-ring-color: var(--p) !important;
}
</style>
