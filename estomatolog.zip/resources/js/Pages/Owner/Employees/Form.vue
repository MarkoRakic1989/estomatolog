<template>
  <OwnerLayout :key="props.employee?.id ?? 'new'">
    <!-- Header -->
    <template #header>
      <h2 class="text-2xl font-semibold">
        {{ props.employee ? 'Edit' : 'New' }} Employee
      </h2>
    </template>

    <!-- Form Container -->
    <div class="container mx-auto px-4 pt-20">
      <div class="card bg-base-100 shadow max-w-lg mx-auto">
        <div class="card-body">
          <form @submit.prevent="submit" enctype="multipart/form-data" class="space-y-6">
            <!-- Name -->
            <div>
              <label class="label">
                <span class="label-text">Name</span>
              </label>
              <input id="name" name="name" v-model="form.name" type="text" class="input input-bordered w-full"
                autocomplete="off" />
              <p v-if="form.errors.name" class="text-error text-sm">
                {{ form.errors.name }}
              </p>
            </div>

            <!-- Email -->
            <div>
              <label class="label">
                <span class="label-text">Email</span>
              </label>
              <template v-if="props.employee">
                <p class="input input-bordered w-full bg-base-200" readonly>
                  {{ props.employee.email }}
                </p>
              </template>
              <template v-else>
                <input id="email" name="email" v-model="form.email" type="email" class="input input-bordered w-full"
                  autocomplete="off" />
                <p v-if="form.errors.email" class="text-error text-sm">
                  {{ form.errors.email }}
                </p>
              </template>
            </div>

            <!-- Phone -->
            <div>
              <label class="label">
                <span class="label-text">Phone</span>
              </label>
              <input id="phone" name="phone" v-model="form.phone" type="text" class="input input-bordered w-full"
                autocomplete="off" />
              <p v-if="form.errors.phone" class="text-error text-sm">
                {{ form.errors.phone }}
              </p>
            </div>

            <!-- Photo Upload -->
            <div>
              <label class="label">
                <span class="label-text">Photo</span>
              </label>
              <input id="photo" name="photo" type="file" accept="image/*" @change="onPhotoChange"
                class="file-input file-input-bordered w-full" />
              <p v-if="form.errors.photo" class="text-error text-sm">
                {{ form.errors.photo }}
              </p>
              <div v-if="previewUrl" class="mt-2">
                <img :src="previewUrl" alt="Preview" class="h-32 w-full object-cover rounded-lg border"
                  @error="onImageError" />
              </div>
            </div>

            <!-- Services Selection -->
            <div>
              <label class="label">
                <span class="label-text">Services</span>
              </label>
              <div class="grid grid-cols-2 gap-2">
                <label v-for="s in props.services" :key="s.id" class="inline-flex items-center space-x-2">
                  <input name="service_ids[]" type="checkbox" :value="s.id" v-model="form.service_ids" class="checkbox
         focus:outline-none focus:ring-0
         hover:bg-transparent" />
                  <span>{{ s.name }}</span>
                </label>
              </div>
              <p v-if="form.errors.service_ids" class="text-error text-sm">
                {{ form.errors.service_ids }}
              </p>
            </div>

            <!-- Actions -->
            <div class="flex justify-end space-x-2">
              <Link :href="route('owner.employees.index')" class="btn btn-outline">
              Cancel
              </Link>
              <button type="submit" :disabled="form.processing" class="btn btn-primary">
                {{ form.processing ? 'Saving...' : 'Save' }}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </OwnerLayout>
</template>

<script setup>
import { ref, computed } from 'vue'
import { Link, useForm } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'

const props = defineProps({
  employee: { type: Object, default: null },
  services: { type: Array, required: true },
})

const form = useForm({
  name: props.employee?.name || '',
  email: props.employee?.email || '',
  phone: props.employee?.phone || '',
  service_ids: props.employee?.service_ids || [],
  photo: null,
  ...(props.employee ? { _method: 'PUT' } : {}),
})

const localPreview = ref(null)

const previewUrl = computed(() => {
  if (localPreview.value) return localPreview.value
  if (props.employee?.photo) return route('photos.show', { filename: props.employee.photo })
  return null
})

function onPhotoChange(e) {
  const file = e.target.files[0]
  if (!file) return
  form.photo = file
  localPreview.value = URL.createObjectURL(file)
}

function onImageError(e) {
  console.error('Image load error:', e.target.src)
}

function submit() {
  const url = props.employee
    ? route('owner.employees.update', props.employee.id)
    : route('owner.employees.store')
  form.post(url, { forceFormData: true })
}
</script>


<style scoped>
.checkbox:hover,
.checkbox:focus {
  background-color: transparent !important;
  box-shadow: none !important;
  outline: none !important;
}
</style>
