<template>
  <OwnerLayout>
    <div class="container mx-auto px-4 pt-20">
      <!-- Header Card -->
      <div class="card bg-base-100 shadow mb-6">
        <div class="card-body flex justify-between items-center">
          <h2 class="card-title">Employees</h2>
          <Link :href="route('owner.employees.create')" class="btn btn-primary">
          Add Employee
          </Link>
        </div>
      </div>

      <!-- Employees Table -->
      <div class="overflow-x-auto card bg-base-100 shadow p-4">
        <table class="table table-zebra w-full">
          <thead>
            <tr>
              <th>Name</th>
              <th>Services</th>
              <th class="text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="e in employees" :key="e.id">
              <td>{{ e.name }}</td>
              <td>{{e.services.map(s => s.name).join(', ')}}</td>
              <td class="text-right space-x-2">
                <Link :href="route('owner.employees.edit', e.id)" class="btn btn-sm btn-outline">
                Edit
                </Link>
                <button @click="destroy(e.id)" class="btn btn-sm btn-error btn-outline">
                  Delete
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </OwnerLayout>
</template>

<script setup>
import { Link, useForm } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'

const props = defineProps({ employees: Array })
const form = useForm()

function destroy(id) {
  if (!confirm('Delete this employee?')) return
  form.delete(route('owner.employees.destroy', id))
}
</script>

<style scoped>
/* No additional styles needed */
</style>
