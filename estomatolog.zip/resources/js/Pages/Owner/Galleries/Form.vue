<template>
  <OwnerLayout>
    <template #header>
      <h2 class="text-2xl font-semibold">{{ gallery ? 'Edit' : 'New' }} Gallery</h2>
    </template>

    <form @submit.prevent="submit" enctype="multipart/form-data" class="bg-white shadow rounded p-6 space-y-4 mt-4">
      <div>
        <label class="block mb-1">Name</label>
        <input v-model="form.name" class="w-full border rounded px-3 py-2" />
        <div v-if="form.errors.name" class="text-red-600">{{ form.errors.name }}</div>
      </div>
      <div>
        <label class="block mb-1">Images</label>
        <input type="file" multiple @change="onFiles" class="w-full" />
      </div>
      <div class="flex justify-end space-x-2">
        <Link :href="route('owner.galleries.index')" class="btn-secondary">Cancel</Link>
        <button type="submit" :disabled="form.processing" class="btn-primary">{{ gallery ? 'Update' : 'Create'
        }}</button>
      </div>
    </form>
  </OwnerLayout>
</template>

<script setup>
import { Link, useForm } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'
const props = defineProps({ gallery: Object })
const form = useForm({
  name: props.gallery?.name || '',
  images: [],
})
function onFiles(e) { form.images = Array.from(e.target.files) }
function submit() {
  if (props.gallery) {
    form.put(route('owner.galleries.update', props.gallery.id))
  } else {
    form.put(route('owner.galleries.store'))
  }
}
</script>

<style scoped>
.btn-primary {
  @apply bg-blue-600 text-white px-3 py-1 rounded
}

.btn-secondary {
  @apply bg-gray-300 text-gray-800 px-3 py-1 rounded
}
</style>
