<template>
  <OwnerLayout>
    <template #header>
      <div class="flex justify-between items-center">
        <h2 class="text-2xl font-semibold">Galleries</h2>
        <Link :href="route('owner.galleries.create')" class="btn-primary">New Gallery</Link>
      </div>
    </template>

    <div class="grid grid-cols-3 gap-4 mt-4">
      <div v-for="g in galleries" :key="g.id" class="bg-white shadow rounded p-4">
        <h3 class="font-medium mb-2">{{ g.name }}</h3>
        <div class="space-y-2 mb-2">
          <img v-for="img in g.images" :key="img.id" :src="img.path" class="w-full h-24 object-cover rounded" />
        </div>
        <div class="space-x-2">
          <Link :href="route('owner.galleries.edit', g.id)" class="text-blue-600">Edit</Link>
          <button @click="destroy(g.id)" class="text-red-600">Delete</button>
        </div>
      </div>
    </div>
  </OwnerLayout>
</template>

<script setup>
import { Link, useForm } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'
const props = defineProps({ galleries: Array })
const form = useForm()
function destroy(id) {
  if (!confirm('Delete gallery?')) return
  form.delete(route('owner.galleries.destroy', id), { preserveState: true })
}
</script>

<style scoped>
.btn-primary { @apply bg-green-600 text-white px-4 py-2 rounded }
</style>
