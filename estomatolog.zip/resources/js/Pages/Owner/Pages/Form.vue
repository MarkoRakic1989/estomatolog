<template>
  <OwnerLayout>
    <template #header>
      <h2 class="text-2xl font-semibold">{{ page ? 'Edit' : 'New' }} Page</h2>
    </template>

    <form @submit.prevent="submit" class="bg-white shadow rounded p-6 space-y-4 mt-4">
      <div>
        <label class="block mb-1">Title</label>
        <input v-model="form.title" class="w-full border rounded px-3 py-2" />
        <div v-if="form.errors.title" class="text-red-600">{{ form.errors.title }}</div>
      </div>
      <div>
        <label class="block mb-1">Slug</label>
        <input v-model="form.slug" class="w-full border rounded px-3 py-2" />
        <div v-if="form.errors.slug" class="text-red-600">{{ form.errors.slug }}</div>
      </div>
      <div>
        <label class="block mb-1">Content</label>
        <textarea v-model="form.content" rows="6" class="w-full border rounded px-3 py-2"></textarea>
        <div v-if="form.errors.content" class="text-red-600">{{ form.errors.content }}</div>
      </div>
      <div class="flex justify-end space-x-2">
        <Link :href="route('owner.pages.index')" class="btn-secondary">Cancel</Link>
        <button type="submit" :disabled="form.processing" class="btn-primary">{{ page ? 'Update' : 'Create' }}</button>
      </div>
    </form>
  </OwnerLayout>
</template>

<script setup>
import { Link, useForm } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'
const props = defineProps({ page: Object })
const form = useForm({
  title: props.page?.title || '',
  slug:  props.page?.slug  || '',
  content: props.page?.content || '',
})
function submit() {
  if (props.page) {
    form.put(route('owner.pages.update', props.page.id))
  } else {
    form.post(route('owner.pages.store'))
  }
}
</script>

<style scoped>
.btn-primary { @apply bg-blue-600 text-white px-3 py-1 rounded }
.btn-secondary { @apply bg-gray-300 text-gray-800 px-3 py-1 rounded }
</style>
