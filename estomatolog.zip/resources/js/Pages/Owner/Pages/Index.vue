<template>
  <OwnerLayout>
    <template #header>
      <div class="flex justify-between items-center">
        <h2 class="text-2xl font-semibold">Pages</h2>
        <Link :href="route('owner.pages.create')" class="btn-primary">New Page</Link>
      </div>
    </template>

    <div class="bg-white shadow rounded overflow-hidden mt-4">
      <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
          <tr>
            <th class="px-4 py-2 text-left">Title</th>
            <th class="px-4 py-2 text-left">Slug</th>
            <th class="px-4 py-2">Actions</th>
          </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200">
          <tr v-for="p in pages" :key="p.id">
            <td class="px-4 py-2">{{ p.title }}</td>
            <td class="px-4 py-2">{{ p.slug }}</td>
            <td class="px-4 py-2 space-x-2">
              <Link :href="route('owner.pages.edit', p.id)" class="text-blue-600">Edit</Link>
              <button @click="destroy(p.id)" class="text-red-600">Delete</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </OwnerLayout>
</template>

<script setup>
import { Link, useForm } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'
const props = defineProps({ pages: Array })
const form = useForm()
function destroy(id) {
  if (!confirm('Are you sure?')) return
  form.delete(route('owner.pages.destroy', id), { preserveState: true })
}
</script>

<style scoped>
.btn-primary { @apply bg-green-600 text-white px-4 py-2 rounded }
</style>
