<template>
    <OwnerLayout>
        <div class="container mx-auto px-4 pt-20">
            <div class="card bg-base-100 shadow max-w-md mx-auto">
                <div class="card-body">
                    <h2 class="card-title mb-4">Izmeni kategoriju</h2>
                    <form @submit.prevent="submit" class="space-y-4">
                        <!-- Naziv -->
                        <div>
                            <label class="label">
                                <span class="label-text">Naziv</span>
                            </label>
                            <input v-model="form.name" type="text" placeholder="Unesi naziv"
                                class="input input-bordered w-full" />
                            <span v-if="form.errors.name" class="text-error text-sm">
                                {{ form.errors.name }}
                            </span>
                        </div>

                        <!-- Roditeljska kategorija -->
                        <div>
                            <label class="label">
                                <span class="label-text">Roditeljska kategorija</span>
                            </label>
                            <select v-model="form.parent_id" class="select select-bordered w-full">
                                <option :value="null">— Nema —</option>
                                <option v-for="p in parents" :key="p.id" :value="p.id">
                                    {{ p.name }}
                                </option>
                            </select>
                        </div>

                        <!-- Slika -->
                        <div>
                            <label class="label">
                                <span class="label-text">Slika (400×300)</span>
                            </label>
                            <input type="file" @change="upload" accept="image/*"
                                class="file-input file-input-bordered w-full" />
                            <img v-if="preview || serviceCategory.image"
                                :src="preview
                                    ? preview
                                    : route('photos.show.folder', { folder: 'service-categories', filename: serviceCategory.image })" alt="Preview"
                                class="mt-2 w-40 h-30 object-cover rounded-lg border" />
                        </div>

                        <!-- Dugme -->
                        <button type="submit" class="btn btn-primary w-full" :disabled="form.processing">
                            Sačuvaj izmene
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </OwnerLayout>
</template>

<script setup>
import { ref } from 'vue'
import { useForm } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'

const props = defineProps({
    serviceCategory: Object,
    parents: Array,
})

const form = useForm({
    name: props.serviceCategory.name,
    parent_id: props.serviceCategory.parent_id,
    image: null,
    _method: 'PUT',
})

const preview = ref(null)

function upload(e) {
    const file = e.target.files[0]
    if (!file) return
    form.image = file
    form.setData('image', file)
    preview.value = URL.createObjectURL(file)
}

function submit() {
    form.post(route('owner.service-categories.update', props.serviceCategory.id), {
        preserveScroll: true,
    })
}
</script>

<style scoped>
/* Additional scoped styles if needed */
</style>
