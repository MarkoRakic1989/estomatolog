<template>
    <OwnerLayout>
        <div class="container mx-auto px-4 pt-20">
            <div class="card bg-base-100 shadow mb-6">
                <div class="card-body flex justify-between items-center">
                    <h2 class="card-title">Kategorije usluga</h2>
                    <Link class="btn btn-primary"
                        :href="route('owner.service-categories.create', { parent_id: parent?.id })">
                    Nova kategorija
                    </Link>
                </div>
            </div>

            <div class="overflow-x-auto">
                <table class="table table-zebra w-full">
                    <thead>
                        <tr>
                            <th>Naziv</th>
                            <th>Slika</th>
                            <th>Roditelj</th>
                            <th class="text-right">Akcije</th>
                        </tr>
                    </thead>
                    <tbody>
                        <template v-for="cat in serviceCategories" :key="cat.id">
                            <tr>
                                <td class="font-semibold">{{ cat.name }}</td>
                                <td>
                                    <img v-if="cat.image"
                                        :src="route('photos.show.folder', { folder: 'service-categories', filename: cat.image })"
                                        class="w-24 h-16 object-cover rounded-lg" />
                                </td>
                                <td>—</td>
                                <td class="text-right space-x-2">
                                    <Link class="btn btn-sm btn-outline"
                                        :href="route('owner.service-categories.edit', cat.id)">
                                    Izmeni
                                    </Link>
                                    <button class="btn btn-sm btn-error" @click="destroy(cat.id)">
                                        Obriši
                                    </button>
                                </td>
                            </tr>
                            <tr v-for="child in cat.children" :key="child.id" class="bg-base-200">
                                <td class="pl-8">├─ {{ child.name }}</td>
                                <td>
                                    <img v-if="child.image"
                                        :src="route('photos.show.folder', { folder: 'service-categories', filename: child.image })"
                                        class="w-24 h-16 object-cover rounded-lg" />
                                </td>
                                <td>{{ cat.name }}</td>
                                <td class="text-right space-x-2">
                                    <Link class="btn btn-sm btn-outline"
                                        :href="route('owner.service-categories.edit', child.id)">
                                    Izmeni
                                    </Link>
                                    <button class="btn btn-sm btn-error" @click="destroy(child.id)">
                                        Obriši
                                    </button>
                                </td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>
        </div>
    </OwnerLayout>
</template>

<script setup>
import { Link, router } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'

const props = defineProps({
    serviceCategories: Array,
    parent: Object,
})

function destroy(id) {
    if (!confirm('Zaista obrisati kategoriju?')) return
    router.delete(route('owner.service-categories.destroy', id))
}
</script>

<style scoped>
/* Additional spacing or overrides if needed */
</style>
