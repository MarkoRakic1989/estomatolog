<template>
    <OwnerLayout>

        <Head title="Kreiraj Uslugu" />
        <div class="container mx-auto px-4 pt-20">
            <div class="card bg-base-100 shadow max-w-lg mx-auto">
                <div class="card-body">
                    <h1 class="card-title mb-6">Kreiraj Uslugu</h1>
                    <form @submit.prevent="submit" class="space-y-6">
                        <!-- Naziv -->
                        <div>
                            <label class="label"><span class="label-text">Naziv</span></label>
                            <input v-model="form.name" type="text" placeholder="Unesite naziv usluge"
                                class="input input-bordered w-full" />
                            <p v-if="form.errors.name" class="text-error text-sm">{{ form.errors.name }}</p>
                        </div>

                        <!-- Opis -->
                        <div>
                            <label class="label"><span class="label-text">Opis</span></label>
                            <textarea v-model="form.description" placeholder="Unesite opis (opciono)"
                                class="textarea textarea-bordered w-full" rows="4"></textarea>
                            <p v-if="form.errors.description" class="text-error text-sm">{{ form.errors.description }}
                            </p>
                        </div>

                        <!-- Kategorije (roditelj + potkategorija) -->
                        <div>
                            <label class="label"><span class="label-text">Kategorija usluge</span></label>
                            <select v-model="form.service_category_id" class="select select-bordered w-full">
                                <option value="">— izaberite —</option>
                                <optgroup v-for="parent in parents" :key="parent.id" :label="parent.name">
                                    <option :value="parent.id">{{ parent.name }}</option>
                                    <option v-for="child in children[parent.id] || []" :key="child.id"
                                        :value="child.id">
                                        &nbsp;— {{ child.name }}
                                    </option>
                                </optgroup>
                            </select>
                            <p v-if="form.errors.service_category_id" class="text-error text-sm">
                                {{ form.errors.service_category_id }}
                            </p>
                        </div>

                        <!-- Cena -->
                        <div>
                            <label class="label"><span class="label-text">Cena ($)</span></label>
                            <input v-model="form.price" type="number" step="0.01" placeholder="npr. 49.99"
                                class="input input-bordered w-full" />
                            <p v-if="form.errors.price" class="text-error text-sm">{{ form.errors.price }}</p>
                        </div>

                        <!-- Trajanje -->
                        <div>
                            <label class="label"><span class="label-text">Trajanje (min)</span></label>
                            <input v-model="form.duration" type="number" placeholder="npr. 30"
                                class="input input-bordered w-full" />
                            <p v-if="form.errors.duration" class="text-error text-sm">{{ form.errors.duration }}</p>
                        </div>

                        <!-- Slika -->
                        <div>
                            <label class="label"><span class="label-text">Slika (300×200)</span></label>
                            <input type="file" accept="image/*" @change="onFileChange"
                                class="file-input file-input-bordered w-full" />
                            <p v-if="form.errors.image" class="text-error text-sm">{{ form.errors.image }}</p>
                        </div>

                        <!-- Dugmad -->
                        <div class="flex justify-between">
                            <Link :href="route('owner.services.index')" class="btn btn-ghost">Otkaži</Link>
                            <button type="submit" class="btn btn-primary" :disabled="form.processing">
                                {{ form.processing ? '...' : 'Sačuvaj' }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </OwnerLayout>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useForm, Head, Link } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'

const props = defineProps({
    // categories flat list with parent_id
    categories: Array
})

const parents = computed(() => props.categories.filter(c => !c.parent_id))
const children = computed(() => {
    const map = {}
    props.categories.forEach(c => {
        if (c.parent_id) {
            map[c.parent_id] = map[c.parent_id] || []
            map[c.parent_id].push(c)
        }
    })
    return map
})

const form = useForm({
    name: '',
    description: '',
    service_category_id: '',
    price: '',
    duration: '',
    image: null
})

function onFileChange(e) {
    form.image = e.target.files[0]
}

function submit() {
    form.post(route('owner.services.store'))
}
</script>
