<template>
    <OwnerLayout>

        <Head :title="`Izmeni Uslugu #${service.id}`" />
        <div class="container mx-auto px-4 pt-20">
            <div class="card bg-base-100 shadow max-w-lg mx-auto">
                <div class="card-body">
                    <h1 class="card-title mb-6">Izmeni Uslugu</h1>
                    <form @submit.prevent="submit" class="space-y-6">
                        <!-- Naziv -->
                        <div>
                            <label class="label"><span class="label-text">Naziv</span></label>
                            <input v-model="form.name" name="name" type="text" placeholder="Unesite naziv usluge"
                                class="input input-bordered w-full" />
                            <p v-if="form.errors.name" class="text-error text-sm">{{ form.errors.name }}</p>
                        </div>

                        <!-- Opis -->
                        <div>
                            <label class="label"><span class="label-text">Opis</span></label>
                            <textarea v-model="form.description" name="description" placeholder="Unesite opis (opciono)"
                                class="textarea textarea-bordered w-full" rows="4"></textarea>
                            <p v-if="form.errors.description" class="text-error text-sm">{{ form.errors.description }}
                            </p>
                        </div>

                        <!-- Kategorija -->
                        <div>
                            <label class="label"><span class="label-text">Kategorija usluge</span></label>
                            <select v-model="form.service_category_id" class="select select-bordered w-full">
                                <option value="">-- izaberi kategoriju --</option>
                                <option v-for="cat in categories" :key="cat.id" :value="cat.id">{{ cat.name }}</option>
                            </select>
                            <p v-if="form.errors.service_category_id" class="text-error text-sm">{{
                                form.errors.service_category_id }}</p>
                        </div>

                        <!-- Cena -->
                        <div>
                            <label class="label"><span class="label-text">Cena ($)</span></label>
                            <input v-model="form.price" name="price" type="number" step="0.01" placeholder="npr. 49.99"
                                class="input input-bordered w-full" />
                            <p v-if="form.errors.price" class="text-error text-sm">{{ form.errors.price }}</p>
                        </div>

                        <!-- Trajanje -->
                        <div>
                            <label class="label"><span class="label-text">Trajanje (min)</span></label>
                            <input v-model="form.duration" name="duration" type="number" placeholder="npr. 30"
                                class="input input-bordered w-full" />
                            <p v-if="form.errors.duration" class="text-error text-sm">{{ form.errors.duration }}</p>
                        </div>

                        <!-- Photo Upload -->
                        <div>
                            <label class="label">
                                <span class="label-text">Photo</span>
                            </label>
                            <input id="photo" name="photo" type="file" accept="image/*" @change="onPhotoChange"
                                class="file-input file-input-bordered w-full" />
                            <p v-if="form.errors.photo" class="text-error text-sm">
                                {{ form.errors.photo }}
                            </p>
                            <div v-if="previewUrl" class="mt-2">
                                <img :src="previewUrl" alt="Preview" class="h-32 w-full object-cover rounded-lg border"
                                    @error="onImageError" />
                            </div>
                        </div>

                        <!-- Dugmad -->
                        <div class="flex justify-between">
                            <Link :href="route('owner.services.index')" class="btn btn-ghost">Otkaži</Link>
                            <button type="submit" class="btn btn-primary" :disabled="form.processing">
                                {{ form.processing ? 'Ažuriranje...' : 'Ažuriraj' }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </OwnerLayout>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useForm, Head, Link } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'

// Props must now include categories
const props = defineProps({ service: Object, categories: Array, selectedCategoryId: Number })

const form = useForm({
    name: props.service.name,
    description: props.service.description,
    service_category_id: props.selectedCategoryId || '',
    price: props.service.price,
    duration: props.service.duration,
    image: null,
    _method: 'PUT',
})

const localPreview = ref(null)

const previewUrl = computed(() => {
    if (localPreview.value) return localPreview.value
    if (props.service?.icon) return route('photos.show', { folder: null, filename: props.service.icon })
    return null
})

function onPhotoChange(e) {
    const file = e.target.files[0]
    if (!file) return
    form.photo = file
    localPreview.value = URL.createObjectURL(file)
}


function submit() {
    form.post(route('owner.services.update', props.service.id), { preserveScroll: true })
}
</script>

<style scoped>
/* No additional styles needed */
</style>
