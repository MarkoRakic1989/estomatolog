<template>
    <OwnerLayout>
        <div class="container mx-auto px-4 pt-20">
            <!-- Title and New Service Button -->
            <div class="card bg-base-100 shadow mb-6">
                <div class="card-body flex justify-between items-center">
                    <h1 class="card-title">Services</h1>
                    <Link :href="route('owner.services.create')" class="btn btn-primary">
                    New Service
                    </Link>
                </div>
            </div>

            <!-- Services Table -->
            <div class="overflow-x-auto card bg-base-100 shadow p-4">
                <table class="table table-zebra w-full">
                    <thead>
                        <tr>
                            <th class="text-center">Self-bookable</th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Duration</th>
                            <th class="text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="svc in services.data" :key="svc.id">
                            <td class="text-center">
                                <input type="checkbox" class="toggle toggle-primary" :checked="svc.self_bookable"
                                    @change="toggleSelfBookable(svc.id, $event.target.checked)" />
                            </td>
                            <td>
                                <img v-if="svc.icon" :src="route('photos.show', { folder: null, filename: svc.icon })"
                                    alt="" class="w-24 h-16 object-cover rounded" />
                            </td>
                            <td>{{ svc.name }}</td>
                            <td>{{ svc.price }}$</td>
                            <td>{{ svc.duration }} min</td>
                            <td class="text-right space-x-2">
                                <Link :href="route('owner.services.edit', svc.id)" class="btn btn-sm btn-outline">
                                Edit
                                </Link>
                                <button class="btn btn-sm btn-error btn-outline" @click="destroy(svc.id)">
                                    Delete
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="mt-4 flex justify-center">
                <button v-for="link in services.links" :key="link.label" v-html="link.label" :disabled="!link.url"
                    @click="goTo(link.url)" :class="[
                        'btn btn-sm mx-1',
                        link.active ? 'btn-primary' : 'btn-outline'
                    ]"></button>
            </div>
        </div>
    </OwnerLayout>
</template>

<script setup>
import { Link, router } from '@inertiajs/vue3'
import { Head } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'

const props = defineProps({
    services: Object,
})

function destroy(id) {
    if (confirm('Delete this service?')) {
        router.delete(route('owner.services.destroy', id))
    }
}

function goTo(url) {
    router.get(url, {}, { preserveState: true, preserveScroll: true })
}

function toggleSelfBookable(id, value) {
    router.patch(
        route('owner.services.toggleSelfBookable', id),
        { self_bookable: value },
        { preserveState: true }
    )
}
</script>

<style scoped>
/* No additional styles needed */
</style>
