<template>
  <OwnerLayout>
    <div class="container mx-auto px-4 pt-20 space-y-6">
      <h1 class="text-2xl font-bold">Podešavanje uloga</h1>
      <div v-for="user in users" :key="user.id" class="card bg-base-100 shadow p-4">
        <h2 class="text-lg font-semibold mb-4">
          {{ user.name }} <span class="text-sm text-gray-500">({{ user.email }})</span>
        </h2>
        <form @submit.prevent="updateRoles(user.id)" class="flex flex-wrap items-center gap-4">
          <div v-for="role in roles" :key="role.id" class="flex items-center space-x-2">
            <input type="checkbox" :id="`role-${user.id}-${role.name}`" v-model="form[user.id]" :value="role.name"
              class="checkbox
         focus:outline-none focus:ring-0
         hover:bg-transparent" />
            <label :for="`role-${user.id}-${role.name}`" class="label-text">
              {{ role.name }}
            </label>
          </div>
          <PrimaryButton class="ml-auto">
            Sačuvaj
          </PrimaryButton>
        </form>
      </div>
    </div>
  </OwnerLayout>
</template>

<script setup>
import { reactive } from 'vue'
import { usePage, router } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'
import PrimaryButton from '@/Components/PrimaryButton.vue'

const { users, roles } = usePage().props

const form = reactive({})
users.forEach(u => {
  form[u.id] = u.roles.map(r => r.name)
})

function updateRoles(userId) {
  router.post(
    route('owner.settings.roles.update'),
    { user_id: userId, roles: form[userId] }
  )
}
</script>


<style scoped>
.checkbox:hover,
.checkbox:focus {
  background-color: transparent !important;
  box-shadow: none !important;
  outline: none !important;
}
</style>