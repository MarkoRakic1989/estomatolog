<template>
  <OwnerLayout>
    <div class="container mx-auto px-6 py-8 mt-6">
      <h1 class="text-2xl font-bold mb-6">Pretplata i paketi</h1>

      <!-- Aktivni paket -->
      <div class="mb-10">
        <div class="card shadow-lg bg-base-100">
          <div class="card-body">
            <h2 class="card-title">
              <span v-if="current" class="badge badge-success">Aktivni paket</span>
              <span v-else class="badge badge-error">Nema aktivne pretplate</span>
            </h2>
            <div v-if="current">
              <div class="flex items-center flex-wrap gap-4">
                <div>
                  <b>Paket:</b> {{ current.package?.name || 'N/A' }}
                </div>
                <div>
                  <b>Status:</b>
                  <span :class="{
                    'badge badge-success': current.status === 'active',
                    'badge badge-warning': current.status === 'pending',
                    'badge badge-error': current.status === 'expired'
                  }">{{ statusLabel(current.status) }}</span>
                </div>
                <div>
                  <b>Važi do:</b>
                  <span>{{ new Date(current.ends_at).toLocaleDateString('sr-RS') }}</span>
                </div>
              </div>
              <div v-html="current.package?.description" class="prose mt-3"></div>
              <button v-if="current.status === 'pending'" class="btn btn-warning mt-4" @click="showNotify = true">
                Obavesti admina da sam uplatio
              </button>
            </div>
            <div v-else>
              <p>Nemate aktivnu pretplatu. Izaberite paket ispod da biste nastavili korišćenje platforme.</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Izbor paketa -->
      <div>
        <h2 class="text-xl font-semibold mb-4">Izaberite paket</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div v-for="p in packages" :key="p.id" class="card shadow bg-base-100 border"
            :class="{ 'ring-2 ring-primary': current?.package_id === p.id }">
            <div class="card-body">
              <h3 class="card-title text-lg mb-2">{{ p.name }}</h3>
              <div class="mb-2 text-2xl font-bold text-primary">{{ Math.round(p.price) }} RSD / mesec</div>
              <div class="prose" v-html="p.description"></div>
              <button class="btn btn-primary mt-4"
                :disabled="current?.package_id === p.id && current.status === 'active'" @click="openRequestModal(p)">
                {{
                  current?.package_id === p.id && current.status === 'active'
                    ? 'Vaš trenutni paket'
                    : 'Zatraži paket'
                }}
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Istorija uplata -->
      <div v-if="payments.length" class="mt-12">
        <h2 class="text-xl font-semibold mb-4">Istorija uplata</h2>
        <div class="overflow-x-auto">
          <table class="table table-zebra w-full">
            <thead>
              <tr>
                <th>Iznos</th>
                <th>Status</th>
                <th>Datum uplate</th>
                <th>Poziv na broj</th>
                <th>Napomena</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="pay in payments" :key="pay.id">
                <td>{{ pay.amount }} RSD</td>
                <td>
                  <span :class="{
                    'badge badge-success': pay.status === 'confirmed',
                    'badge badge-warning': pay.status === 'pending',
                    'badge badge-error': pay.status === 'rejected'
                  }">{{ statusLabel(pay.status) }}</span>
                </td>
                <td>{{ pay.paid_at ? new Date(pay.paid_at).toLocaleDateString('sr-RS') : '-' }}</td>
                <td>{{ pay.reference_number || '-' }}</td>
                <td>{{ pay.note || '-' }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- MODAL za zahtev novog paketa -->
      <input type="checkbox" id="modal-request" class="modal-toggle" v-model="showRequest" />
      <div class="modal" v-if="showRequest">
        <div class="modal-box">
          <h3 class="font-bold text-lg mb-4">Potvrda narudžbine paketa</h3>
          <div class="mb-4">
            Da li ste sigurni da želite da naručite paket <b>{{ selectedPackage?.name }}</b>?
          </div>
          <div class="mb-4" v-html="selectedPackage?.description"></div>
          <div class="flex justify-end gap-2">
            <button class="btn btn-ghost" @click="showRequest = false">Otkaži</button>
            <button class="btn btn-primary" @click="sendRequest">Potvrdi</button>
          </div>
        </div>
      </div>

      <!-- MODAL za notifikaciju adminu -->
      <input type="checkbox" id="modal-notify" class="modal-toggle" v-model="showNotify" />
      <div class="modal" v-if="showNotify">
        <div class="modal-box">
          <h3 class="font-bold text-lg mb-4">Obavesti admina o uplati</h3>
          <form @submit.prevent="notifyAdmin">
            <div class="form-control mb-3">
              <label class="label"><span class="label-text">Poziv na broj / referenca</span></label>
              <input v-model="notifyForm.reference_number" type="text" class="input input-bordered" />
            </div>
            <div class="form-control mb-3">
              <label class="label"><span class="label-text">Napomena (opciono)</span></label>
              <textarea v-model="notifyForm.note" class="textarea textarea-bordered"></textarea>
            </div>
            <div class="flex justify-end gap-2">
              <button class="btn btn-ghost" @click.prevent="showNotify = false">Otkaži</button>
              <button class="btn btn-primary" type="submit">Pošalji obaveštenje</button>
            </div>
          </form>
        </div>
      </div>

    </div>
  </OwnerLayout>
</template>

<script setup>
import { ref } from 'vue'
import { router } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'

const props = defineProps({
  current: Object,
  packages: Array,
  payments: Array,
})

function statusLabel(status) {
  switch (status) {
    case 'active': return 'Aktivan'
    case 'pending': return 'Čeka uplatu'
    case 'expired': return 'Istekao'
    case 'confirmed': return 'Potvrđeno'
    case 'rejected': return 'Odbijeno'
    default: return status
  }
}

const showRequest = ref(false)
const selectedPackage = ref(null)
function openRequestModal(pkg) {
  selectedPackage.value = pkg
  showRequest.value = true
}
function sendRequest() {
  router.post(route('owner.subscription.request'), {
    package_id: selectedPackage.value.id
  }, {
    onSuccess: () => {
      showRequest.value = false
    }
  })
}

// Notifikacija adminu
const showNotify = ref(false)
const notifyForm = ref({ reference_number: '', note: '' })
function notifyAdmin() {
  router.post(route('owner.subscription.notify'), {
    reference_number: notifyForm.value.reference_number,
    note: notifyForm.value.note
  }, {
    onSuccess: () => {
      showNotify.value = false
      notifyForm.value = { reference_number: '', note: '' }
    }
  })
}
</script>
