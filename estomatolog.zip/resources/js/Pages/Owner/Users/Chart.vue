<template>
  <OwnerLayout>
    <template #header>
      <h1 class="text-2xl font-bold">Karton pacijenta</h1>
    </template>
    <div class="container mx-auto px-4 pt-20">
      <div class="text-gray-500 text-sm mb-8">Izaberi sekciju kartona</div>
      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6">
        <DashboardCard icon="user"      label="Osnovni podaci"      :href="route('owner.users.chart.basic', user.id)" />
        <DashboardCard icon="tooth"     label="Odontogram"          :href="route('owner.users.chart.odontogram', user.id)" />
        <DashboardCard icon="image"     label="Dokumenti"           :href="route('owner.users.chart.documents', user.id)" />
        <DashboardCard icon="heart"     label="Anamneza"            :href="route('owner.users.chart.anamnesis', user.id)" />
        <DashboardCard icon="credit-card" label="Finansije"         :href="route('owner.users.chart.financial', user.id)" />
        <DashboardCard icon="package"   label="Materijali"          :href="route('owner.users.chart.materials', user.id)" />
      </div>
    </div>
  </OwnerLayout>
</template>

<script setup>
import OwnerLayout from '@/Layouts/OwnerLayout.vue'
import DashboardCard from '@/Components/DashboardCard.vue'
defineProps({ user: Object })
</script>
