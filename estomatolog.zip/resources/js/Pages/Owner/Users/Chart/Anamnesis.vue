<script setup>
import { useForm, Link } from '@inertiajs/vue3'
import OwnerLayout from '../../../../Layouts/OwnerLayout.vue'

// Props: chart instance with anamnesis fields if already filled.
const props = defineProps({
  chart: Object,
  user: Object,
})

// Inicijalizacija forme sa postojećim vrednostima ili defaultima.
const form = useForm({
  chronic_diseases: Boolean(props.chart.chronic_diseases),
  smoker: Boolean(props.chart.smoker),
  alcohol: Boolean(props.chart.alcohol),
  anticoagulant_therapy: Boolean(props.chart.anticoagulant_therapy),
  infectious_diseases: Boolean(props.chart.infectious_diseases),
  malignant_diseases: Boolean(props.chart.malignant_diseases),
  regular_therapy: Boolean(props.chart.regular_therapy),
  cardiovascular_diseases: Boolean(props.chart.cardiovascular_diseases),
  other_notes: props.chart.other_notes || '',
})

function submit() {
  // Koristi owner prefiks i šalje ID pacijenta, ne ID kartona
  form.put(route('owner.users.chart.anamnesis.update', props.user.id))
}
</script>

<template>
  <OwnerLayout>
    <div class="container mx-auto px-4 pt-20">
      <div class="card bg-base-100 shadow mb-6">
        <div class="card-body flex justify-between items-center">
          <h1 class="text-2xl font-bold">Anamneza</h1>
          <Link :href="route('owner.users.chart.dashboard', props.user.id)" class="btn btn-outline btn-sm">
            <svg class="inline-block w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
            Nazad na karton
          </Link>
        </div>
      </div>
      <div class="card bg-base-100 shadow">
        <div class="card-body">
          <form @submit.prevent="submit" class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="flex items-center">
          <input type="checkbox" id="chronic" v-model="form.chronic_diseases" class="mr-2" />
          <label for="chronic" class="font-medium">Hronične bolesti</label>
        </div>
        <div class="flex items-center">
          <input type="checkbox" id="smoker" v-model="form.smoker" class="mr-2" />
          <label for="smoker" class="font-medium">Pušač</label>
        </div>
        <div class="flex items-center">
          <input type="checkbox" id="alcohol" v-model="form.alcohol" class="mr-2" />
          <label for="alcohol" class="font-medium">Konzumira alkohol</label>
        </div>
        <div class="flex items-center">
          <input type="checkbox" id="anticoagulant" v-model="form.anticoagulant_therapy" class="mr-2" />
          <label for="anticoagulant" class="font-medium">Antikoagulantna terapija</label>
        </div>
        <div class="flex items-center">
          <input type="checkbox" id="infectious" v-model="form.infectious_diseases" class="mr-2" />
          <label for="infectious" class="font-medium">Infektivne bolesti</label>
        </div>
        <div class="flex items-center">
          <input type="checkbox" id="malignant" v-model="form.malignant_diseases" class="mr-2" />
          <label for="malignant" class="font-medium">Maligne bolesti</label>
        </div>
        <div class="flex items-center">
          <input type="checkbox" id="regular" v-model="form.regular_therapy" class="mr-2" />
          <label for="regular" class="font-medium">Redovne terapije</label>
        </div>
        <div class="flex items-center">
          <input type="checkbox" id="cardio" v-model="form.cardiovascular_diseases" class="mr-2" />
          <label for="cardio" class="font-medium">Kardiovaskularne bolesti</label>
        </div>
            </div>
            <div>
              <label class="block font-medium mb-1">Ostale napomene</label>
              <textarea v-model="form.other_notes" class="w-full border rounded p-2" rows="3"></textarea>
              <div v-if="form.errors.other_notes" class="text-red-500 text-sm mt-1">{{ form.errors.other_notes }}</div>
            </div>
            <div class="flex justify-end mt-4">
              <button type="submit" class="btn btn-primary" :disabled="form.processing">Sačuvaj</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </OwnerLayout>
</template>

