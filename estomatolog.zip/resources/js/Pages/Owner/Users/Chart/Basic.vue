<template>
  <OwnerLayout>
    <div class="container mx-auto px-4 pt-20">

        <!-- Title and New Service Button -->
        <div class="card bg-base-100 shadow mb-6">
            <div class="card-body flex justify-between items-center">
                <h1 class="text-2xl font-bold">Osnovni podaci o pacijentu</h1>
                <Link :href="route('owner.users.chart.dashboard', user.id)" class="btn btn-outline btn-sm">
                <svg class="inline-block w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
                Nazad na karton
                </Link>
            </div>
        </div>
      <div v-if="!editMode" class="max-w-md mx-auto card bg-base-100 shadow p-8 space-y-6">
        <div>
          <div class="font-semibold text-gray-600 mb-2">Ime i prezime</div>
          <div class="input input-bordered w-full bg-gray-100 pointer-events-none select-none">{{ user.name }}</div>
        </div>
        <div>
          <div class="font-semibold text-gray-600 mb-2">Email</div>
          <div class="input input-bordered w-full bg-gray-100 pointer-events-none select-none">{{ user.email }}</div>
        </div>
        <div>
          <div class="font-semibold text-gray-600 mb-2">Telefon</div>
          <div class="input input-bordered w-full bg-gray-100 pointer-events-none select-none">{{ user.phone || 'Nije unet' }}</div>
        </div>
        <div>
          <div class="font-semibold text-gray-600 mb-2">Godište (datum rođenja)</div>
          <div class="input input-bordered w-full bg-gray-100 pointer-events-none select-none">
            {{ user.date_of_birth ? formatDate(user.date_of_birth) : 'Nije uneto' }}
          </div>
        </div>
        <div>
          <div class="font-semibold text-gray-600 mb-2">Alergije</div>
          <div class="input input-bordered w-full bg-gray-100 pointer-events-none select-none">{{ user.allergies || 'Nema podataka' }}</div>
        </div>
        <div>
          <div class="font-semibold text-gray-600 mb-2">Medicinske napomene</div>
          <div class="input input-bordered w-full bg-gray-100 pointer-events-none select-none">{{ user.medical_notes || '-' }}</div>
        </div>
        <div class="flex justify-end pt-2">
          <button class="btn btn-primary" @click="editMode = true">Izmeni podatke</button>
        </div>
      </div>

      <form v-else @submit.prevent="submit" class="max-w-md mx-auto card bg-base-100 shadow p-8 space-y-6">
        <div>
          <div class="font-semibold text-gray-600 mb-2">Ime i prezime</div>
          <div class="input input-bordered w-full bg-gray-100 pointer-events-none select-none">{{ user.name }}</div>
        </div>
        <div>
          <div class="font-semibold text-gray-600 mb-2">Email</div>
          <div class="input input-bordered w-full bg-gray-100 pointer-events-none select-none">{{ user.email }}</div>
        </div>
        <div>
          <label class="font-semibold text-gray-600 mb-2">Telefon</label>
          <input v-model="form.phone" class="input input-bordered w-full" />
        </div>
        <div>
          <label class="font-semibold text-gray-600 mb-2">Godište (datum rođenja)</label>
          <input v-model="form.date_of_birth" class="input input-bordered w-full" type="date" />
        </div>
        <div>
          <label class="font-semibold text-gray-600 mb-2">Alergije</label>
          <textarea v-model="form.allergies" class="textarea textarea-bordered w-full" rows="2"></textarea>
        </div>
        <div>
          <label class="font-semibold text-gray-600 mb-2">Medicinske napomene</label>
          <textarea v-model="form.medical_notes" class="textarea textarea-bordered w-full" rows="2"></textarea>
        </div>
        <div class="flex justify-between pt-2">
          <button class="btn btn-outline" type="button" @click="cancelEdit" :disabled="processing">
            Otkaži
          </button>
          <button class="btn btn-primary" type="submit" :disabled="processing">
            Sačuvaj izmene
          </button>
        </div>
      </form>
    </div>
  </OwnerLayout>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { Link, router } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'
const props = defineProps({ user: Object })

const editMode = ref(false)
const processing = ref(false)
const success = ref('')

const form = reactive({
  phone: props.user.phone ?? '',
  date_of_birth: props.user.date_of_birth ?? '',
  allergies: props.user.allergies ?? '',
  medical_notes: props.user.medical_notes ?? ''
})

function submit() {
  processing.value = true
  router.put(route('owner.users.chart.basic.update', props.user.id), form, {
    onSuccess: () => {
      success.value = 'Podaci su sačuvani.'
      editMode.value = false
      processing.value = false
      setTimeout(() => { success.value = '' }, 1800)
    },
    onError: () => {
      processing.value = false
    }
  })
}

function cancelEdit() {
  form.phone = props.user.phone ?? ''
  form.date_of_birth = props.user.date_of_birth ?? ''
  form.allergies = props.user.allergies ?? ''
  form.medical_notes = props.user.medical_notes ?? ''
  editMode.value = false
}

function formatDate(dateStr) {
  if (!dateStr) return ''
  const [y, m, d] = dateStr.split('-')
  return `${d}.${m}.${y}.`
}
</script>
