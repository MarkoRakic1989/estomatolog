<script setup>
import { ref } from 'vue'
import { useForm, Link } from '@inertiajs/vue3'
import OwnerLayout from '../../../../Layouts/OwnerLayout.vue'

// Props: chart and existing documents
const props = defineProps({
  chart: Object,
  documents: Array,
  user: Object,
})

// Forma za upload novog dokumenta
const uploadForm = useForm({
  file: null,
  type: '',
  title: '',
  note: '',
  tooth_id: '',
})

// Podržani tipovi dokumenata
const docTypes = ['RTG snimak', 'Izveštaj', 'Fotografija', 'Nalaz', 'Ostalo']

// Upload file funkcija
function submit() {
  // Snima dokument u owner sekciji koristeći ID pacijenta
  uploadForm.post(route('owner.users.chart.documents.upload', props.user.id), {
    forceFormData: true,
    onSuccess: () => uploadForm.reset('file', 'type', 'title', 'note', 'tooth_id'),
  })
}

// Biranje fajla
function handleFileChange(event) {
  uploadForm.file = event.target.files[0]
}
</script>

<template>
  <OwnerLayout>
    <div class="container mx-auto px-4 pt-20">
      <div class="card bg-base-100 shadow mb-6">
        <div class="card-body flex justify-between items-center">
          <h1 class="text-2xl font-bold">Dokumenti</h1>
          <Link :href="route('owner.users.chart.dashboard', props.user.id)" class="btn btn-outline btn-sm">
            <svg class="inline-block w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
            Nazad na karton
          </Link>
        </div>
      </div>
      <!-- Forma za upload novog dokumenta -->
      <form @submit.prevent="submit" class="bg-white border p-4 rounded mb-6">
      <h2 class="text-lg font-semibold mb-2">Dodaj dokument</h2>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label class="block font-medium mb-1">Tip dokumenta</label>
          <select v-model="uploadForm.type" class="w-full border rounded p-2">
            <option value="">Odaberi tip</option>
            <option v-for="dt in docTypes" :key="dt" :value="dt">{{ dt }}</option>
          </select>
          <div v-if="uploadForm.errors.type" class="text-red-500 text-sm mt-1">{{ uploadForm.errors.type }}</div>
        </div>
        <div>
          <label class="block font-medium mb-1">Naziv</label>
          <input v-model="uploadForm.title" type="text" class="w-full border rounded p-2" />
          <div v-if="uploadForm.errors.title" class="text-red-500 text-sm mt-1">{{ uploadForm.errors.title }}</div>
        </div>
        <div>
          <label class="block font-medium mb-1">Zub (opciono)</label>
          <input v-model="uploadForm.tooth_id" type="text" class="w-full border rounded p-2" placeholder="Šifra zuba (npr. 46)" />
        </div>
        <div>
          <label class="block font-medium mb-1">Fajl</label>
          <input @change="handleFileChange" type="file" class="w-full" />
          <div v-if="uploadForm.errors.file" class="text-red-500 text-sm mt-1">{{ uploadForm.errors.file }}</div>
        </div>
        <div class="md:col-span-2">
          <label class="block font-medium mb-1">Napomena</label>
          <textarea v-model="uploadForm.note" class="w-full border rounded p-2" rows="2"></textarea>
        </div>
      </div>
      <div class="flex justify-end mt-4">
        <button type="submit" class="btn btn-primary" :disabled="uploadForm.processing">Sačuvaj</button>
      </div>
    </form>
      <!-- Lista postojećih dokumenata -->
      <table class="min-w-full border">
      <thead>
        <tr class="bg-gray-200">
          <th class="p-2">Tip</th>
          <th class="p-2">Naziv</th>
          <th class="p-2">Zub</th>
          <th class="p-2">Napomena</th>
          <th class="p-2">Preuzmi</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="doc in (documents || [])" :key="doc.id" class="border-b">
          <td class="p-2">{{ doc.type }}</td>
          <td class="p-2">{{ doc.title }}</td>
          <td class="p-2">{{ doc.tooth ? doc.tooth.code : '-' }}</td>
          <td class="p-2">{{ doc.note }}</td>
          <td class="p-2">
            <a :href="doc.file" class="text-blue-500 underline" target="_blank">Preuzmi</a>
          </td>
        </tr>
        <tr v-if="!documents || documents.length === 0">
          <td colspan="5" class="p-4 text-center text-gray-500">Nema dokumenata</td>
        </tr>
      </tbody>
      </table>
    </div>
  </OwnerLayout>
</template>
