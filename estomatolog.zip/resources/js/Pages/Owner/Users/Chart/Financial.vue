<script setup>
import { ref } from 'vue'
import { useForm, Link } from '@inertiajs/vue3'
import OwnerLayout from '../../../../Layouts/OwnerLayout.vue'

// Props: chart, invoices i estimates
const props = defineProps({
  chart: Object,
  invoices: Array,
  estimates: Array,
  user: Object,
})

// Forme za unos fakture i predračuna
const invoiceForm = useForm({
  invoice_date: '',
  total: '',
  status: 'izdato',
})

const estimateForm = useForm({
  estimate_date: '',
  total: '',
  status: 'draft',
})

function submitInvoice() {
  // Snimi račun koristeći owner rutu i ID pacijenta
  invoiceForm.post(route('owner.users.chart.financial.save_invoice', props.user.id), {
    onSuccess: () => invoiceForm.reset('invoice_date', 'total', 'status'),
  })
}

function submitEstimate() {
  // Snimi predračun koristeći owner rutu i ID pacijenta
  estimateForm.post(route('owner.users.chart.financial.save_estimate', props.user.id), {
    onSuccess: () => estimateForm.reset('estimate_date', 'total', 'status'),
  })
}
</script>

<template>
  <OwnerLayout>
    <div class="container mx-auto px-4 pt-20">
      <div class="card bg-base-100 shadow mb-6">
        <div class="card-body flex justify-between items-center">
          <h1 class="text-2xl font-bold">Finansije</h1>
          <Link :href="route('owner.users.chart.dashboard', props.user.id)" class="btn btn-outline btn-sm">
            <svg class="inline-block w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
            Nazad na karton
          </Link>
        </div>
      </div>
    </div>
    <!-- Forma za unos predračuna -->
    <div class="mb-6 bg-white border p-4 rounded">
      <h2 class="text-lg font-semibold mb-2">Dodaj predračun</h2>
      <form @submit.prevent="submitEstimate" class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label class="block font-medium mb-1">Datum</label>
          <input type="date" v-model="estimateForm.estimate_date" class="w-full border rounded p-2" />
          <div v-if="estimateForm.errors.estimate_date" class="text-red-500 text-sm mt-1">{{ estimateForm.errors.estimate_date }}</div>
        </div>
        <div>
          <label class="block font-medium mb-1">Ukupan iznos (RSD)</label>
          <input type="number" step="0.01" v-model="estimateForm.total" class="w-full border rounded p-2" />
          <div v-if="estimateForm.errors.total" class="text-red-500 text-sm mt-1">{{ estimateForm.errors.total }}</div>
        </div>
        <div>
          <label class="block font-medium mb-1">Status</label>
          <select v-model="estimateForm.status" class="w-full border rounded p-2">
            <option value="draft">U pripremi</option>
            <option value="sent">Poslato</option>
            <option value="approved">Odobreno</option>
          </select>
        </div>
        <div class="md:col-span-3 flex justify-end">
          <button type="submit" class="btn btn-primary" :disabled="estimateForm.processing">Sačuvaj predračun</button>
        </div>
      </form>
    </div>
    <!-- Forma za unos fakture -->
    <div class="mb-6 bg-white border p-4 rounded">
      <h2 class="text-lg font-semibold mb-2">Dodaj račun</h2>
      <form @submit.prevent="submitInvoice" class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label class="block font-medium mb-1">Datum</label>
          <input type="date" v-model="invoiceForm.invoice_date" class="w-full border rounded p-2" />
          <div v-if="invoiceForm.errors.invoice_date" class="text-red-500 text-sm mt-1">{{ invoiceForm.errors.invoice_date }}</div>
        </div>
        <div>
          <label class="block font-medium mb-1">Ukupan iznos (RSD)</label>
          <input type="number" step="0.01" v-model="invoiceForm.total" class="w-full border rounded p-2" />
          <div v-if="invoiceForm.errors.total" class="text-red-500 text-sm mt-1">{{ invoiceForm.errors.total }}</div>
        </div>
        <div>
          <label class="block font-medium mb-1">Status</label>
          <select v-model="invoiceForm.status" class="w-full border rounded p-2">
            <option value="izdato">Izdato</option>
            <option value="plaćeno">Plaćeno</option>
            <option value="stornirano">Stornirano</option>
          </select>
        </div>
        <div class="md:col-span-3 flex justify-end">
          <button type="submit" class="btn btn-primary" :disabled="invoiceForm.processing">Sačuvaj račun</button>
        </div>
      </form>
    </div>
    <!-- Tabela predračuna -->
    <div class="mb-6">
      <h2 class="text-lg font-semibold mb-2">Predračuni</h2>
      <table class="min-w-full border">
        <thead>
          <tr class="bg-gray-200">
            <th class="p-2">Datum</th>
            <th class="p-2">Ukupno</th>
            <th class="p-2">Status</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="est in (estimates || [])" :key="est.id" class="border-b">
            <td class="p-2">{{ est.estimate_date }}</td>
            <td class="p-2">{{ est.total }}</td>
            <td class="p-2">{{ est.status }}</td>
          </tr>
          <tr v-if="!estimates || estimates.length === 0">
            <td colspan="3" class="p-4 text-center text-gray-500">Nema predračuna</td>
          </tr>
        </tbody>
      </table>
    </div>
    <!-- Tabela računa -->
    <div>
      <h2 class="text-lg font-semibold mb-2">Računi</h2>
      <table class="min-w-full border">
        <thead>
          <tr class="bg-gray-200">
            <th class="p-2">Datum</th>
            <th class="p-2">Ukupno</th>
            <th class="p-2">Status</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="inv in (invoices || [])" :key="inv.id" class="border-b">
            <td class="p-2">{{ inv.invoice_date }}</td>
            <td class="p-2">{{ inv.total }}</td>
            <td class="p-2">{{ inv.status }}</td>
          </tr>
          <tr v-if="!invoices || invoices.length === 0">
            <td colspan="3" class="p-4 text-center text-gray-500">Nema računa</td>
          </tr>
        </tbody>
      </table>
    </div>
  </OwnerLayout>
</template>
