<script setup>
import { ref } from 'vue'
import { useForm, Link } from '@inertiajs/vue3'
import OwnerLayout from '../../../../Layouts/OwnerLayout.vue'

const props = defineProps({
  chart: Object,
  materials: Array,
  materialTypes: Array,
  user: Object,
})

// Forma za dodavanje materijala
const materialForm = useForm({
  material_type_id: '',
  quantity: '',
  unit: '',
  used_at: '',
})

function submitMaterial() {
  // Snimi materijal na owner ruti koristeći ID pacijenta
  materialForm.post(route('owner.users.chart.materials.save', props.user.id), {
    onSuccess: () => materialForm.reset('material_type_id', 'quantity', 'unit', 'used_at'),
  })
}
</script>

<template>
  <OwnerLayout>
    <div class="container mx-auto px-4 pt-20">
      <div class="card bg-base-100 shadow mb-6">
        <div class="card-body flex justify-between items-center">
          <h1 class="text-2xl font-bold">Materijali</h1>
          <Link :href="route('owner.users.chart.dashboard', props.user.id)" class="btn btn-outline btn-sm">
            <svg class="inline-block w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
            Nazad na karton
          </Link>
        </div>
      </div>
      <!-- Forma za dodavanje materijala -->
      <div class="mb-6 bg-white border p-4 rounded">
        <h2 class="text-lg font-semibold mb-2">Dodaj materijal</h2>
        <form @submit.prevent="submitMaterial" class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div>
          <label class="block font-medium mb-1">Vrsta materijala</label>
          <select v-model="materialForm.material_type_id" class="w-full border rounded p-2">
            <option value="">Odaberite</option>
            <option v-for="mt in (materialTypes || [])" :key="mt.id" :value="mt.id">{{ mt.name }}</option>
          </select>
          <div v-if="materialForm.errors.material_type_id" class="text-red-500 text-sm mt-1">{{ materialForm.errors.material_type_id }}</div>
        </div>
        <div>
          <label class="block font-medium mb-1">Količina</label>
          <input type="number" step="0.001" v-model="materialForm.quantity" class="w-full border rounded p-2" />
          <div v-if="materialForm.errors.quantity" class="text-red-500 text-sm mt-1">{{ materialForm.errors.quantity }}</div>
        </div>
        <div>
          <label class="block font-medium mb-1">Jedinica</label>
          <input type="text" v-model="materialForm.unit" class="w-full border rounded p-2" />
        </div>
        <div>
          <label class="block font-medium mb-1">Datum upotrebe</label>
          <input type="date" v-model="materialForm.used_at" class="w-full border rounded p-2" />
          <div v-if="materialForm.errors.used_at" class="text-red-500 text-sm mt-1">{{ materialForm.errors.used_at }}</div>
        </div>
        <div class="md:col-span-4 flex justify-end">
          <button type="submit" class="btn btn-primary" :disabled="materialForm.processing">Sačuvaj</button>
        </div>
      </form>
    </div>
    <!-- Lista materijala -->
    <table class="min-w-full border">
      <thead>
        <tr class="bg-gray-200">
          <th class="p-2">Vrsta</th>
          <th class="p-2">Količina</th>
          <th class="p-2">Jedinica</th>
          <th class="p-2">Datum upotrebe</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="mat in (materials || [])" :key="mat.id" class="border-b">
          <td class="p-2">{{ mat.material_type ? mat.material_type.name : '-' }}</td>
          <td class="p-2">{{ mat.quantity }}</td>
          <td class="p-2">{{ mat.unit }}</td>
          <td class="p-2">{{ mat.used_at }}</td>
        </tr>
        <tr v-if="!materials || materials.length === 0">
          <td colspan="4" class="p-4 text-center text-gray-500">Nema unetih materijala</td>
        </tr>
      </tbody>
      </table>
    </div>
  </OwnerLayout>
</template>
