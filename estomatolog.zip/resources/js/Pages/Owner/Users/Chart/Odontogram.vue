<template>
  <OwnerLayout>
    <div class="container mx-auto px-4 pt-20">

        <!-- Title and New Service Button -->
        <div class="card bg-base-100 shadow mb-6">
            <div class="card-body flex justify-between items-center">
                <h1 class="text-2xl font-bold">Odontogram</h1>
                <Link :href="route('owner.users.chart.dashboard', user.id)" class="btn btn-outline btn-sm">
                <svg class="inline-block w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
                Nazad na karton
                </Link>
            </div>
        </div>
    </div>
    <div class="max-w-7xl mx-auto mt-8 card bg-base-100 shadow p-6 overflow-auto">
      <!-- Toggle between permanent and deciduous teeth -->
      <div class="mb-4 flex items-center space-x-2">
        <input
          type="checkbox"
          v-model="dentition"
          true-value="mlečni"
          false-value="stalni"
          id="dentition-toggle"
        />
        <label for="dentition-toggle" class="text-sm">Uključi mlečnu denticiju</label>
      </div>

      <!-- Toolbar shown when surfaces are selected -->
      <div v-if="selectedSurfaces.length" class="flex flex-wrap items-center gap-3 mb-4 p-2 bg-gray-50 rounded-lg">
        <span class="text-sm font-medium">Izabrano: {{ selectedLabel }}</span>
        <button class="btn btn-primary btn-sm" @click="openModal('status')">Status</button>
        <button class="btn btn-primary btn-sm" @click="openModal('therapy')">Terapija</button>
        <button class="btn btn-ghost btn-sm" @click="clearSelection">Očisti</button>
      </div>

      <!-- Teeth grid -->
      <div v-if="!loading">
      <table class="w-full table-fixed border-collapse">
        <tr>
          <td
            v-for="n in quadrants.upperRight"
            :key="'ur-' + n"
            class="p-1 relative"
            :class="{ 'bg-blue-50': isToothSelected(n), 'opacity-40': isExtracted(n) }"
            @click="toggleWholeTooth(n)"
          >
            <span
              v-if="isExtracted(n)"
              class="absolute top-0 right-0 text-red-600 text-xs"
              :title="'Zub izvađen'"
            >✖</span>
            <!-- hide info icon; statuses are shown via tooltip on hover -->
            <div v-if="showImplantSvg(n)" class="svg-container" v-html="getImplantSvg(n)"></div>
            <div
              v-else-if="svgs[n]"
              class="svg-container"
              v-html="svgs[n]"
              @mouseenter="(e) => { if (!isExtracted(n)) bindSvgEvents(e, n) }"
            ></div>
            <!-- no popover needed; all status details are shown via tooltip on hover -->
          </td>
          <td
            v-for="n in quadrants.upperLeft"
            :key="'ul-' + n"
            class="p-1 relative"
            :class="{ 'bg-blue-50': isToothSelected(n), 'opacity-40': isExtracted(n) }"
            @click="toggleWholeTooth(n)"
          >
            <span
              v-if="isExtracted(n)"
              class="absolute top-0 right-0 text-red-600 text-xs"
              :title="'Zub izvađen'"
            >✖</span>
            <!-- hide info icon; statuses are shown via tooltip on hover -->
            <div v-if="showImplantSvg(n)" class="svg-container" v-html="getImplantSvg(n)"></div>
            <div
              v-else-if="svgs[n]"
              class="svg-container"
              v-html="svgs[n]"
              @mouseenter="(e) => { if (!isExtracted(n)) bindSvgEvents(e, n) }"
            ></div>
            <!-- no popover needed; all status details are shown via tooltip on hover -->
          </td>
        </tr>
        <tr>
          <td
            v-for="n in quadrants.lowerRight"
            :key="'lr-' + n"
            class="p-1 relative"
            :class="{ 'bg-blue-50': isToothSelected(n), 'opacity-40': isExtracted(n) }"
            @click="toggleWholeTooth(n)"
          >
            <span
              v-if="isExtracted(n)"
              class="absolute top-0 right-0 text-red-600 text-xs"
              :title="'Zub izvađen'"
            >✖</span>
            <!-- info icon removed; statuses shown via tooltip -->
            <div v-if="showImplantSvg(n)" class="svg-container" v-html="getImplantSvg(n)"></div>
            <div
              v-else-if="svgs[n]"
              class="svg-container"
              v-html="svgs[n]"
              @mouseenter="(e) => { if (!isExtracted(n)) bindSvgEvents(e, n) }"
            ></div>
            <!-- popover removed; statuses shown via tooltip -->
          </td>
          <td
            v-for="n in quadrants.lowerLeft"
            :key="'ll-' + n"
            class="p-1 relative"
            :class="{ 'bg-blue-50': isToothSelected(n), 'opacity-40': isExtracted(n) }"
            @click="toggleWholeTooth(n)"
          >
            <span
              v-if="isExtracted(n)"
              class="absolute top-0 right-0 text-red-600 text-xs"
              :title="'Zub izvađen'"
            >✖</span>
            <!-- info icon removed; statuses shown via tooltip -->
            <div v-if="showImplantSvg(n)" class="svg-container" v-html="getImplantSvg(n)"></div>
            <div
              v-else-if="svgs[n]"
              class="svg-container"
              v-html="svgs[n]"
              @mouseenter="(e) => { if (!isExtracted(n)) bindSvgEvents(e, n) }"
            ></div>
            <!-- popover removed; statuses shown via tooltip -->
          </td>
        </tr>
      </table>
      </div>
      <!-- Pagination controls -->
      <div v-if="totalPages > 1" class="mt-4 flex justify-center items-center gap-2">
        <button class="btn btn-sm" :disabled="currentPage === 1" @click="currentPage--">Prethodna</button>
        <span class="text-sm">Strana {{ currentPage }} / {{ totalPages }}</span>
        <button class="btn btn-sm" :disabled="currentPage === totalPages" @click="currentPage++">Sledeća</button>
      </div>
      <!-- If there is only one page or no entries, no pagination is shown -->

      <!-- Modal for selecting statuses/therapies by group -->
      <dialog v-if="modal.show" class="modal modal-open">
        <div class="modal-box max-w-4xl">
          <div class="flex justify-between items-center mb-3">
            <h2 class="font-bold text-lg">Odaberite statuse/terapije</h2>
            <button class="btn btn-sm btn-circle btn-ghost" @click="closeModal">✕</button>
          </div>
          <div v-for="state in modal.groupStates" :key="state.groupType" class="mb-6 border-b pb-4">
            <h3 class="font-semibold text-sm mb-2">
              {{ groupLabel(state.groupType) }}
              <span class="text-xs text-gray-500">({{ countGroupSurfaces(state.groupType) }})</span>
            </h3>
            <div class="flex gap-2 mb-2">
              <button
                class="btn btn-sm"
                :class="state.mode === 'status' ? 'btn-primary' : 'btn-outline'"
                @click="state.mode = 'status'"
              >
                Status
              </button>
              <button
                class="btn btn-sm"
                :class="state.mode === 'therapy' ? 'btn-primary' : 'btn-outline'"
                @click="state.mode = 'therapy'"
              >
                Terapija
              </button>
            </div>
            <div v-for="(opts, category) in getOptionsFor(state.groupType, state.mode)" :key="state.groupType + '-' + category" class="mb-3">
              <h4 class="text-xs uppercase text-gray-500 mb-1">{{ category }}</h4>
              <div class="flex flex-wrap gap-2">
                <span
                  v-for="opt in opts"
                  :key="opt"
                  class="badge badge-lg cursor-pointer"
                  :class="state.selected === opt ? 'badge-primary' : 'badge-ghost'"
                  @click="state.selected = opt"
                >
                  {{ opt }}
                </span>
              </div>
            </div>
            <div>
              <label class="block text-xs mb-1">Napomena (opciono):</label>
              <input
                v-model="state.note"
                class="input input-bordered w-full"
                placeholder="Unesite napomenu..."
              />
            </div>
          </div>
          <div class="flex justify-end gap-2 mt-4">
            <button class="btn btn-ghost" @click="closeModal">Otkaži</button>
            <button class="btn btn-primary" :disabled="!allGroupsValid" @click="saveSelection">Sačuvaj</button>
          </div>
        </div>
      </dialog>

      <!-- Patient protocol table -->
      <div class="bg-white rounded-xl shadow p-4 mt-8">
        <h2 class="text-lg font-semibold mb-2">Protokol pacijenta</h2>
        <div class="overflow-x-auto">
          <table class="table table-zebra w-full">
            <thead>
              <tr>
                <th>Datum</th>
                <th>Zub</th>
                <th>Površina</th>
                <th>Tip</th>
                <th>Opis</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(r, i) in paginatedEntries" :key="i">
                <td>{{ r.date }}</td>
                <td>{{ r.teeth.join(', ') }}</td>
                <td>{{ r.surfaces.map(surfaceLabel).join(', ') }}</td>
                <td>{{ r.type }} – {{ r.value }}</td>
                <td>{{ r.note }}</td>
              </tr>
              <tr v-if="!paginatedEntries.length">
                <td colspan="5" class="text-center text-gray-400">Nema unosa</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Interventions table -->
      <div class="bg-white rounded-xl shadow p-4 mt-8">
        <div class="flex justify-between items-center mb-2">
          <h2 class="text-lg font-semibold">Intervencije</h2>
          <button class="btn btn-primary btn-sm" @click="openInterventionModal">Dodaj</button>
        </div>
        <div class="overflow-x-auto">
          <table class="table table-zebra w-full">
            <thead>
              <tr>
                <th>Datum</th>
                <th>Zub</th>
                <th>Površina</th>
                <th>Tip</th>
                <th>Opis</th>
                <th>Doktor</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(inv, idx) in interventionsData" :key="'inv-' + idx">
                <td>{{ inv.date }}</td>
                <td>{{ inv.tooth }}</td>
                <td>{{ surfaceLabel(`tooth_${inv.tooth}_${inv.surface || 'ALL'}`) }}</td>
                <td>{{ inv.type }}</td>
                <td>{{ inv.description }}</td>
                <td>{{ inv.doctor }}</td>
                <td>{{ inv.status }}</td>
              </tr>
              <tr v-if="interventionsData.length === 0">
                <td colspan="7" class="text-center text-gray-400">Nema intervencija</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Intervention modal -->
      <dialog v-if="interventionModal" class="modal modal-open">
        <div class="modal-box max-w-lg">
          <div class="flex justify-between items-center mb-3">
            <h3 class="font-bold text-lg">Nova intervencija</h3>
            <button class="btn btn-sm btn-circle btn-ghost" @click="interventionModal = false">✕</button>
          </div>
          <div class="mb-3">
            <label class="label">Zub:</label>
            <select v-model="newIntervention.tooth_id" class="select select-bordered w-full">
              <option value="" disabled>Izaberite zub</option>
              <option v-for="t in allTeeth" :key="'t-' + t" :value="t">{{ t }}</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="label">Površina:</label>
            <select v-model="newIntervention.surface" class="select select-bordered w-full">
              <option v-for="s in surfaceOptions" :key="'s-' + s" :value="s">
                {{ s === 'ALL' ? 'Ceo zub' : surfaceLabel(`tooth_${newIntervention.tooth_id || ''}_${s}`) }}
              </option>
            </select>
          </div>
          <div class="mb-3">
            <label class="label">Tip intervencije:</label>
            <input v-model="newIntervention.type" class="input input-bordered w-full" placeholder="Vrsta intervencije" />
          </div>
          <div class="mb-3">
            <label class="label">Opis:</label>
            <textarea v-model="newIntervention.description" class="textarea textarea-bordered w-full" placeholder="Opis intervencije"></textarea>
          </div>
          <div class="mb-3">
            <label class="label">Datum:</label>
            <input type="date" v-model="newIntervention.performed_at" class="input input-bordered w-full" />
          </div>
          <div class="flex justify-end gap-2">
            <button class="btn btn-ghost" @click="interventionModal = false">Otkaži</button>
            <button class="btn btn-primary" @click="saveIntervention">Sačuvaj</button>
          </div>
        </div>
      </dialog>

      <!-- Therapies table -->
      <div class="bg-white rounded-xl shadow p-4 mt-8">
        <div class="flex justify-between items-center mb-2">
          <h2 class="text-lg font-semibold">Terapije</h2>
          <button class="btn btn-primary btn-sm" @click="openTherapyModal">Dodaj</button>
        </div>
        <div class="overflow-x-auto">
          <table class="table table-zebra w-full">
            <thead>
              <tr>
                <th>Datum</th>
                <th>Terapija</th>
                <th>Doktor</th>
                <th>Napomena</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(th, idx) in therapiesData" :key="'th-' + idx">
                <td>{{ th.date }}</td>
                <td>{{ th.therapy }}</td>
                <td>{{ th.doctor }}</td>
                <td>{{ th.note }}</td>
              </tr>
              <tr v-if="therapiesData.length === 0">
                <td colspan="4" class="text-center text-gray-400">Nema terapija</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Therapy modal -->
      <dialog v-if="therapyModal" class="modal modal-open">
        <div class="modal-box max-w-lg">
          <div class="flex justify-between items-center mb-3">
            <h3 class="font-bold text-lg">Nova terapija</h3>
            <button class="btn btn-sm btn-circle btn-ghost" @click="therapyModal = false">✕</button>
          </div>
          <div class="mb-3">
            <label class="label">Terapija:</label>
            <select v-model="newTherapy.therapy_type" class="select select-bordered w-full">
              <option value="" disabled>Izaberite terapiju</option>
              <option v-for="opt in props.therapyTypes" :key="opt" :value="opt">{{ opt }}</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="label">Napomena:</label>
            <textarea v-model="newTherapy.note" class="textarea textarea-bordered w-full" placeholder="Napomena"></textarea>
          </div>
          <div class="mb-3">
            <label class="label">Datum:</label>
            <input type="date" v-model="newTherapy.applied_at" class="input input-bordered w-full" />
          </div>
          <div class="flex justify-end gap-2">
            <button class="btn btn-ghost" @click="therapyModal = false">Otkaži</button>
            <button class="btn btn-primary" @click="saveTherapy">Sačuvaj</button>
          </div>
        </div>
      </dialog>

      <!-- Diagnoses table -->
      <div class="bg-white rounded-xl shadow p-4 mt-8">
        <div class="flex justify-between items-center mb-2">
          <h2 class="text-lg font-semibold">Dijagnoze</h2>
          <button class="btn btn-primary btn-sm" @click="openDiagnosisModal">Dodaj</button>
        </div>
        <div class="overflow-x-auto">
          <table class="table table-zebra w-full">
            <thead>
              <tr>
                <th>Datum</th>
                <th>Dijagnoza</th>
                <th>Opis</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(dg, idx) in diagnosesData" :key="'dg-' + idx">
                <td>{{ dg.date }}</td>
                <td>
                  <span
                    class="inline-flex items-center gap-1"
                  >
                    <span
                      v-if="dg.color"
                      :style="{ backgroundColor: dg.color }"
                      class="inline-block w-3 h-3 rounded-full"
                    ></span>
                    {{ dg.diagnosis }}
                  </span>
                </td>
                <td>{{ dg.description }}</td>
              </tr>
              <tr v-if="diagnosesData.length === 0">
                <td colspan="3" class="text-center text-gray-400">Nema dijagnoza</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Diagnosis modal -->
      <dialog v-if="diagnosisModal" class="modal modal-open">
        <div class="modal-box max-w-lg">
          <div class="flex justify-between items-center mb-3">
            <h3 class="font-bold text-lg">Nova dijagnoza</h3>
            <button class="btn btn-sm btn-circle btn-ghost" @click="diagnosisModal = false">✕</button>
          </div>
          <div class="mb-3">
            <label class="label">Tip dijagnoze:</label>
            <select v-model="newDiagnosis.diagnosis_type" class="select select-bordered w-full">
              <option value="" disabled>Izaberite dijagnozu</option>
              <option v-for="opt in props.diagnosisTypes" :key="opt" :value="opt">{{ opt }}</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="label">Opis:</label>
            <textarea v-model="newDiagnosis.description" class="textarea textarea-bordered w-full" placeholder="Opis"></textarea>
          </div>
          <div class="mb-3">
            <label class="label">Boja (heks kod, opcionalno):</label>
            <input type="text" v-model="newDiagnosis.color" class="input input-bordered w-full" placeholder="#ffffff" />
          </div>
          <div class="mb-3">
            <label class="label">Datum:</label>
            <input type="date" v-model="newDiagnosis.diagnosed_at" class="input input-bordered w-full" />
          </div>
          <div class="flex justify-end gap-2">
            <button class="btn btn-ghost" @click="diagnosisModal = false">Otkaži</button>
            <button class="btn btn-primary" @click="saveDiagnosis">Sačuvaj</button>
          </div>
        </div>
      </dialog>

      <!-- Treatment plan table -->
      <div class="bg-white rounded-xl shadow p-4 mt-8">
        <div class="flex justify-between items-center mb-2">
          <h2 class="text-lg font-semibold">Plan terapije</h2>
          <button class="btn btn-primary btn-sm" @click="openPlanModal">Dodaj</button>
        </div>
        <div class="overflow-x-auto">
          <table class="table table-zebra w-full">
            <thead>
              <tr>
                <th>Planirano</th>
                <th>Zub</th>
                <th>Opis</th>
                <th>Napomena</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(pt, idx) in treatmentPlansData" :key="'pt-' + idx">
                <td>{{ pt.date }}</td>
                <td>{{ pt.tooth }}</td>
                <td>{{ pt.plan }}</td>
                <td>{{ pt.note }}</td>
              </tr>
              <tr v-if="treatmentPlansData.length === 0">
                <td colspan="4" class="text-center text-gray-400">Nema plana terapije</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Treatment Plan modal -->
      <dialog v-if="planModal" class="modal modal-open">
        <div class="modal-box max-w-lg">
          <div class="flex justify-between items-center mb-3">
            <h3 class="font-bold text-lg">Novi plan terapije</h3>
            <button class="btn btn-sm btn-circle btn-ghost" @click="planModal = false">✕</button>
          </div>
          <div class="mb-3">
            <label class="label">Zub:</label>
            <select v-model="newPlan.tooth_id" class="select select-bordered w-full">
              <option value="" disabled>Izaberite zub</option>
              <option v-for="t in allTeeth" :key="'p-' + t" :value="t">{{ t }}</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="label">Opis plana:</label>
            <textarea v-model="newPlan.plan" class="textarea textarea-bordered w-full" placeholder="Plan terapije"></textarea>
          </div>
          <div class="mb-3">
            <label class="label">Napomena:</label>
            <textarea v-model="newPlan.note" class="textarea textarea-bordered w-full" placeholder="Napomena"></textarea>
          </div>
          <div class="mb-3">
            <label class="label">Datum:</label>
            <input type="date" v-model="newPlan.planned_at" class="input input-bordered w-full" />
          </div>
          <div class="flex justify-end gap-2">
            <button class="btn btn-ghost" @click="planModal = false">Otkaži</button>
            <button class="btn btn-primary" @click="savePlan">Sačuvaj</button>
          </div>
        </div>
      </dialog>

      <!-- Floating tooltip for hovered surfaces -->
      <!--
        This tooltip is displayed when hovering over any clickable surface on a tooth.  It shows
        the human‑readable name of the surface (e.g. "46 Bukalno"), and when the surface has
        an existing status, it also shows the status and any note associated with it.  When a
        status is present, a small coloured circle matching the status colour appears before
        the label.  The tooltip follows the mouse cursor via inline style bindings.
      -->
      <div
        v-if="tooltip.show"
        :style="tooltip.style"
        class="fixed z-50 p-2 bg-white border shadow rounded text-xs pointer-events-none flex items-center"
      >
        <span
          v-if="tooltip.color"
          :style="{ backgroundColor: tooltip.color }"
          class="inline-block w-3 h-3 rounded-full mr-2 flex-shrink-0"
        ></span>
        <span>{{ tooltip.text }}</span>
      </div>
    </div>
  </OwnerLayout>
</template>

<script setup>
import { ref, reactive, computed, watch, onMounted } from 'vue'
import { useForm } from '@inertiajs/vue3'
import { Link } from '@inertiajs/vue3'
import OwnerLayout from '../../../../Layouts/OwnerLayout.vue'

const props = defineProps({
  user: Object,
  chart_id: Number,
  statuses: Array,
  therapyTypes: Array,
  diagnosisTypes: Array,
  interventions: { type: Array, default: () => [] },
  therapies: { type: Array, default: () => [] },
  diagnoses: { type: Array, default: () => [] },
  treatmentPlans: { type: Array, default: () => [] },
})

// Form for persisting statuses to backend
const form = useForm({ dataItems: [], chart_id: props.chart_id })

// Local copy of statuses for reactive updates
const statusesData = ref([...props.statuses])

// Loading state (not used for spinner here). We keep it for potential future use.
const loading = ref(false)
onMounted(() => {
  // No artificial delay; statuses are available immediately
  loading.value = false
})

// Dentition toggle state
const dentition = ref('stalni')
const adultQuadrants = {
  upperRight: [18, 17, 16, 15, 14, 13, 12, 11],
  upperLeft: [21, 22, 23, 24, 25, 26, 27, 28],
  lowerLeft: [31, 32, 33, 34, 35, 36, 37, 38],
  lowerRight: [48, 47, 46, 45, 44, 43, 42, 41],
}
const milkQuadrants = {
  upperRight: [55, 54, 53, 52, 51],
  upperLeft: [61, 62, 63, 64, 65],
  lowerLeft: [71, 72, 73, 74, 75],
  lowerRight: [85, 84, 83, 82, 81],
}
const quadrants = computed(() => (dentition.value === 'stalni' ? adultQuadrants : milkQuadrants))

// Filtered quadrants that exclude extracted teeth (no v-if inside v-for)
const filteredQuadrants = computed(() => {
  const base = quadrants.value
  const res = {}
  Object.keys(base).forEach((key) => {
    res[key] = base[key].filter((num) => !isExtracted(num))
  })
  return res
})

// Load tooth SVGs
const modules = import.meta.glob('../../../../svg/tooth_*.svg', { as: 'raw', eager: true })
const svgs = {}
Object.entries(modules).forEach(([path, raw]) => {
  const m = path.match(/tooth_(\d+)\.svg$/)
  if (m) svgs[+m[1]] = raw
})
// Load implant SVGs
const implantModules = import.meta.glob('../../../../svg/implant_*.svg', { as: 'raw', eager: true })
const implantSvgs = {}
Object.entries(implantModules).forEach(([path, raw]) => {
  const m = path.match(/implant_([a-z_]+)\.svg$/)
  if (m) implantSvgs[m[1]] = raw
})
function getImplantSvgKey(toothNum) {
  toothNum = parseInt(toothNum)
  if ([14, 15, 24, 25].includes(toothNum)) return 'up_premolar'
  if ([16, 17, 18, 26, 27, 28].includes(toothNum)) return 'up_molar'
  if ([13, 23].includes(toothNum)) return 'up_canine'
  if ([11, 12, 21, 22].includes(toothNum)) return 'up_incisors'
  if ([34, 35, 44, 45].includes(toothNum)) return 'down_premolar'
  if ([36, 37, 38, 46, 47, 48].includes(toothNum)) return 'down_molar'
  if ([33, 43].includes(toothNum)) return 'down_canine'
  if ([31, 32, 41, 42].includes(toothNum)) return 'down_incisors'
  return null
}
function showImplantSvg(toothNum) {
  return statusesData.value.some(
    (s) => parseInt(s.tooth_id) === toothNum && ['Implant', 'Implantacija'].includes(s.status)
  )
}
function getImplantSvg(toothNum) {
  const key = getImplantSvgKey(toothNum)
  return key && implantSvgs[key] ? implantSvgs[key] : ''
}

// Selected surfaces or whole teeth
const selectedSurfaces = ref([])
function toggleWholeTooth(num) {
  const id = `tooth_${num}_ALL`
  if (selectedSurfaces.value.includes(id)) {
    selectedSurfaces.value = selectedSurfaces.value.filter((x) => x !== id)
  } else {
    // Remove any partial selections for this tooth
    selectedSurfaces.value = selectedSurfaces.value.filter((x) => !x.startsWith(`tooth_${num}_`))
    selectedSurfaces.value.push(id)
  }
  updateSvgSelection()
  // When toggling whole tooth, ensure no tooltips remain visible
  tooltip.show = false
}
function isToothSelected(num) {
  return selectedSurfaces.value.includes(`tooth_${num}_ALL`)
}

// We no longer use info icons and popovers; statuses are shown via tooltip

// Determine if a tooth has been extracted (status 'Vađenje'); extracted teeth are hidden
function isExtracted(num) {
  return statusesData.value.some((s) => parseInt(s.tooth_id) === num && s.status === 'Vađenje')
}

// Bind surface events
function bindSvgEvents(e, toothNum) {
  const svg = e.currentTarget.querySelector('svg')
  if (!svg) return
  svg.querySelectorAll('.clickable').forEach((el) => {
    el.onmouseenter = (evt) => {
      // Compose label and color for hovered surface
      const id = el.id
      const parts = id.split('_')
      const tooth_id = parts[1]
      const surface = parts[2]
      // Prefer the data-title attribute from the SVG element for the surface name; fallback to surfaceLabel
      let label = el.getAttribute('data-title') || surfaceLabel(id)
      const st = statusesData.value.find((s) => s.tooth_id == tooth_id && s.surface == surface)
      if (st) {
        label += ' – ' + st.status
        if (st.note) label += ' – ' + st.note
        tooltip.color = statusColors[st.status] || null
      } else {
        tooltip.color = null
      }
      tooltip.show = true
      tooltip.text = label
      tooltip.style = {
        top: evt.clientY + 10 + 'px',
        left: evt.clientX + 10 + 'px',
        position: 'fixed',
      }
    }
    el.onmousemove = (evt) => {
      if (tooltip.show) {
        tooltip.style = {
          top: evt.clientY + 10 + 'px',
          left: evt.clientX + 10 + 'px',
          position: 'fixed',
        }
      }
    }
    el.onmouseleave = () => {
      tooltip.show = false
      tooltip.text = ''
      tooltip.color = null
    }
    el.onclick = (ev) => {
      ev.stopPropagation()
      const id = el.id
      // If whole tooth selected remove whole and add this surface
      const [_, tnum] = id.split('_')
      const wholeId = `tooth_${tnum}_ALL`
      if (selectedSurfaces.value.includes(wholeId)) {
        selectedSurfaces.value = selectedSurfaces.value.filter((x) => x !== wholeId)
      }
      if (selectedSurfaces.value.includes(id)) {
        selectedSurfaces.value = selectedSurfaces.value.filter((x) => x !== id)
      } else {
        selectedSurfaces.value.push(id)
      }
      updateSvgSelection()
      // Hide any existing tooltip when clicking surface
      tooltip.show = false
    }
  })
  updateSvgSelection()
}

function updateSvgSelection() {
  setTimeout(() => {
    document.querySelectorAll('.svg-container svg').forEach((svg) => {
      svg.querySelectorAll('.clickable').forEach((el) => {
        let base = 'clickable'
        const parts = el.id.split('_')
        const tooth_id = parts[1]
        const surface = parts[2]
        const st = statusesData.value.find((s) => s.tooth_id == tooth_id && s.surface == surface)
        // If the tooth is extracted, skip applying status class on surfaces
        const toothExtracted = statusesData.value.some(
          (s) => s.tooth_id == tooth_id && s.status === 'Vađenje'
        )
        if (st && !toothExtracted) base += ' ' + statusClass(st.status)
        if (selectedSurfaces.value.includes(el.id) || selectedSurfaces.value.includes(`tooth_${tooth_id}_ALL`)) {
          base += ' surface-selected'
        }
        el.setAttribute('class', base)
      })
    })
  }, 30)
}
watch(selectedSurfaces, updateSvgSelection)
watch(
  () => statusesData.value,
  updateSvgSelection,
  { deep: true }
)

// Tooltip state
// Tooltip state now includes a color for status indicators
const tooltip = reactive({ show: false, text: '', style: {}, color: null })

// Modal state
const modal = reactive({
  show: false,
  groupStates: [],
})

// Computed property to check if all selected groups have chosen value
const allGroupsValid = computed(() => {
  return modal.groupStates.length > 0 && modal.groupStates.every((st) => !!st.selected)
})

// Categories for statuses and therapies grouped by type
const statusCategories = {
  Restaurativne: ['Karijes', 'Plomba', 'Fraktura', 'Pigmentacija', 'Ortodontska bravica', 'Fisure zatvorene', 'Lečenje pulpitisa', 'Zamena ispuna'],
  Endodontske: ['Zdrav koren', 'Cista', 'Granulom', 'Periapikalna lezija', 'Parodontitis', 'Endodontski tretman', 'Apikotomija'],
  Protetika: ['Krunica', 'Most', 'Proteza', 'Implant'],
  Parodontologija: ['Parodontni džep', 'Periimplantitis', 'Gingivitis'],
  Ostalo: ['Zdrav', 'Vađenje', 'Trauma zuba', 'Abradiran zub', 'Erozija zuba', 'Halitoza', 'Leukoplakija', 'Oralna kandidijaza', 'Herpes simplex', 'Afte', 'Neuralgija trigeminusa', 'Malokluzija', 'Upala sinusa', 'Paradontopatija'],
}
const therapyCategories = {
  Endodontske: ['Endodontski tretman', 'Apikotomija', 'Vađenje', 'Implantacija'],
  Protetika: ['Izrada krunice', 'Izrada mosta', 'Protetika', 'Zamena ispuna'],
  Restaurativne: ['Plomba', 'Lečenje pulpitisa'],
  Preventivne: ['Fisure zatvorene'],
  Ostalo: ['Vađenje'],
}

// Mapping of status names to their tooltip color (matching fill colors in CSS)
const statusColors = {
  Karijes: '#dc2626',
  Plomba: '#2563eb',
  Krunica: '#facc15',
  Most: '#fb923c',
  Proteza: '#c084fc',
  Implant: '#6b7280',
  Pigmentacija: '#14b8a6',
  Fraktura: '#f87171',
  'Ortodontska bravica': '#ec4899',
  'Fisure zatvorene': '#84cc16',
  'Zdrav koren': '#15803d',
  Cista: '#e11d48',
  Granulom: '#f59e0b',
  'Periapikalna lezija': '#a855f7',
  Parodontitis: '#06b6d4',
  'Endodontski tretman': '#8b5cf6',
  Vađenje: '#0ea5e9',
  Apikotomija: '#a3a3a3',
  Zdrav: '#22c55e',
  'Zamena ispuna': '#0ea5e9',
  'Lečenje pulpitisa': '#c026d3',
  'Izrada krunice': '#fde047',
  'Izrada mosta': '#fb923c',
  Protetika: '#4f46e5',
  'Parodontni džep': '#4ade80',
  'Periimplantitis': '#f472b6',
  Gingivitis: '#16a34a',
  'Trauma zuba': '#f87171',
  'Abradiran zub': '#71717a',
  'Erozija zuba': '#eab308',
  Halitoza: '#6ee7b7',
  Leukoplakija: '#c084fc',
  'Oralna kandidijaza': '#f472b6',
  'Herpes simplex': '#ec4899',
  Afte: '#fbbf24',
  'Neuralgija trigeminusa': '#a78bfa',
  Malokluzija: '#60a5fa',
  'Upala sinusa': '#4ade80',
  Paradontopatija: '#22d3ee',
}

// =================================================================================================
// Forms and state for adding interventions, therapies, diagnoses, and treatment plans
// =================================================================================================

// All tooth codes for selection (both permanent and deciduous)
const allTeeth = computed(() => {
  // Flatten adult and milk quadrants into a single set
  const adult = [
    ...adultQuadrants.upperRight,
    ...adultQuadrants.upperLeft,
    ...adultQuadrants.lowerLeft,
    ...adultQuadrants.lowerRight,
  ]
  const milk = [
    ...milkQuadrants.upperRight,
    ...milkQuadrants.upperLeft,
    ...milkQuadrants.lowerLeft,
    ...milkQuadrants.lowerRight,
  ]
  const set = new Set([...adult, ...milk])
  return Array.from(set).sort((a, b) => a - b)
})

// Possible surface codes for interventions; 'ALL' means cijeli zub
const surfaceOptions = ['ALL', 'B', 'L', 'O', 'D', 'M', 'R']

// Intervention modal state and form data
const interventionModal = ref(false)
const newIntervention = reactive({
  tooth_id: '',
  surface: 'ALL',
  type: '',
  description: '',
  performed_at: new Date().toISOString().substring(0, 10),
})
const interventionForm = useForm({
  chart_id: props.chart_id,
  tooth_id: '',
  surface: '',
  type: '',
  description: '',
  performed_at: '',
})

function openInterventionModal() {
  // Reset form values
  newIntervention.tooth_id = ''
  newIntervention.surface = 'ALL'
  newIntervention.type = ''
  newIntervention.description = ''
  newIntervention.performed_at = new Date().toISOString().substring(0, 10)
  interventionModal.value = true
}

function saveIntervention() {
  // Validate simple fields (ensure tooth is selected)
  if (!newIntervention.tooth_id || !newIntervention.type) {
    // you can add more validation here
    return
  }
  interventionForm.tooth_id = newIntervention.tooth_id
  interventionForm.surface = newIntervention.surface
  interventionForm.type = newIntervention.type
  interventionForm.description = newIntervention.description
  interventionForm.performed_at = newIntervention.performed_at
  interventionForm.chart_id = props.chart_id
  interventionForm.post(route('owner.users.chart.odontogram.save_intervention', props.user.id), {
    preserveScroll: true,
    onSuccess: () => {
      // Push to local interventionsData for immediate display
      const dateObj = new Date(newIntervention.performed_at)
      interventionsData.value.unshift({
        date: dateObj.toLocaleDateString('sr-RS'),
        timestamp: dateObj.toISOString(),
        tooth: String(newIntervention.tooth_id),
        surface: newIntervention.surface,
        type: newIntervention.type,
        description: newIntervention.description,
        doctor: '',
        status: '',
      })
      interventionModal.value = false
    },
  })
}

// Therapy modal state and form data
const therapyModal = ref(false)
const newTherapy = reactive({
  therapy_type: '',
  note: '',
  applied_at: new Date().toISOString().substring(0, 10),
})
const therapyForm = useForm({
  chart_id: props.chart_id,
  therapy_type: '',
  note: '',
  applied_at: '',
})

function openTherapyModal() {
  newTherapy.therapy_type = ''
  newTherapy.note = ''
  newTherapy.applied_at = new Date().toISOString().substring(0, 10)
  therapyModal.value = true
}

function saveTherapy() {
  if (!newTherapy.therapy_type) return
  therapyForm.chart_id = props.chart_id
  therapyForm.therapy_type = newTherapy.therapy_type
  therapyForm.note = newTherapy.note
  therapyForm.applied_at = newTherapy.applied_at
  therapyForm.post(route('owner.users.chart.odontogram.save_therapy', props.user.id), {
    preserveScroll: true,
    onSuccess: () => {
      const dateObj = new Date(newTherapy.applied_at)
      therapiesData.value.unshift({
        date: dateObj.toLocaleDateString('sr-RS'),
        timestamp: dateObj.toISOString(),
        therapy: newTherapy.therapy_type,
        doctor: '',
        note: newTherapy.note,
      })
      therapyModal.value = false
    },
  })
}

// Diagnosis modal state and form data
const diagnosisModal = ref(false)
const newDiagnosis = reactive({
  diagnosis_type: '',
  description: '',
  color: '',
  diagnosed_at: new Date().toISOString().substring(0, 10),
})
const diagnosisForm = useForm({
  chart_id: props.chart_id,
  diagnosis_type: '',
  description: '',
  color: '',
  diagnosed_at: '',
})

function openDiagnosisModal() {
  newDiagnosis.diagnosis_type = ''
  newDiagnosis.description = ''
  newDiagnosis.color = ''
  newDiagnosis.diagnosed_at = new Date().toISOString().substring(0, 10)
  diagnosisModal.value = true
}

function saveDiagnosis() {
  if (!newDiagnosis.diagnosis_type) return
  diagnosisForm.chart_id = props.chart_id
  diagnosisForm.diagnosis_type = newDiagnosis.diagnosis_type
  diagnosisForm.description = newDiagnosis.description
  diagnosisForm.color = newDiagnosis.color
  diagnosisForm.diagnosed_at = newDiagnosis.diagnosed_at
  diagnosisForm.post(route('owner.users.chart.odontogram.save_diagnosis', props.user.id), {
    preserveScroll: true,
    onSuccess: () => {
      const dateObj = new Date(newDiagnosis.diagnosed_at)
      diagnosesData.value.unshift({
        date: dateObj.toLocaleDateString('sr-RS'),
        timestamp: dateObj.toISOString(),
        diagnosis: newDiagnosis.diagnosis_type,
        description: newDiagnosis.description,
        color: newDiagnosis.color,
      })
      diagnosisModal.value = false
    },
  })
}

// Treatment plan modal state and form data
const planModal = ref(false)
const newPlan = reactive({
  tooth_id: '',
  plan: '',
  note: '',
  planned_at: new Date().toISOString().substring(0, 10),
})
const planForm = useForm({
  chart_id: props.chart_id,
  tooth_id: '',
  plan: '',
  note: '',
  planned_at: '',
})

function openPlanModal() {
  newPlan.tooth_id = ''
  newPlan.plan = ''
  newPlan.note = ''
  newPlan.planned_at = new Date().toISOString().substring(0, 10)
  planModal.value = true
}

function savePlan() {
  if (!newPlan.tooth_id || !newPlan.plan) return
  planForm.chart_id = props.chart_id
  planForm.tooth_id = newPlan.tooth_id
  planForm.plan = newPlan.plan
  planForm.note = newPlan.note
  planForm.planned_at = newPlan.planned_at
  planForm.post(route('owner.users.chart.odontogram.save_plan', props.user.id), {
    preserveScroll: true,
    onSuccess: () => {
      const dateObj = new Date(newPlan.planned_at)
      treatmentPlansData.value.unshift({
        date: dateObj.toLocaleDateString('sr-RS'),
        timestamp: dateObj.toISOString(),
        tooth: String(newPlan.tooth_id),
        plan: newPlan.plan,
        note: newPlan.note,
      })
      planModal.value = false
    },
  })
}
// Allowed options depending on selected group (ALL, R, K)
const allowedStatusOptions = {
  ALL: ['Krunica', 'Most', 'Proteza', 'Implant', 'Zdrav', 'Vađenje', 'Trauma zuba', 'Abradiran zub', 'Erozija zuba', 'Halitoza', 'Leukoplakija', 'Oralna kandidijaza', 'Herpes simplex', 'Afte', 'Neuralgija trigeminusa', 'Malokluzija', 'Upala sinusa', 'Paradontopatija'],
  R: ['Zdrav koren', 'Cista', 'Granulom', 'Periapikalna lezija', 'Parodontitis', 'Endodontski tretman', 'Apikotomija'],
  K: ['Karijes', 'Plomba', 'Fraktura', 'Pigmentacija', 'Ortodontska bravica', 'Fisure zatvorene', 'Lečenje pulpitisa', 'Zamena ispuna', 'Parodontni džep', 'Periimplantitis', 'Gingivitis', 'Zdrav'],
}
const allowedTherapyOptions = {
  ALL: ['Izrada krunice', 'Izrada mosta', 'Protetika', 'Zamena ispuna', 'Implantacija', 'Vađenje'],
  R: ['Endodontski tretman', 'Apikotomija', 'Vađenje', 'Implantacija'],
  K: ['Plomba', 'Lečenje pulpitisa', 'Fisure zatvorene', 'Zamena ispuna'],
}

function openModal(mode) {
  // Determine unique group types in the current selection
  const groups = [...new Set(selectedSurfaces.value.map((id) => getGroupFromId(id)))]
  if (!groups.length) return
  // Build group states for each group
  modal.groupStates = groups.map((g) => ({
    groupType: g,
    mode: mode,
    selected: '',
    note: '',
  }))
  modal.show = true
}
function closeModal() {
  modal.show = false
}

// Determine selected group type (ALL, R, K)
function getSelectedGroup() {
  // If at least one surface ends with _ALL treat as whole tooth
  for (const id of selectedSurfaces.value) {
    if (id.endsWith('_ALL')) return 'ALL'
  }
  // If any surface has _R suffix => root
  for (const id of selectedSurfaces.value) {
    if (id.split('_')[2] === 'R') return 'R'
  }
  return 'K'
}

// Helper to compute group type from a single surface ID
function getGroupFromId(id) {
  const parts = id.split('_')
  const suffix = parts[2] || 'ALL'
  if (suffix === 'ALL') return 'ALL'
  if (suffix === 'R') return 'R'
  return 'K'
}

// Provide a human-friendly label for a group
function groupLabel(type) {
  if (type === 'ALL') return 'Ceo zub'
  if (type === 'R') return 'Koren'
  return 'Krunica/Deo krunice'
}

// Count selected surfaces belonging to a group
function countGroupSurfaces(type) {
  return selectedSurfaces.value.filter((id) => getGroupFromId(id) === type).length
}

// Get options grouped by category for a given group and mode
function getOptionsFor(groupType, mode) {
  const baseOptions = mode === 'status' ? statusCategories : therapyCategories
  const allowedList = mode === 'status' ? allowedStatusOptions[groupType] : allowedTherapyOptions[groupType]
  const filtered = {}
  Object.entries(baseOptions).forEach(([cat, opts]) => {
    const list = opts.filter((opt) => allowedList.includes(opt))
    if (list.length) filtered[cat] = list
  })
  return filtered
}

function saveSelection() {
  // Build payload for backend and update local state
  const allNewEntries = []
  const payload = []
  modal.groupStates.forEach((state) => {
    if (!state.selected) return
    const groupType = state.groupType
    const surfacesForGroup = selectedSurfaces.value.filter((id) => getGroupFromId(id) === groupType)
    surfacesForGroup.forEach((id) => {
      const parts = id.split('_')
      const tooth = parts[1]
      let surface = parts[2]
      if (surface === 'ALL') {
        surface = 'ALL'
      }
      // Entry for protocol table
      const now = new Date()
      const entry = {
        date: now.toLocaleDateString('sr-RS'),
        timestamp: now.toISOString(),
        teeth: [tooth],
        surfaces: [id],
        type: state.mode === 'status' ? 'Status' : 'Terapija',
        value: state.selected,
        note: state.note,
      }
      allNewEntries.push(entry)
      // Prepare payload item for backend
      payload.push({
        tooth_id: tooth,
        surface: surface,
        status: state.selected,
        note: state.note,
      })
      // Update local statuses: replace existing record for this tooth and surface
      const existingIndices = []
      statusesData.value.forEach((item, idx) => {
        if (item.tooth_id == tooth && item.surface == surface) {
          existingIndices.push(idx)
        }
      })
      // Remove existing entries for this tooth+surface
      for (let i = existingIndices.length - 1; i >= 0; i--) {
        statusesData.value.splice(existingIndices[i], 1)
      }
      // Add new status/therapy entry
      statusesData.value.push({
        tooth_id: tooth,
        surface: surface,
        status: state.selected,
        note: state.note,
        type: state.mode === 'status' ? 'Status' : 'Terapija',
      })
    })
    // Remove surfaces of this group from selection
    selectedSurfaces.value = selectedSurfaces.value.filter((id) => getGroupFromId(id) !== groupType)
  })
  // Persist to backend if payload not empty
  if (payload.length) {
    form.dataItems = payload
    form.chart_id = props.chart_id
    form.post(route('owner.users.chart.odontogram.save_status', props.user.id), {
      preserveScroll: true,
      onSuccess: () => {
        // Optionally handle success (statuses refreshed via server)
      },
    })
  }
  if (allNewEntries.length) {
    entries.value.push(...allNewEntries)
  }
  closeModal()
  updateSvgSelection()
}

// Entries for protocol — initialize from loaded statuses
// Each entry also contains a timestamp for reliable sorting
const entries = ref(
  props.statuses.map((s) => {
    // If status_date is provided, parse it; otherwise use current date
    let dateObj
    try {
      dateObj = s.status_date ? new Date(s.status_date) : new Date()
    } catch (e) {
      dateObj = new Date()
    }
    return {
      date: dateObj.toLocaleDateString('sr-RS'),
      timestamp: dateObj.toISOString(),
      teeth: [String(s.tooth_id)],
      surfaces: [`tooth_${s.tooth_id}_${s.surface || 'ALL'}`],
      type: 'Status',
      value: s.status,
      note: s.note || '',
    }
  }),
)

// When statusesData changes, update entries for protocol
watch(
  () => statusesData.value,
  (val) => {
    entries.value = val.map((s) => {
      let dateObj
      try {
        dateObj = s.status_date ? new Date(s.status_date) : new Date()
      } catch (e) {
        dateObj = new Date()
      }
      return {
        date: dateObj.toLocaleDateString('sr-RS'),
        timestamp: dateObj.toISOString(),
        teeth: [String(s.tooth_id)],
        surfaces: [`tooth_${s.tooth_id}_${s.surface || 'ALL'}`],
        type: s.type || 'Status',
        value: s.status,
        note: s.note || '',
      }
    })
  },
  { deep: true }
)

// Pagination for protocol table
const pageSize = 5
const currentPage = ref(1)

// Sort entries by timestamp descending (latest first)
const sortedEntries = computed(() => {
  return [...entries.value].sort((a, b) => {
    const dateA = a.timestamp ? new Date(a.timestamp) : new Date(a.date.split('.').reverse().join('-'))
    const dateB = b.timestamp ? new Date(b.timestamp) : new Date(b.date.split('.').reverse().join('-'))
    return dateB - dateA
  })
})

// Total pages for pagination (at least 1)
const totalPages = computed(() => {
  const count = sortedEntries.value.length
  return count === 0 ? 1 : Math.ceil(count / pageSize)
})

// Entries for current page
const paginatedEntries = computed(() => {
  const start = (currentPage.value - 1) * pageSize
  return sortedEntries.value.slice(start, start + pageSize)
})

// Reset to first page when entries change
watch(
  () => entries.value,
  () => {
    currentPage.value = 1
  },
  { deep: true }
)

// Check if tooth has statuses
function hasStatuses(num) {
  return statusesData.value.some((s) => parseInt(s.tooth_id) === num)
}

// Compute nice label for selected surfaces
const selectedLabel = computed(() => {
  return selectedSurfaces.value
    .map((id) => {
      const parts = id.split('_')
      if (parts[0] === 'tooth') {
        const tooth = parts[1]
        const sec = parts[2] || 'ALL'
        const map = {
          O: 'Okluzalno',
          B: 'Bukalno',
          L: 'Lingvalno',
          D: 'Distalno',
          M: 'Mezijalno',
          R: 'Koren',
          ALL: 'Ceo zub',
        }
        return `${tooth} ${map[sec] || sec}`
      }
      return id
    })
    .join(', ')
})

// Clear current selection
function clearSelection() {
  selectedSurfaces.value = []
  updateSvgSelection()
}

// Determine class names for surfaces based on status
function statusClass(status) {
  const map = {
    Karijes: 'odontogram-caries',
    Plomba: 'odontogram-filling',
    Krunica: 'odontogram-crown',
    Most: 'odontogram-bridge',
    Proteza: 'odontogram-prosthetic',
    Implant: 'odontogram-implant',
    Pigmentacija: 'odontogram-pigment',
    Fraktura: 'odontogram-fracture',
    'Ortodontska bravica': 'odontogram-ortho',
    'Fisure zatvorene': 'odontogram-fissure',
    'Zdrav koren': 'odontogram-healthy-root',
    Cista: 'odontogram-cyst',
    Granulom: 'odontogram-granulom',
    'Periapikalna lezija': 'odontogram-periapex',
    Parodontitis: 'odontogram-parodontitis',
    'Endodontski tretman': 'odontogram-endo',
    Vađenje: 'odontogram-extract',
    Apikotomija: 'odontogram-apico',
    Zdrav: 'odontogram-healthy',
    'Zamena ispuna': 'odontogram-replacefill',
    'Lečenje pulpitisa': 'odontogram-pulpitis',
    'Izrada krunice': 'odontogram-crownwork',
    'Izrada mosta': 'odontogram-bridgework',
    Protetika: 'odontogram-prosthetic',
    Proteza: 'odontogram-prosthesis',
    'Endodontski tretman': 'odontogram-endo',
    'Izrada krunice': 'odontogram-crownwork',
    'Parodontni džep': 'odontogram-parodontni',
    'Periimplantitis': 'odontogram-periimplantitis',
    Gingivitis: 'odontogram-gingivitis',
    'Trauma zuba': 'odontogram-trauma',
    'Abradiran zub': 'odontogram-abrasion',
    'Erozija zuba': 'odontogram-erosion',
    Halitoza: 'odontogram-halitosis',
    Leukoplakija: 'odontogram-leukoplakia',
    'Oralna kandidijaza': 'odontogram-candidiasis',
    'Herpes simplex': 'odontogram-herpes',
    Afte: 'odontogram-afta',
    'Neuralgija trigeminusa': 'odontogram-neuralgia',
    Malokluzija: 'odontogram-malocclusion',
    'Upala sinusa': 'odontogram-sinusitis',
    Paradontopatija: 'odontogram-paradontopathy',
  }
  return map[status] || ''
}

// Convert surface ID to label
function surfaceLabel(id) {
  const parts = id.split('_')
  const tooth = parts[1]
  const sec = parts[2] || 'ALL'
  const map = {
    O: 'Okluzalno',
    B: 'Bukalno',
    L: 'Lingvalno',
    D: 'Distalno',
    M: 'Mezijalno',
    R: 'Koren',
    ALL: 'Ceo zub',
  }
  return `${tooth} ${map[sec] || sec}`
}

// ============ Additional sections: interventions, therapies, diagnoses, treatment plans =============
// Convert interventions prop into display-friendly objects sorted by date descending
const interventionsData = computed(() => {
  // Ensure the prop is an array; otherwise use empty array
  const arr = Array.isArray(props.interventions) ? props.interventions : []
  return [...arr].map((i) => {
    const dateObj = i.performed_at ? new Date(i.performed_at) : new Date()
    return {
      date: dateObj.toLocaleDateString('sr-RS'),
      timestamp: dateObj.toISOString(),
      tooth: String(i.tooth_id || (i.tooth && i.tooth.code) || ''),
      surface: i.surface || 'ALL',
      type: i.type || '',
      description: i.description || '',
      doctor: (i.doctor && (i.doctor.name || i.doctor.full_name)) || i.doctor_id || '',
      status: i.status || '',
    }
  }).sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
})
// Convert therapies prop into display-friendly objects sorted by date descending
const therapiesData = computed(() => {
  const arr = Array.isArray(props.therapies) ? props.therapies : []
  return [...arr].map((t) => {
    const dateObj = t.applied_at ? new Date(t.applied_at) : new Date()
    return {
      date: dateObj.toLocaleDateString('sr-RS'),
      timestamp: dateObj.toISOString(),
      therapy: (t.therapy_type && t.therapy_type.name) || t.therapy_type_id || '',
      doctor: (t.doctor && (t.doctor.name || t.doctor.full_name)) || t.doctor_id || '',
      note: t.note || '',
    }
  }).sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
})
// Convert diagnoses prop into display-friendly objects sorted by date descending
const diagnosesData = computed(() => {
  const arr = Array.isArray(props.diagnoses) ? props.diagnoses : []
  return [...arr].map((d) => {
    const dateObj = d.diagnosed_at ? new Date(d.diagnosed_at) : new Date()
    return {
      date: dateObj.toLocaleDateString('sr-RS'),
      timestamp: dateObj.toISOString(),
      diagnosis: (d.diagnosis_type && (d.diagnosis_type.name || d.diagnosis_type.code)) || d.diagnosis_type_id || '',
      description: d.description || '',
      color: d.color || '',
    }
  }).sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
})
// Convert treatment plans prop into display-friendly objects sorted by date (assuming 'planned_at')
const treatmentPlansData = computed(() => {
  const arr = Array.isArray(props.treatmentPlans) ? props.treatmentPlans : []
  return [...arr].map((p) => {
    const dateObj = p.planned_at ? new Date(p.planned_at) : new Date()
    return {
      date: dateObj.toLocaleDateString('sr-RS'),
      timestamp: dateObj.toISOString(),
      plan: p.plan || p.description || '',
      tooth: String(p.tooth_id || (p.tooth && p.tooth.code) || ''),
      note: p.note || '',
    }
  }).sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
})
</script>

<style scoped>

/* Color mapping for odontogram statuses */
::v-deep .odontogram-caries {
  fill: #dc2626 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-filling {
  fill: #2563eb !important;
  opacity: 1 !important;
}
::v-deep .odontogram-crown {
  fill: #facc15 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-bridge {
  fill: #fb923c !important;
  opacity: 1 !important;
}
::v-deep .odontogram-prosthetic {
  fill: #4f46e5 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-implant {
  fill: #6b7280 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-pigment {
  fill: #14b8a6 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-fracture {
  fill: #f87171 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-ortho {
  fill: #ec4899 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-fissure {
  fill: #84cc16 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-healthy-root {
  fill: #15803d !important;
  opacity: 1 !important;
}
::v-deep .odontogram-cyst {
  fill: #e11d48 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-granulom {
  fill: #f59e0b !important;
  opacity: 1 !important;
}
::v-deep .odontogram-periapex {
  fill: #a855f7 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-parodontitis {
  fill: #06b6d4 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-endo {
  fill: #8b5cf6 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-extract {
  fill: #0ea5e9 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-apico {
  fill: #a3a3a3 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-healthy {
  fill: #22c55e !important;
  opacity: 1 !important;
}
::v-deep .odontogram-replacefill {
  fill: #0ea5e9 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-pulpitis {
  fill: #c026d3 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-crownwork {
  fill: #fde047 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-bridgework {
  fill: #fb923c !important;
  opacity: 1 !important;
}
::v-deep .odontogram-parodontni {
  fill: #4ade80 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-periimplantitis {
  fill: #f472b6 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-gingivitis {
  fill: #16a34a !important;
  opacity: 1 !important;
}
::v-deep .odontogram-trauma {
  fill: #f87171 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-abrasion {
  fill: #71717a !important;
  opacity: 1 !important;
}
::v-deep .odontogram-erosion {
  fill: #eab308 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-halitosis {
  fill: #6ee7b7 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-leukoplakia {
  fill: #c084fc !important;
  opacity: 1 !important;
}
::v-deep .odontogram-candidiasis {
  fill: #f472b6 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-herpes {
  fill: #ec4899 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-afta {
  fill: #fbbf24 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-neuralgia {
  fill: #a78bfa !important;
  opacity: 1 !important;
}
::v-deep .odontogram-malocclusion {
  fill: #60a5fa !important;
  opacity: 1 !important;
}
::v-deep .odontogram-sinusitis {
  fill: #4ade80 !important;
  opacity: 1 !important;
}
::v-deep .odontogram-paradontopathy {
  fill: #22d3ee !important;
  opacity: 1 !important;
}

/* Selektovan deo */
::v-deep .surface-selected {
  opacity: 0.6 !important;
}

::v-deep .odontogram-svg svg {
  width: 100%;
  max-width: 1600px;
  margin: 0 auto;
}

::v-deep .svg-tooltip {
  position: absolute;
  pointer-events: none;
  background: rgba(0, 0, 0, 0.75);
  color: #fff;
  padding: 2px 6px;
  border-radius: 3px;
  font-size: 12px;
  white-space: nowrap;
  z-index: 1000;
  transform: translate(8px, 8px);
  display: none;
}

::v-deep .surface-selected {
  opacity: 0.6 !important;
}

/* your ::v-deep .st0 … ::v-deep .st318 definitions can stay in each SVG */
::v-deep .clickable:hover {
  opacity: 0.2;
  fill: #000000;
}

::v-deep .clickable {
  opacity: 0;
  fill: #000000;
  cursor: pointer;
  position: relative;
}

::v-deep .st0 {
  fill: #F3F4F4;
}

::v-deep .st1 {
  fill: #E9E9E9;
}

::v-deep .st2 {
  fill: #DFDFDF;
}

::v-deep .st3 {
  fill: #D6D6D6;
}

::v-deep .st4 {
  fill: #CCCCCC;
}

::v-deep .st5 {
  fill: #CCC6B9;
}

::v-deep .st6 {
  fill: #DFD9CA;
}

::v-deep .st7 {
  fill: #BCB5AA;
}

::v-deep .st8 {
  fill: #DCD2C3;
}

::v-deep .st9 {
  fill: #D0CABC;
}

::v-deep .st10 {
  fill: #F5EEE2;
}

::v-deep .st11 {
  fill: #D0C8BF;
}

::v-deep .st12 {
  fill: #C2BCB1;
}

::v-deep .st13 {
  fill: #CEC6B9;
}

::v-deep .st14 {
  fill: #C8C3B8;
}

::v-deep .st15 {
  fill: #CCC7BF;
}

::v-deep .st16 {
  fill: #CAC0B4;
}

::v-deep .st17 {
  fill: #C8C2BA;
}

::v-deep .st18 {
  fill: #D1CBC1;
}

::v-deep .st19 {
  fill: #E6E2D6;
}

::v-deep .st20 {
  fill: #EBE2CF;
}

::v-deep .st21 {
  fill: #DED9D1;
}

::v-deep .st22 {
  fill: #E0D8C7;
}

::v-deep .st23 {
  fill: #D3C9BC;
}

::v-deep .st24 {
  fill: #B5ACA1;
}

::v-deep .st25 {
  fill: #BDB5A9;
}

::v-deep .st26 {
  fill: #D7D1CB;
}

::v-deep .st27 {
  fill: #D0CAC5;
}

::v-deep .st28 {
  fill: #CEC6B7;
}

::v-deep .st29 {
  fill: #C2BAAD;
}

::v-deep .st30 {
  fill: #D6CDBD;
}

::v-deep .st31 {
  fill: #CFC9C2;
}

::v-deep .st32 {
  fill: #CDC6BF;
}

::v-deep .st33 {
  fill: #B5ACA2;
}

::v-deep .st34 {
  fill: #C4BEB5;
}

::v-deep .st35 {
  fill: #D8D1C8;
}

::v-deep .st36 {
  fill: #C7BDB0;
}

::v-deep .st37 {
  fill: #DBD2C3;
}

::v-deep .st38 {
  fill: #DFD6C7;
}

::v-deep .st39 {
  fill: #EAE3D2;
}

::v-deep .st40 {
  fill: #C2BAB0;
}

::v-deep .st41 {
  fill: #ABA298;
}

::v-deep .st42 {
  fill: #B4ABA0;
}

::v-deep .st43 {
  fill: #E3DBCC;
}

::v-deep .st44 {
  fill: #F1E9D9;
}

::v-deep .st45 {
  fill: #FAF7F1;
}

::v-deep .st46 {
  fill: #CBC4BB;
}

::v-deep .st47 {
  fill: #FFFFFF;
}

::v-deep .st48 {
  fill: #F5F1EC;
}

::v-deep .st49 {
  fill: #D7D3CC;
}

::v-deep .st50 {
  fill: #D2CDC5;
}

::v-deep .st51 {
  fill: #DBD7D0;
}

::v-deep .st52 {
  fill: #BBB4AC;
}

::v-deep .st53 {
  fill: #EBE8E4;
}

::v-deep .st54 {
  fill: #EAE3D7;
}

::v-deep .st55 {
  fill: #C2B9AC;
}

::v-deep .st56 {
  fill: #C9C0B1;
}

::v-deep .st57 {
  fill: #E4DFDA;
}

::v-deep .st58 {
  fill: #DCD6D0;
}

::v-deep .st59 {
  fill: #F9F7F6;
}

::v-deep .st60 {
  fill: #E6E1DC;
}

::v-deep .st61 {
  fill: #D6D1CC;
}

::v-deep .st62 {
  fill: #C8C0BA;
}

::v-deep .st63 {
  fill: #E5DFD7;
}

::v-deep .st64 {
  fill: #E0DAD0;
}

::v-deep .st65 {
  fill: #BAB1A6;
}

::v-deep .st66 {
  fill: #FAF6F1;
}

::v-deep .st67 {
  fill: #F3F0EB;
}

::v-deep .st68 {
  fill: #EBE8E3;
}

::v-deep .st69 {
  fill: #E0DDD7;
}

::v-deep .st70 {
  fill: #EAE8E2;
}

::v-deep .st71 {
  fill: #F0EEEB;
}

::v-deep .st72 {
  fill: #F2EFEA;
}

::v-deep .st73 {
  fill: #F1EEE9;
}

::v-deep .st74 {
  fill: #E7E2DD;
}

::v-deep .st75 {
  fill: #EDE9E4;
}

::v-deep .st76 {
  fill: #E9E4DF;
}

::v-deep .st77 {
  fill: none;
}

::v-deep .st78 {
  opacity: 0;
  fill: #000000;
  enable-background: new;
}

::v-deep .st79 {
  opacity: 0;
  fill: #000000;
  enable-background: new;
}

::v-deep .st80 {
  fill: #BFB7AC;
}

::v-deep .st81 {
  fill: #CDC7BA;
}

::v-deep .st82 {
  fill: #F3F3F3;
}

::v-deep .st83 {
  fill: #D1C9BC;
}

::v-deep .st84 {
  fill: #CAC5BC;
}

::v-deep .st85 {
  fill: #CEC5BC;
}

::v-deep .st86 {
  fill: #D0CBBD;
}

::v-deep .st87 {
  fill: #DCD4C6;
}

::v-deep .st88 {
  fill: #F2EAD9;
}

::v-deep .st89 {
  fill: #D2CCC2;
}

::v-deep .st90 {
  fill: #D7D0C2;
}

::v-deep .st91 {
  fill: #DED6CD;
}

::v-deep .st92 {
  fill: #C9BEB2;
}

::v-deep .st93 {
  fill: #C8C2B8;
}

::v-deep .st94 {
  fill: #D4CFC1;
}

::v-deep .st95 {
  fill: #CFC6C0;
}

::v-deep .st96 {
  fill: #C2BAB3;
}

::v-deep .st97 {
  fill: #D7D0CB;
}

::v-deep .st98 {
  fill: #CFCAC3;
}

::v-deep .st99 {
  fill: #CCC3B7;
}

::v-deep .st100 {
  fill: #B5ADA3;
}

::v-deep .st101 {
  fill: #C8C1BB;
}

::v-deep .st102 {
  fill: #D7CFC6;
}

::v-deep .st103 {
  fill: #E5E1D5;
}

::v-deep .st104 {
  fill: #DCD3C4;
}

::v-deep .st105 {
  fill: #ECE4D4;
}

::v-deep .st106 {
  fill: #E7DECF;
}

::v-deep .st107 {
  fill: #BAB3AC;
}

::v-deep .st108 {
  fill: #DBD7CE;
}

::v-deep .st109 {
  fill: #F7F2ED;
}

::v-deep .st110 {
  fill: #F2E9D9;
}

::v-deep .st111 {
  fill: #F4EEE1;
}

::v-deep .st112 {
  fill: #D5D1CA;
}

::v-deep .st113 {
  fill: #FBFAF9;
}

::v-deep .st114 {
  fill: #DCD7D0;
}

::v-deep .st115 {
  fill: #CCC5C0;
}

::v-deep .st116 {
  fill: #DED6CB;
}

::v-deep .st117 {
  fill: #F4EDE0;
}

::v-deep .st118 {
  fill: #DFE0DF;
}

::v-deep .st119 {
  fill: #E5E1DC;
}

::v-deep .st120 {
  fill: #E1DFD7;
}

::v-deep .st121 {
  fill: #D7D2CD;
}

::v-deep .st122 {
  fill: #F4F0EC;
}

::v-deep .st123 {
  fill: #EEEAE5;
}

::v-deep .st124 {
  fill: #EEECE9;
}

::v-deep .st125 {
  fill: #E1DDD7;
}

::v-deep .st126 {
  fill: #DCD8D2;
}

::v-deep .st127 {
  fill: #E4DED7;
}

::v-deep .st128 {
  fill: #D7D7D6;
}

::v-deep .st129 {
  fill: #F4F4F4;
}

::v-deep .st130 {
  fill: #EAE9E9;
}

::v-deep .st131 {
  fill: #ECE4DC;
}

::v-deep .st132 {
  fill: #B9B2A8;
}

::v-deep .st133 {
  fill: #C0B8AC;
}

::v-deep .st134 {
  fill: #DCD5CB;
}

::v-deep .st135 {
  fill: #D1C6B8;
}

::v-deep .st136 {
  fill: #C3BAAE;
}

::v-deep .st137 {
  fill: #CCC1B4;
}

::v-deep .st138 {
  fill: #BDB7AC;
}

::v-deep .st139 {
  fill: #CAC0B3;
}

::v-deep .st140 {
  fill: #C5BCAF;
}

::v-deep .st141 {
  fill: #C2BBB0;
}

::v-deep .st142 {
  fill: #CAC3BB;
}

::v-deep .st143 {
  fill: #C5BEB6;
}

::v-deep .st144 {
  fill: #C3BCB2;
}

::v-deep .st145 {
  fill: #DBD2CB;
}

::v-deep .st146 {
  fill: #D3C9C1;
}

::v-deep .st147 {
  fill: #E2DAD5;
}

::v-deep .st148 {
  fill: #F2EBE6;
}

::v-deep .st149 {
  fill: #D1CAC5;
}

::v-deep .st150 {
  fill: #F2EADF;
}

::v-deep .st151 {
  fill: #E7E2DB;
}

::v-deep .st152 {
  fill: #BDB4AD;
}

::v-deep .st153 {
  fill: #E3DED6;
}

::v-deep .st154 {
  fill: #D3CEC7;
}

::v-deep .st155 {
  fill: #C3BAB4;
}

::v-deep .st156 {
  fill: #FCFAF8;
}

::v-deep .st157 {
  fill: #F7F1E7;
}

::v-deep .st158 {
  fill: #F6F2EC;
}

::v-deep .st159 {
  fill: #F8F4F0;
}

::v-deep .st160 {
  fill: #FCF9F3;
}

::v-deep .st161 {
  fill: #E9E3D3;
}

::v-deep .st162 {
  fill: #F0EDE8;
}

::v-deep .st163 {
  fill: #E0E0E0;
}

::v-deep .st164 {
  fill: #BBB4A9;
}

::v-deep .st165 {
  fill: #EBE4DD;
}

::v-deep .st166 {
  fill: #CCC2B4;
}

::v-deep .st167 {
  fill: #C3BAAF;
}

::v-deep .st168 {
  fill: #E6E1DA;
}

::v-deep .st169 {
  fill: #B6AFA5;
}

::v-deep .st170 {
  fill: #C9C2B9;
}

::v-deep .st171 {
  fill: #C3BBB1;
}

::v-deep .st172 {
  fill: #C3BDB3;
}

::v-deep .st173 {
  fill: #CBC1B4;
}

::v-deep .st174 {
  fill: #D1C6BF;
}

::v-deep .st175 {
  fill: #D5CBC4;
}

::v-deep .st176 {
  fill: #D6CFC9;
}

::v-deep .st177 {
  fill: #D2C8BA;
}

::v-deep .st178 {
  fill: #DED7D1;
}

::v-deep .st179 {
  fill: #DFD9D1;
}

::v-deep .st180 {
  fill: #D6CFC6;
}

::v-deep .st181 {
  fill: #D7D0C3;
}

::v-deep .st182 {
  fill: #CCC6BD;
}

::v-deep .st183 {
  fill: #E5DDCF;
}

::v-deep .st184 {
  fill: #F5F1EE;
}

::v-deep .st185 {
  fill: #E0D9CA;
}

::v-deep .st186 {
  fill: #F7F3EE;
}

::v-deep .st187 {
  fill: #C9C0B8;
}

::v-deep .st188 {
  fill: #E1DBD1;
}

::v-deep .st189 {
  fill: #F9F3EA;
}

::v-deep .st190 {
  fill: #F6F2ED;
}

::v-deep .st191 {
  fill: #E8E3D9;
}

::v-deep .st192 {
  fill: #D7D6D6;
}

::v-deep .st193 {
  fill: #C6BEB2;
}

::v-deep .st194 {
  fill: #C4BBB0;
}

::v-deep .st195 {
  fill: #BCB5AB;
}

::v-deep .st196 {
  fill: #CBC5BA;
}

::v-deep .st197 {
  fill: #D8D3CA;
}

::v-deep .st198 {
  fill: #D0C9BF;
}

::v-deep .st199 {
  fill: #CFC5B8;
}

::v-deep .st200 {
  fill: #C7BFB7;
}

::v-deep .st201 {
  fill: #CFCABF;
}

::v-deep .st202 {
  fill: #ECE3DB;
}

::v-deep .st203 {
  fill: #E2DAD2;
}

::v-deep .st204 {
  fill: #DAD5CB;
}

::v-deep .st205 {
  fill: #ECE7E1;
}

::v-deep .st206 {
  fill: #E0D9CB;
}

::v-deep .st207 {
  fill: #F9F6F1;
}

::v-deep .st208 {
  fill: #F7F1E5;
}

::v-deep .st209 {
  fill: #F6F1EA;
}

::v-deep .st210 {
  fill: #E2DED5;
}

::v-deep .st211 {
  fill: #E4DED2;
}

::v-deep .st212 {
  fill: #EFE9DE;
}

::v-deep .st213 {
  fill: #C9C5B8;
}

::v-deep .st214 {
  fill: #BBB5AA;
}

::v-deep .st215 {
  fill: #CBC0B5;
}

::v-deep .st216 {
  fill: #C4BFB3;
}

::v-deep .st217 {
  fill: #B9B0A6;
}

::v-deep .st218 {
  fill: #C5BAAF;
}

::v-deep .st219 {
  fill: #BEB6AC;
}

::v-deep .st220 {
  fill: #C6BEB3;
}

::v-deep .st221 {
  fill: #D0C9BC;
}

::v-deep .st222 {
  fill: #E7DFD0;
}

::v-deep .st223 {
  fill: #DAD4CB;
}

::v-deep .st224 {
  fill: #E1DCD4;
}

::v-deep .st225 {
  fill: #E9E9E8;
}

::v-deep .st226 {
  fill: #CFC7BD;
}

::v-deep .st227 {
  fill: #DBD4CC;
}

::v-deep .st228 {
  fill: #DFDAD3;
}

::v-deep .st229 {
  fill: #DDD3CC;
}

::v-deep .st230 {
  fill: #DFD6C8;
}

::v-deep .st231 {
  fill: #EAE7E1;
}

::v-deep .st232 {
  fill: #E8DFD9;
}

::v-deep .st233 {
  fill: #E2DAD3;
}

::v-deep .st234 {
  fill: #F2EEEA;
}

::v-deep .st235 {
  fill: #E5E0DB;
}

::v-deep .st236 {
  fill: #E9E5DF;
}

::v-deep .st237 {
  fill: #F7F3F0;
}

::v-deep .st238 {
  fill: #EFE9E5;
}

::v-deep .st239 {
  fill: #EDE9E6;
}

::v-deep .st240 {
  fill: #ED2024;
}

::v-deep .st241 {
  fill: #C8C4B7;
}

::v-deep .st242 {
  fill: #E8E4DE;
}

::v-deep .st243 {
  fill: #B3A9A0;
}

::v-deep .st244 {
  fill: #D7D1C3;
}

::v-deep .st245 {
  fill: #CCC1B6;
}

::v-deep .st246 {
  fill: #C4BEB2;
}

::v-deep .st247 {
  fill: #D1CAC1;
}

::v-deep .st248 {
  fill: #C2B6AB;
}

::v-deep .st249 {
  fill: #BAAFA6;
}

::v-deep .st250 {
  fill: #BEB7AC;
}

::v-deep .st251 {
  fill: #B7B0A5;
}

::v-deep .st252 {
  fill: #CAC4B8;
}

::v-deep .st253 {
  fill: #C9BFB5;
}

::v-deep .st254 {
  fill: #D0C8BE;
}

::v-deep .st255 {
  fill: #DAD3C4;
}

::v-deep .st256 {
  fill: #CFC9BB;
}

::v-deep .st257 {
  fill: #DACEC7;
}

::v-deep .st258 {
  fill: #DFD9D2;
}

::v-deep .st259 {
  fill: #E8E2D1;
}

::v-deep .st260 {
  fill: #E2DDD5;
}

::v-deep .st261 {
  fill: #E3DDD1;
}

::v-deep .st262 {
  fill: #E9E0DA;
}

::v-deep .st263 {
  fill: #F0EAE6;
}

::v-deep .st264 {
  fill: #F3EEEA;
}

::v-deep .st265 {
  fill: #F6EFE3;
}

::v-deep .st266 {
  fill: #D6D6D5;
}

::v-deep .st267 {
  fill: #CCCDCC;
}

::v-deep .st268 {
  opacity: 0.8;
  fill: #ED2024;
  enable-background: new;
}

::v-deep .st269 {
  fill: #E0E0DF;
}

::v-deep .st270 {
  fill: #CDCDCC;
}

::v-deep .st271 {
  fill: #C8BFB2;
}

::v-deep .st272 {
  fill: #C5BAAD;
}

::v-deep .st273 {
  fill: #C9C1B5;
}

::v-deep .st274 {
  fill: #C3BAB0;
}

::v-deep .st275 {
  fill: #B0A79D;
}

::v-deep .st276 {
  fill: #CEC9BF;
}

::v-deep .st277 {
  fill: #C1BAB1;
}

::v-deep .st278 {
  fill: #C9C3B9;
}

::v-deep .st279 {
  fill: #BAB3AB;
}

::v-deep .st280 {
  fill: #DAD2C4;
}

::v-deep .st281 {
  fill: #E9E8E8;
}

::v-deep .st282 {
  fill: #DAD2C9;
}

::v-deep .st283 {
  fill: #E9E3DE;
}

::v-deep .st284 {
  fill: #DAD3CA;
}

::v-deep .st285 {
  fill: #DCD4CC;
}

::v-deep .st286 {
  fill: #E7E0D0;
}

::v-deep .st287 {
  fill: #E3DDD0;
}

::v-deep .st288 {
  fill: #E1DDD4;
}

::v-deep .st289 {
  fill: #E5DFD9;
}

::v-deep .st290 {
  fill: #E1DAD3;
}

::v-deep .st291 {
  fill: #E0DAD2;
}

::v-deep .st292 {
  fill: #E8DFDA;
}

::v-deep .st293 {
  fill: #F8F3EA;
}

::v-deep .st294 {
  fill: #F2ECE3;
}

::v-deep .st295 {
  fill: #EAE7E2;
}

::v-deep .st296 {
  fill: #F0EBE6;
}

::v-deep .st297 {
  fill: #C4BBB1;
}

::v-deep .st298 {
  fill: #CBC2B8;
}

::v-deep .st299 {
  fill: #C1B9AE;
}

::v-deep .st300 {
  fill: #C8C0B4;
}

::v-deep .st301 {
  fill: #CFC9BF;
}

::v-deep .st302 {
  fill: #BFB6AB;
}

::v-deep .st303 {
  fill: #DDD4C6;
}

::v-deep .st304 {
  fill: #CFC9BC;
}

::v-deep .st305 {
  fill: #CEC2B5;
}

::v-deep .st306 {
  fill: #DAD1C9;
}

::v-deep .st307 {
  fill: #EAE3D3;
}

::v-deep .st308 {
  fill: #F0E9E5;
}

::v-deep .st309 {
  fill: #E8E3DD;
}

::v-deep .st310 {
  fill: #EBE7E2;
}

::v-deep .st311 {
  fill: #E6E0D9;
}

::v-deep .st312 {
  fill: #F3EEEB;
}

::v-deep .st313 {
  fill: #F2ECE4;
}

::v-deep .st314 {
  fill: #FBF7F1;
}

::v-deep .st315 {
  fill: #F6F0E3;
}

::v-deep .st316 {
  fill: #E0DCD4;
}

::v-deep .st317 {
  fill: #E2DDD0;
}

::v-deep .st318 {
  fill: #EFECE8;
}
</style>
