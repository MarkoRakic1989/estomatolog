<template>
    <OwnerLayout>
        <template #header>
            <h1 class="text-2xl font-bold">Karton pacijenta: {{ user.name }}</h1>
        </template>

        <div class="container mx-auto px-6 py-8">
            <div class="flex flex-col lg:flex-row space-y-8 lg:space-y-0 lg:space-x-8">
                <!-- Mobile: chart on top; Desktop: chart on the right third -->
                <div ref="chartContainer" class=" border rounded p-4 lg:order-2 lg:w-1/3" v-html="dentalChart">
                </div>

                <!-- Reports + history -->
                <div class="flex-1 space-y-8 lg:order-1">
                    <!-- Modal trigger is handled by JS -->
                    <input type="checkbox" id="modal-tooth" class="modal-toggle" />
                    <div class="modal">
                        <div class="modal-box relative h-[80vh] overflow-auto flex flex-col">
                            <label for="modal-tooth" class="btn btn-sm btn-circle absolute right-2 top-2">✕</label>
                            <h3 class="font-bold text-lg mb-4">Izveštaj za zub {{ selectedTooth }}</h3>

                            <!-- Form -->
                            <form @submit.prevent="saveReport" class="space-y-4">
                                <div>
                                    <label class="label"><span class="label-text">Status</span></label>
                                    <div class="flex items-center space-x-4">
                                        <!-- healthy -->
                                        <label class="flex items-center space-x-1 cursor-pointer">
                                            <input type="radio" v-model="form.status" value="healthy" class="radio"
                                                :disabled="hasExtracted" />
                                            <span class="tooltip tooltip-bottom" data-tip="Zdrav">
                                                <svg class="w-6 h-6 stroke-current text-green-500" fill="none"
                                                    viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2"
                                                        d="M12 2C8.13 2 5 5.13 5 9c0 7 7 13 7 13s7-6 7-13c0-3.87-3.13-7-7-7z" />
                                                </svg>
                                            </span>
                                        </label>
                                        <!-- filled -->
                                        <label class="flex items-center space-x-1 cursor-pointer">
                                            <input type="radio" v-model="form.status" value="filled" class="radio"
                                                :disabled="hasExtracted" />
                                            <span class="tooltip tooltip-bottom" data-tip="Popravljen">
                                                <svg class="w-6 h-6 stroke-current text-yellow-500" fill="none"
                                                    viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2" d="M5 13l4 4L19 7" />
                                                </svg>
                                            </span>
                                        </label>
                                        <!-- extracted -->
                                        <label class="flex items-center space-x-1 cursor-pointer">
                                            <input type="radio" v-model="form.status" value="extracted" class="radio"
                                                :disabled="hasExtracted" />
                                            <span class="tooltip tooltip-bottom" data-tip="Izvađen">
                                                <svg class="w-6 h-6 stroke-current text-red-500" fill="none"
                                                    viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                                </svg>
                                            </span>
                                        </label>
                                    </div>
                                </div>

                                <div>
                                    <label class="label"><span class="label-text">Opis</span></label>
                                    <textarea v-model="form.report" class="textarea textarea-bordered w-full" rows="3"
                                        placeholder="Opis intervencije..." :disabled="hasExtracted"></textarea>
                                </div>

                                <button type="submit" class="btn btn-primary" :disabled="hasExtracted">Sačuvaj</button>
                            </form>

                            <!-- prethodni izveštaji za ovaj zub -->
                            <div v-if="reportsForSelected.length" class="mt-6 flex-1 overflow-auto">
                                <h4 class="font-semibold mb-2">Prethodni izveštaji</h4>
                                <ul class="menu bg-base-200 p-2 rounded space-y-2 w-full">
                                    <li v-for="r in reportsForSelected" :key="r.id" class="border rounded p-2">
                                        <div class="text-sm text-gray-500">{{ new
                                            Date(r.updated_at).toLocaleString('sr-RS') }}
                                        </div>
                                        <div class="flex items-center space-x-2">
                                            <span :class="statusClass(r.status)" class="badge badge-outline badge-sm">{{
                                                statusLabel(r.status) }}</span>
                                            <p class="flex-1">{{ r.report }}</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Tabela istorije (svi izveštaji) -->
                    <div>
                        <h2 class="text-xl font-semibold mb-2">Istorija izveštaja</h2>
                        <table class="table w-full table-zebra">
                            <thead>
                                <tr>
                                    <th>Zub</th>
                                    <th>Status</th>
                                    <th>Izveštaj</th>
                                    <th>Datum</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="r in sortedAllReports" :key="r.id">
                                    <td>{{ r.tooth_number }}</td>
                                    <td><span :class="statusClass(r.status)" class="badge badge-sm">{{
                                        statusLabel(r.status)
                                            }}</span></td>
                                    <td>{{ r.report }}</td>
                                    <td>{{ new Date(r.updated_at).toLocaleString('sr-RS') }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </OwnerLayout>
</template>

<script setup>
import { ref, computed, nextTick, onMounted, watch } from 'vue'
import { useForm } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'

const props = defineProps({
    user: Object,
    dentalChart: String,
    toothReports: Array
})
console.log(props.dentalChart)
const chartContainer = ref(null)
const selectedTooth = ref(null)
const form = useForm({
    tooth_number: null,
    status: 'healthy',
    report: ''
})

// lokalni niz za mutable izveštaje
const toothReportsLocal = ref([...props.toothReports])

// computed da proverimo da li je izvađen
const hasExtracted = computed(() =>
    toothReportsLocal.value.some(r => r.tooth_number === selectedTooth.value && r.status === 'extracted')
)

// svi izveštaji sortovani unazad po datumu
const sortedAllReports = computed(() =>
    [...toothReportsLocal.value].sort(
        (a, b) => new Date(b.updated_at) - new Date(a.updated_at)
    )
)

// samo izveštaji za trenutno izabrani zub
const reportsForSelected = computed(() =>
    toothReportsLocal.value
        .filter(r => r.tooth_number === selectedTooth.value)
        .sort((a, b) => new Date(b.updated_at) - new Date(a.updated_at))
)

function statusClass(s) {
    return {
        'badge-success': s === 'healthy',
        'badge-warning': s === 'filled',
        'badge-error': s === 'extracted'
    }
}
function statusLabel(s) {
    return s === 'healthy'
        ? 'Zdrav'
        : s === 'filled'
            ? 'Popravljen'
            : 'Izvađen'
}

// bind click + bojenje
async function bindTooth() {
    const container = chartContainer.value
    if (!container) return
    // obriši sve stare
    container
        .querySelectorAll('.status-healthy, .status-filled, .status-extracted')
        .forEach(el =>
            el.classList.remove('status-healthy', 'status-filled', 'status-extracted')
        )
    // dodaj klase iz baza/local
    toothReportsLocal.value.forEach(r => {
        const el = container.querySelector(`[data-tooth="${r.tooth_number}"]`)
        if (el) el.classList.add(`status-${r.status}`)
    })
    // bind klikove
    container.querySelectorAll('[data-tooth]').forEach(el => {
        el.style.cursor = 'pointer'
        el.onclick = () => {
            const t = el.getAttribute('data-tooth')
            selectedTooth.value = t
            form.tooth_number = t
            // uvek prazno polje za novi izveštaj
            form.status = 'healthy'
            form.report = ''
            document.getElementById('modal-tooth').checked = true
        }
    })
}

onMounted(() => nextTick(bindTooth))

// svaki put kad se dentalChart ili izveštaji promene
watch(
    () => [props.dentalChart, toothReportsLocal.value],
    () => nextTick(bindTooth),
    { deep: true }
)

function saveReport() {
    form.post(route('owner.toothReports.store', { user: props.user.id }), {
        preserveState: true,
        onSuccess: () => {
            // zatvori modal
            document.getElementById('modal-tooth').checked = false
            // dodaj novi izveštaj
            toothReportsLocal.value.push({
                id: Date.now(),
                tooth_number: form.tooth_number,
                status: form.status,
                report: form.report,
                updated_at: new Date().toISOString()
            })
        }
    })
}
</script>
