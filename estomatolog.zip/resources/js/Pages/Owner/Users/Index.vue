<template>
  <OwnerLayout>
    <template #header>
      <h1 class="text-2xl font-bold">Pacijenti</h1>
    </template>
    <div class="container mx-auto px-4 pt-20">
      <AdvancedSearch v-model:search="search" :loading="loading" />
      <div class="flex justify-between items-center mb-4">
        <span class="text-sm opacity-70">{{ users.total }} pacijenata</span>
        <button class="btn btn-sm btn-success" @click="goToAdd">+ Novi pacijent</button>
      </div>
      <table class="table table-zebra w-full">
        <thead>
          <tr>
            <th>Ime</th>
            <th>Email</th>
            <th>Status</th>
            <th>Badgevi</th>
            <th class="text-right">Akcije</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="u in users.data" :key="u.id">
            <td>{{ u.name }}</td>
            <td>{{ u.email }}</td>
            <td>
              <span :class="u.is_blocked ? 'badge badge-error' : 'badge badge-success'">
                {{ u.is_blocked ? 'Blokiran' : 'Aktivan' }}
              </span>
            </td>
            <td>
              <span
                v-for="badge in (u.diagnoses || [])"
                :key="badge.id"
                class="badge mx-1"
                :style="{ background: badge.color || '#ccc', color: 'white' }"
                >{{ badge.name }}</span>
            </td>
            <td class="text-right space-x-1">
              <button v-if="!u.is_blocked" @click="toggleBlock(u.id, true)" class="btn btn-xs btn-error">
                Blokiraj
              </button>
              <button v-else @click="toggleBlock(u.id, false)" class="btn btn-xs btn-success">
                Odblokiraj
              </button>
              <button @click="goToChart(u.id)" class="btn btn-xs btn-outline">
                Karton
              </button>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="mt-4 flex justify-center">
        <button
          v-for="link in users.links"
          :key="link.label"
          v-html="link.label"
          :disabled="!link.url"
          :class="['btn btn-sm mx-1', link.active ? 'btn-primary' : 'btn-outline']"
          @click="goTo(link.url)"
        />
      </div>
    </div>
  </OwnerLayout>
</template>

<script setup>
import { ref, watch } from 'vue'
import { useForm, router } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'
import AdvancedSearch from './Tabs/components/AdvancedSearch.vue'
import debounce from 'lodash.debounce'

const props = defineProps({ users: Object })
const form = useForm()
const search = ref('')
const loading = ref(false)

function toggleBlock(id, block) {
  const routeName = block ? 'owner.users.block' : 'owner.users.unblock'
  form.patch(route(routeName, id), {}, { onSuccess: () => form.reset() })
}

function goToChart(id) {
  router.get(route('owner.users.chart.dashboard', id))
}

function goTo(url) {
  router.get(url, {}, { preserveState: true, preserveScroll: true })
}

const debouncedSearch = debounce(() => {
  loading.value = true
  router.get(route('owner.users.index'), { q: search.value }, {
    preserveState: true,
    replace: true,
    onFinish: () => (loading.value = false),
  })
}, 350)

watch(search, debouncedSearch)

function goToAdd() {
  router.get(route('owner.users.create'))
}
</script>
