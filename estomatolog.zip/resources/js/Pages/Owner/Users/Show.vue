<template>
    <OwnerLayout>
        <template #header>
            <h2 class="text-2xl font-semibold">Karton pacijenta — {{ user.name }}</h2>
        </template>

        <div class="container mx-auto px-4 py-6 space-y-8">
            <div v-for="appt in appointments" :key="appt.id" class="border rounded-lg bg-white shadow p-6">
                <div class="flex justify-between items-center mb-4">
                    <div>
                        <h3 class="font-semibold text-lg">
                            Termin: {{ appt.date }} {{ appt.start_time }} – {{ appt.end_time }}
                        </h3>
                        <p class="text-sm text-gray-600">
                            Zaposleni: {{ appt.employee.name }},
                            Usluge: {{appt.services.map(s => s.name).join(', ')}}
                        </p>
                    </div>
                </div>

                <!-- Postojeći izveštaji -->
                <div v-if="appt.reports.length" class="mb-4">
                    <h4 class="font-medium mb-2">Izveštaji:</h4>
                    <ul class="space-y-2">
                        <li v-for="r in appt.reports" :key="r.id" class="border p-3 rounded">
                            <div class="text-sm text-gray-500 mb-1">
                                {{ new Date(r.created_at).toLocaleString() }}
                            </div>
                            <div class="whitespace-pre-wrap">{{ r.content }}</div>
                        </li>
                    </ul>
                </div>

                <!-- Forma za novi izveštaj -->
                <div>
                    <h4 class="font-medium mb-2">Dodaj izveštaj:</h4>
                    <form @submit.prevent="submitReport(appt.id)" class="space-y-2">
                        <textarea v-model="reports[appt.id]" placeholder="Upišite izveštaj..."
                            class="textarea textarea-bordered w-full" rows="3"></textarea>
                        <div class="flex space-x-2">
                            <button :disabled="processing[appt.id]" class="btn btn-primary">
                                {{ processing[appt.id] ? '...' : 'Sačuvaj' }}
                            </button>
                        </div>
                    </form>
                </div>

                <div v-if="flashSuccess" class="mt-2 text-green-600">
                    {{ flashSuccess }}
                </div>
            </div>
        </div>
    </OwnerLayout>
</template>

<script setup>
import { ref, reactive, computed } from 'vue'
import { useForm, usePage, router } from '@inertiajs/vue3'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'

const props = defineProps({
    user: Object,
    appointments: Array,
})
const page = usePage()

// Reaktivni stanja za svaki appointment
const reports = reactive({})
const processing = reactive({})

// Inicijalizacija praznih vrednosti
props.appointments.forEach(a => {
    reports[a.id] = ''
    processing[a.id] = false
})

const flashSuccess = computed(() => page.props.flash.success)

// Funkcija za slanje novog izveštaja
function submitReport(apptId) {
    processing[apptId] = true
    router.post(
        route('owner.users.report', { user: props.user.id, appointment: apptId }),
        { content: reports[apptId] },
        {
            onSuccess: () => {
                reports[apptId] = ''
            },
            onFinish: () => {
                processing[apptId] = false
            }
        }
    )
}
</script>

<style scoped>
/* nema dodatnih */
</style>
