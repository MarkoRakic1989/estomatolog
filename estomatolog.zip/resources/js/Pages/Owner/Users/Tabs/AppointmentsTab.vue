<template>
  <div>
    <div class="flex items-center gap-4 mb-4">
      <button class="btn btn-primary ml-auto" @click="showModal = true">+ Termin</button>
    </div>
    <table class="table w-full">
      <thead>
        <tr>
          <th>Lekar</th>
          <th>Od</th>
          <th>Do</th>
          <th>Status</th>
          <th>Napomena</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="appt in appointments" :key="appt.id">
          <td>{{ appt.doctor?.name }}</td>
          <td>{{ new Date(appt.start_at).toLocaleString('sr-RS') }}</td>
          <td>{{ appt.end_at ? new Date(appt.end_at).toLocaleString('sr-RS') : '-' }}</td>
          <td><span class="badge">{{ appt.status }}</span></td>
          <td>{{ appt.note }}</td>
          <td>
            <button
              v-if="appt.deletable"
              class="btn btn-xs btn-outline btn-error"
              @click="remove(appt.id)">
              🗑
            </button>
          </td>
        </tr>
      </tbody>
    </table>

    <dialog v-if="showModal" class="modal modal-open" @close="showModal = false">
      <form method="dialog" class="modal-box" @submit.prevent="saveAppointment">
        <h3 class="font-bold text-lg mb-4">Dodaj termin</h3>
        <label>Lekar</label>
        <input v-model="form.doctor_id" class="input input-bordered w-full mb-2" />
        <label>Od</label>
        <input v-model="form.start_at" type="datetime-local" class="input input-bordered w-full mb-2" />
        <label>Do</label>
        <input v-model="form.end_at" type="datetime-local" class="input input-bordered w-full mb-2" />
        <label>Status</label>
        <select v-model="form.status" class="select select-bordered w-full mb-2">
          <option value="scheduled">Zakazano</option>
          <option value="done">Urađeno</option>
          <option value="canceled">Otkazano</option>
        </select>
        <label>Napomena</label>
        <textarea v-model="form.note" class="textarea textarea-bordered w-full mb-2"></textarea>
        <div class="modal-action">
          <button type="submit" class="btn btn-primary" :disabled="form.processing">Sačuvaj</button>
          <button type="button" class="btn" @click="showModal = false">Otkaži</button>
        </div>
      </form>
    </dialog>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useForm, router } from '@inertiajs/vue3'

const props = defineProps({
  user: Object,
  appointments: Array // <- šalješ iz kontrolera kao prop!
})

const showModal = ref(false)
const form = useForm({
  doctor_id: '',
  start_at: '',
  end_at: '',
  status: 'scheduled',
  note: ''
})

function saveAppointment() {
  form.post(route('owner.users.appointments.store', props.user.id), {
    onSuccess: () => {
      showModal.value = false
      form.reset()
      router.reload({ only: ['appointments'] }) // refresuj samo termine
    }
  })
}

function remove(id) {
  if (confirm('Obrisati termin?')) {
    router.delete(route('owner.users.appointments.destroy', [props.user.id, id]), {
      onSuccess: () => router.reload({ only: ['appointments'] })
    })
  }
}
</script>
