<template>
  <div>
    <div class="flex items-center mb-4">
      <button class="btn btn-primary ml-auto" @click="showModal = true">+ Dijagnoza</button>
    </div>
    <div class="flex flex-wrap gap-2 mb-3">
      <span
        v-for="d in diagnoses"
        :key="d.id"
        class="badge"
        :style="{ background: d.color || '#ccc', color: 'white' }"
      >{{ d.name }}</span>
    </div>
    <table class="table w-full">
      <thead>
        <tr>
          <th>Tip</th>
          <th>Naziv</th>
          <th>Opis</th>
          <th>Datum</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="d in diagnoses" :key="d.id">
          <td>{{ typeLabel(d.type) }}</td>
          <td>{{ d.name }}</td>
          <td>{{ d.description }}</td>
          <td>{{ d.diagnosed_at ? new Date(d.diagnosed_at).toLocaleDateString('sr-RS') : '-' }}</td>
          <td>
            <button class="btn btn-xs btn-outline btn-error" @click="remove(d.id)">
              <span class="icon">🗑</span>
            </button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- Modal za unos -->
    <dialog v-if="showModal" class="modal modal-open" @close="showModal = false">
      <form method="dialog" class="modal-box" @submit.prevent="saveDiagnosis">
        <h3 class="font-bold text-lg mb-4">Dodaj dijagnozu/badge</h3>
        <label class="block mb-1">Tip</label>
        <select v-model="form.type" class="select select-bordered w-full mb-2">
          <option value="allergy">Alergija</option>
          <option value="disease">Bolest</option>
          <option value="warning">Upozorenje</option>
          <option value="therapy">Terapija</option>
          <option value="note">Napomena</option>
        </select>
        <label class="block mb-1">Naziv</label>
        <input v-model="form.name" class="input input-bordered w-full mb-2" />
        <label class="block mb-1">Opis</label>
        <textarea v-model="form.description" class="textarea textarea-bordered w-full mb-2"></textarea>
        <label class="block mb-1">Boja badge-a</label>
        <input v-model="form.color" class="input input-bordered w-full mb-2" type="color" />
        <label class="block mb-1">Datum</label>
        <input v-model="form.diagnosed_at" class="input input-bordered w-full mb-2" type="date" />
        <div class="modal-action">
          <button type="submit" class="btn btn-primary" :disabled="form.processing">Sačuvaj</button>
          <button type="button" class="btn" @click="showModal = false">Otkaži</button>
        </div>
      </form>
    </dialog>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useForm, router } from '@inertiajs/vue3'
const props = defineProps({
  user: Object,
  diagnoses: Object // šalješ kao prop iz kontrolera!
})

const showModal = ref(false)
const form = useForm({ type: 'allergy', name: '', description: '', color: '#009688', diagnosed_at: '' })

function saveDiagnosis() {
  form.post(route('owner.users.diagnoses.store', props.user.id), {
    onSuccess: () => {
      showModal.value = false
      form.reset()
      router.reload({ only: ['diagnoses'] })
    }
  })
}
function remove(id) {
  if (confirm('Obrisati ovu dijagnozu?')) {
    router.delete(route('owner.users.diagnoses.destroy', [props.user.id, id]), {
      onSuccess: () => router.reload({ only: ['diagnoses'] })
    })
  }
}
const diagnoses = computed(() => props.diagnoses || [])
console.log(diagnoses);
function typeLabel(type) {
  switch (type) {
    case 'allergy': return 'Alergija'
    case 'disease': return 'Bolest'
    case 'warning': return 'Upozorenje'
    case 'therapy': return 'Terapija'
    case 'note': return 'Napomena'
    default: return type
  }
}
</script>
