<template>
  <div>
    <div class="flex items-center mb-4">
      <UploadModal
        v-if="showUpload"
        :user-id="user.id"
        @close="closeUpload"
        @uploaded="refreshDocuments"
      />
      <button class="btn btn-outline btn-primary" @click="showUpload = true">Dodaj dokument</button>
    </div>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
      <div
        v-for="doc in documents"
        :key="doc.id"
        class="card p-2 bg-base-200 shadow rounded"
      >
        <img
          v-if="doc.file && isImage(doc.file)"
          :src="`/storage/${doc.file}`"
          class="rounded mb-2 max-h-40 mx-auto"
        />
        <div class="font-semibold">{{ doc.title || doc.type }}</div>
        <div class="text-xs opacity-70">{{ doc.note }}</div>
        <a
          :href="`/storage/${doc.file}`"
          target="_blank"
          class="btn btn-xs btn-primary mt-2"
        >Otvori</a>
        <button class="btn btn-xs btn-error mt-2" @click="remove(doc.id)">Obriši</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useForm, router } from '@inertiajs/vue3'
import UploadModal from './components/UploadModal.vue'

const props = defineProps({
  user: Object,
  documents: Array // šalješ kao prop iz kontrolera!
})

const showUpload = ref(false)

function isImage(file) {
  return /\.(jpg|jpeg|png|gif)$/i.test(file)
}

function remove(id) {
  if (confirm('Obrisati dokument?')) {
    router.delete(route('owner.users.documents.destroy', [props.user.id, id]), {
      onSuccess: () => router.reload({ only: ['documents'] })
    })
  }
}
function refreshDocuments() {
  showUpload.value = false
  router.reload({ only: ['documents'] })
}
function closeUpload() {
  showUpload.value = false
}
const documents = computed(() => props.documents || [])
</script>
