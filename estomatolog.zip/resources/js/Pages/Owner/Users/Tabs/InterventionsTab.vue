<template>
  <div>
    <div class="flex items-center gap-4 mb-4">
      <input
        v-model="search"
        @input="searchInterventions"
        class="input input-bordered"
        placeholder="Pretraga (opis, tip)..."
      />
      <select v-model="status" @change="filterStatus" class="select select-bordered">
        <option value="">Status: Svi</option>
        <option value="planned">Planirano</option>
        <option value="done">Urađeno</option>
        <option value="canceled">Otkazano</option>
      </select>
      <button class="btn btn-primary ml-auto" @click="showModal = true">+ Intervencija</button>
    </div>
    <table class="table table-zebra w-full">
      <thead>
        <tr>
          <th>Zub</th>
          <th>Površina</th>
          <th>Vrsta</th>
          <th>Opis</th>
          <th>Doktor</th>
          <th>Datum</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in interventions" :key="item.id">
          <td>{{ item.tooth?.code || '-' }}</td>
          <td>{{ item.surface || '-' }}</td>
          <td>{{ item.type }}</td>
          <td>{{ item.description }}</td>
          <td>{{ item.doctor?.name || '-' }}</td>
          <td>{{ item.performed_at ? new Date(item.performed_at).toLocaleDateString('sr-RS') : '-' }}</td>
          <td>
            <button class="btn btn-xs btn-outline btn-error" @click="remove(item.id)">
              <span class="icon">🗑</span>
            </button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- Modal za dodavanje intervencije -->
    <InterventionModal
      v-if="showModal"
      :user-id="user.id"
      @close="showModal = false"
      @saved="onSaved"
    />
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { router } from '@inertiajs/vue3'
import debounce from 'lodash.debounce'
import InterventionModal from './components/InterventionModal.vue'

const props = defineProps({
  user: Object,
  interventions: Array // šalješ iz kontrolera kao prop!
})

const search = ref('')
const status = ref('')
const showModal = ref(false)

const interventions = computed(() => props.interventions || [])

const searchInterventions = debounce(() => {
  router.get(
    route('owner.users.chart', props.user.id),
    { q: search.value, status: status.value, tab: 'intervencije' },
    { preserveState: true, replace: true, only: ['interventions'] }
  )
}, 400)

function filterStatus() {
  router.get(
    route('owner.users.chart', props.user.id),
    { q: search.value, status: status.value, tab: 'intervencije' },
    { preserveState: true, replace: true, only: ['interventions'] }
  )
}

function remove(id) {
  if (confirm('Obrisati ovu intervenciju?')) {
    router.delete(route('owner.users.interventions.destroy', [props.user.id, id]), {
      onSuccess: () => router.reload({ only: ['interventions'] })
    })
  }
}
function onSaved() {
  showModal.value = false
  router.reload({ only: ['interventions'] })
}
</script>
