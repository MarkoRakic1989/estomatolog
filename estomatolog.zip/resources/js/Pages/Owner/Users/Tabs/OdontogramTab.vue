<template>
  <div>
    <h2 class="text-xl font-bold mb-4">Digitalni Odontogram</h2>
    <svg viewBox="0 0 200 120" class="w-full max-w-xl mx-auto odontogram-svg">
      <g v-for="tooth in teeth" :key="tooth.code">
        <path :id="'tooth-' + tooth.code" :d="tooth.path" :fill="getColor(tooth.code)" stroke="#333" stroke-width="2"
          @mouseenter="showTooltip(tooth.code)" @mouseleave="hideTooltip" @click="onToothClick(tooth.code)" />
        <text v-if="tooth.cx && tooth.cy" :x="tooth.cx" :y="tooth.cy" text-anchor="middle" font-size="14"
          fill="#374151">{{ tooth.code }}</text>
      </g>
      <foreignObject v-if="tooltip.show" :x="tooltip.x" :y="tooltip.y" width="140" height="32">
        <div class="odontogram-tooltip">
          Zub: {{ tooltip.tooth }}<br>
          Status: {{ statusLabel(tooltip.tooth) }}
        </div>
      </foreignObject>
    </svg>
    <dialog v-if="modalTooth" class="modal modal-open">
      <form method="dialog" class="modal-box" @submit.prevent="saveStatus">
        <h3 class="font-bold text-lg mb-4">Zub {{ modalTooth }}</h3>
        <label class="block mb-1">Status</label>
        <select v-model="form.status" class="select select-bordered w-full mb-4">
          <option value="healthy">Zdrav</option>
          <option value="caries">Karijes</option>
          <option value="filling">Plomba</option>
          <option value="extracted">Izvađen</option>
          <option value="implant">Implant</option>
          <option value="crown">Krunica</option>
        </select>
        <label class="block mb-1">Napomena</label>
        <textarea v-model="form.note" class="textarea textarea-bordered w-full mb-2"></textarea>
        <div class="modal-action">
          <button type="submit" class="btn btn-primary">Sačuvaj</button>
          <button type="button" class="btn" @click="modalTooth = null">Otkaži</button>
        </div>
      </form>
    </dialog>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useForm, router } from '@inertiajs/vue3'

const props = defineProps({
  teeth: { type: Array, default: () => [] },
  toothStatuses: { type: Array, default: () => [] },
  user: Object
})

// Tooltip
const tooltip = ref({ show: false, x: 80, y: 20, tooth: null })
function showTooltip(code) { tooltip.value = { ...tooltip.value, show: true, tooth: code } }
function hideTooltip() { tooltip.value = { ...tooltip.value, show: false } }

// Status iz baze
const statusMap = computed(() => {
  const map = {}
  for (const s of props.toothStatuses || []) {
    map[s.tooth?.code || s.tooth_id] = s.status
  }
  return map
})
function getColor(code) {
  const s = statusMap.value[code] || 'healthy'
  switch (s) {
    case 'caries': return '#f87171'
    case 'filling': return '#60a5fa'
    case 'crown': return '#c7d2fe'
    case 'extracted': return '#9ca3af'
    case 'implant': return '#fcd34d'
    default: return '#b5f5b7'
  }
}
function statusLabel(code) {
  const s = statusMap.value[code] || 'zdrav'
  switch (s) {
    case 'caries': return 'Karijes'
    case 'filling': return 'Plomba'
    case 'crown': return 'Krunica'
    case 'extracted': return 'Izvađen'
    case 'implant': return 'Implant'
    default: return 'Zdrav'
  }
}

// Modal i forma
const modalTooth = ref(null)
const form = useForm({ status: 'healthy', note: '', tooth_id: '' })
function onToothClick(code) {
  modalTooth.value = code
  form.tooth_id = code
  form.status = statusMap.value[code] || 'healthy'
  form.note = ''
}
function saveStatus() {
  form.post(route('owner.users.teeth-status.store', props.user.id), {
    onSuccess: () => {
      modalTooth.value = null
      router.reload({ only: ['toothStatuses'] })
    }
  })
}
</script>

<style scoped>
.odontogram-svg path {
  cursor: pointer;
  transition: fill 0.2s, stroke 0.2s;
}

.odontogram-svg path:hover {
  stroke: #f59e42;
  filter: brightness(1.14);
}

.odontogram-tooltip {
  background: #fff8dc;
  border: 1px solid #eab308;
  border-radius: 6px;
  font-size: 14px;
  color: #374151;
  padding: 6px 10px;
  pointer-events: none;
  box-shadow: 0 2px 12px #0001;
  z-index: 100;
}
</style>
