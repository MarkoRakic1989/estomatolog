<template>
  <div class="max-w-2xl bg-base-100 rounded shadow p-6 mx-auto">
    <div class="flex items-center mb-6">
      <div class="avatar">
        <div class="w-20 rounded-full bg-primary text-primary-content flex items-center justify-center text-2xl">
          <span v-if="!user.photo">{{ initials }}</span>
          <img v-else :src="user.photo" alt="Avatar" />
        </div>
      </div>
      <div class="ml-6">
        <h2 class="text-2xl font-semibold">{{ user.name }}</h2>
        <div class="text-gray-500">{{ user.email }}</div>
        <div v-if="user.is_blocked" class="badge badge-error mt-2">Blokiran</div>
        <div v-else class="badge badge-success mt-2">Aktivan</div>
      </div>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <label class="block text-sm text-gray-500 mb-1">Pol:</label>
        <div class="font-semibold">{{ genderLabel(user.gender) }}</div>
      </div>
      <div>
        <label class="block text-sm text-gray-500 mb-1">Datum rođenja:</label>
        <div class="font-semibold">{{ date(user.date_of_birth) }}</div>
      </div>
      <div>
        <label class="block text-sm text-gray-500 mb-1">Telefon:</label>
        <div class="font-semibold">{{ user.phone || '-' }}</div>
      </div>
      <div>
        <label class="block text-sm text-gray-500 mb-1">Adresa:</label>
        <div class="font-semibold">{{ user.address || '-' }}</div>
      </div>
      <div>
        <label class="block text-sm text-gray-500 mb-1">JMBG:</label>
        <div class="font-semibold">{{ user.jmbg || '-' }}</div>
      </div>
      <div>
        <label class="block text-sm text-gray-500 mb-1">Napomena:</label>
        <div class="font-semibold">{{ user.note || '-' }}</div>
      </div>
    </div>
    <div v-if="user.diagnoses && user.diagnoses.length" class="mt-6">
      <label class="block text-sm text-gray-500 mb-1">Badgevi / Dijagnoze:</label>
      <div class="flex flex-wrap gap-2">
        <span v-for="d in user.diagnoses" :key="d.id"
              class="badge"
              :style="{ background: d.color || '#ccc', color: 'white' }">
          {{ d.name }}
        </span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
const props = defineProps({ user: Object })

const initials = computed(() =>
  (props.user.name || '')
    .split(' ')
    .map(w => w[0])
    .join('')
    .slice(0, 2)
    .toUpperCase()
)

function genderLabel(g) {
  if (!g) return '-'
  if (g === 'm') return 'Muški'
  if (g === 'f') return 'Ženski'
  return g
}
function date(d) {
  if (!d) return '-'
  return new Date(d).toLocaleDateString('sr-RS')
}
</script>
