<template>
  <div class="form-control w-full mb-6">
    <div class="input-group">
      <input
        class="input input-bordered w-full"
        type="text"
        v-model="search"
        placeholder="Pretraga pacijenata, usluga, statusa..."
        @input="$emit('update:search', search)"
      />
      <button class="btn btn-outline" @click="clear">
        <span class="icon">✖️</span>
      </button>
    </div>
  </div>
</template>
<script setup>
import { ref, watch } from 'vue'
const props = defineProps({ modelValue: String, loading: Boolean })
const search = ref(props.modelValue || '')
function clear() {
  search.value = ''
  emit('update:search', '')
}
const emit = defineEmits(['update:search'])
watch(() => props.modelValue, val => {
  if (val !== search.value) search.value = val
})
</script>
