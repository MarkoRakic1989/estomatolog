<template>
  <dialog class="modal modal-open">
    <form method="dialog" class="modal-box" @submit.prevent="save">
      <h3 class="font-bold text-lg mb-4">Nova intervencija</h3>
      <label class="block mb-1">Zub</label>
      <select v-model="form.tooth_id" class="select select-bordered w-full mb-2">
        <option value="">(nije vezano za zub)</option>
        <option v-for="t in teeth" :key="t.id" :value="t.id">{{ t.code }}</option>
      </select>
      <label class="block mb-1">Površina</label>
      <input v-model="form.surface" class="input input-bordered w-full mb-2" />
      <label class="block mb-1">Tip intervencije</label>
      <input v-model="form.type" class="input input-bordered w-full mb-2" placeholder="Npr. plombiranje, ekstrakcija" />
      <label class="block mb-1">Opis</label>
      <textarea v-model="form.description" class="textarea textarea-bordered w-full mb-2"></textarea>
      <div class="modal-action">
        <button type="submit" class="btn btn-primary" :disabled="form.processing">Sačuvaj</button>
        <button type="button" class="btn" @click="$emit('close')">Otkaži</button>
      </div>
    </form>
  </dialog>
</template>

<script setup>
import { ref } from 'vue'
import { useForm } from '@inertiajs/vue3'
const props = defineProps({
  userId: Number,
  teeth: { type: Array, default: () => [] } // šalješ kao prop iz parenta (nije više axios)
})
const emit = defineEmits(['close', 'saved'])

const form = useForm({ tooth_id: '', surface: '', type: '', description: '' })

function save() {
  form.post(route('owner.users.interventions.store', props.userId), {
    onSuccess: () => {
      form.reset()
      emit('saved')
      emit('close')
    }
  })
}
</script>
