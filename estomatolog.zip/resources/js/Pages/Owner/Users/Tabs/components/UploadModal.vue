<template>
  <dialog class="modal modal-open">
    <form method="dialog" class="modal-box" @submit.prevent="upload" enctype="multipart/form-data">
      <h3 class="font-bold text-lg mb-4">Upload dokumenata/slika</h3>
      <input
        type="file"
        @change="onFileChange"
        multiple
        class="file-input file-input-bordered w-full mb-3"
      />
      <label>Naslov</label>
      <input v-model="form.title" class="input input-bordered w-full mb-2" />
      <label>Napomena</label>
      <textarea v-model="form.note" class="textarea textarea-bordered w-full mb-2"></textarea>
      <div class="modal-action">
        <button type="submit" class="btn btn-primary" :disabled="form.processing">Upload</button>
        <button type="button" class="btn" @click="$emit('close')">Otkaži</button>
      </div>
    </form>
  </dialog>
</template>

<script setup>
import { ref } from 'vue'
import { useForm } from '@inertiajs/vue3'
const props = defineProps({ userId: Number })
const emit = defineEmits(['uploaded', 'close'])

// Ova forma NE podržava direktno array fajlova, pa šaljemo upload jedan po jedan:
const form = useForm({ file: null, title: '', note: '' })
const files = ref([])

function onFileChange(e) {
  files.value = Array.from(e.target.files)
}

function upload() {
  if (!files.value.length) return

  // Multiple upload inertia-friendly: šalješ jedan po jedan i refresuješ parent na kraju!
  let counter = 0
  function uploadNext() {
    if (counter >= files.value.length) {
      form.reset()
      files.value = []
      emit('uploaded')
      emit('close')
      return
    }
    form.file = files.value[counter]
    form.post(route('owner.users.documents.store', props.userId), {
      forceFormData: true,
      preserveScroll: true,
      onSuccess: () => {
        counter++
        uploadNext()
      }
    })
  }
  uploadNext()
}
</script>
