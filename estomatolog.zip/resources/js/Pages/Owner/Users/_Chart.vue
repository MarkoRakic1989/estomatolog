<template>
  <OwnerLayout>
    <template #header>
      <h1 class="text-2xl font-bold">Digitalni odontogram</h1>
    </template>

    <div class="max-w-7xl mx-auto mt-8 card bg-base-100 shadow p-6 overflow-auto">
      <div v-if="selectionGroups.length" class="mb-4 flex flex-col gap-6">
        <div v-for="group in selectionGroups" :key="group.type"
          class="flex flex-col gap-2 md:flex-row md:items-center border-b pb-2">
          <div class="font-semibold w-32">
            {{ groupLabel(group.type) }}
            <span class="text-xs text-gray-500">({{ group.ids.length }})</span>
          </div>
          <div class="flex flex-row gap-2">
            <div :class="[
              'cursor-pointer px-4 py-1 rounded-xl border text-sm select-none',
              selectionState[group.type].mode === 'status'
                ? 'bg-blue-100 border-blue-600 font-bold'
                : 'bg-white border-gray-300 hover:bg-gray-100'
            ]" @click="selectionState[group.type].mode = 'status'">
              Status
            </div>
            <div :class="[
              'cursor-pointer px-4 py-1 rounded-xl border text-sm select-none',
              selectionState[group.type].mode === 'therapy'
                ? 'bg-blue-100 border-blue-600 font-bold'
                : 'bg-white border-gray-300 hover:bg-gray-100'
            ]" @click="selectionState[group.type].mode = 'therapy'">
              Terapija
            </div>
          </div>
          <div class="flex flex-wrap gap-2 ml-0 md:ml-4">
            <div v-for="opt in selectionState[group.type].mode === 'status' ? group.statuses : group.therapies"
              :key="opt" :class="[
                'cursor-pointer px-4 py-1 rounded-2xl border text-sm select-none transition',
                selectionState[group.type].selected === opt
                  ? 'bg-blue-600 text-white border-blue-600 font-bold shadow'
                  : 'bg-white border-gray-300 hover:bg-blue-100'
              ]" @click="selectionState[group.type].selected = opt">
              {{ opt }}
            </div>
          </div>
          <input v-model="selectionState[group.type].note" placeholder="Napomena (opciono)"
            class="input input-bordered w-64 ml-0 md:ml-4" />
        </div>
        <div>
          <button class="btn btn-primary mr-2" :disabled="!allGroupsValid" @click="applyGroupedStatus">
            Sačuvaj za selektovano
          </button>
          <button class="btn btn-ghost" @click="clearSelection">Očisti selekciju</button>
        </div>
      </div>

      <table class="w-full table-fixed border-collapse">
        <tr>
          <td v-for="n in quadrants.upperRight" :key="n" class="p-1">
            <div v-if="svgs[n]" class="svg-container" v-html="svgs[n]" @mouseenter="e => bindSvgEvents(e, n)"></div>
          </td>
          <td v-for="n in quadrants.upperLeft" :key="n" class="p-1">
            <div v-if="svgs[n]" class="svg-container" v-html="svgs[n]" @mouseenter="e => bindSvgEvents(e, n)"></div>
          </td>
        </tr>
        <tr>
          <td v-for="n in quadrants.lowerRight" :key="n" class="p-1">
            <div v-if="svgs[n]" class="svg-container" v-html="svgs[n]" @mouseenter="e => bindSvgEvents(e, n)"></div>
          </td>
          <td v-for="n in quadrants.lowerLeft" :key="n" class="p-1">
            <div v-if="svgs[n]" class="svg-container" v-html="svgs[n]" @mouseenter="e => bindSvgEvents(e, n)"></div>
          </td>
        </tr>
      </table>
      <div v-if="tooltip.show" :style="tooltip.style"
        class="fixed z-50 p-2 bg-white border shadow rounded text-xs pointer-events-none">
        {{ tooltip.text }}
      </div>
    </div>
  </OwnerLayout>
</template>

<script setup>
import { ref, reactive, computed, watch, nextTick } from 'vue'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'

const quadrants = {
  upperRight: [18, 17, 16, 15, 14, 13, 12, 11],
  upperLeft: [21, 22, 23, 24, 25, 26, 27, 28],
  lowerLeft: [31, 32, 33, 34, 35, 36, 37, 38],
  lowerRight: [48, 47, 46, 45, 44, 43, 42, 41]
}

const modules = import.meta.glob('../../../svg/tooth_*.svg', { as: 'raw', eager: true })
const svgs = {}
Object.entries(modules).forEach(([path, raw]) => {
  const m = path.match(/tooth_(\d+)\.svg$/)
  if (m) svgs[+m[1]] = raw
})

const selectedSurfaces = ref([])
const statuses = reactive({})

const korenStatuses = [
  'Zdrav koren', 'Cista', 'Granulom', 'Periapikalna lezija', 'Parodontitis'
]
const korenTherapies = [
  'Endodontski tretman', 'Vađenje', 'Apikotomija', 'Implantacija'
]
const krunicaStatuses = [
  'Zdrav', 'Karijes', 'Plomba', 'Ispao ispun', 'Krunica', 'Most', 'Fraktura', 'Ortodontska bravica', 'Pigmentacija'
]
const krunicaTherapies = [
  'Fisure zatvorene', 'Lečenje pulpitisa', 'Zamena ispuna', 'Izrada krunice', 'Izrada mosta', 'Protetika'
]

const selectionState = reactive({
  R: { mode: 'status', selected: '', note: '' },
  K: { mode: 'status', selected: '', note: '' }
})

const selectionGroups = computed(() => {
  if (!selectedSurfaces.value.length) return []
  const groups = { R: [], K: [] }
  selectedSurfaces.value.forEach(id => {
    const type = id.includes('_R') ? 'R' : 'K'
    groups[type].push(id)
  })
  return ['R', 'K'].filter(type => groups[type].length).map(type => ({
    type,
    ids: groups[type],
    statuses: type === 'R' ? korenStatuses : krunicaStatuses,
    therapies: type === 'R' ? korenTherapies : krunicaTherapies
  }))
})

function groupLabel(type) {
  return type === 'R' ? 'Koren' : 'Krunica/Deo krunice'
}

const allGroupsValid = computed(() =>
  selectionGroups.value.every(g => selectionState[g.type].selected)
)

const tooltip = reactive({ show: false, text: '', style: {} })

function showTooltip(text, evt) {
  tooltip.show = true
  tooltip.text = text
  tooltip.style = {
    top: evt.clientY + 10 + 'px',
    left: evt.clientX + 10 + 'px',
    position: 'fixed'
  }
}
function hideTooltip() {
  tooltip.show = false
  tooltip.text = ''
}

function statusClass(status) {
  if (!status) return ''
  const map = {
    // STATUSI
    'Karijes': 'odontogram-caries',
    'Plomba': 'odontogram-filling',
    'Krunica': 'odontogram-crown',
    'Most': 'odontogram-bridge',
    'Ortodontska bravica': 'odontogram-ortho',
    'Zdrav': 'odontogram-healthy',
    'Ispao ispun': 'odontogram-missingfill',
    'Fraktura': 'odontogram-fracture',
    'Pigmentacija': 'odontogram-pigment',
    'Zdrav koren': 'odontogram-healthy-root',
    'Cista': 'odontogram-cyst',
    'Granulom': 'odontogram-granulom',
    'Periapikalna lezija': 'odontogram-periapex',
    'Parodontitis': 'odontogram-parodontitis',
    // TERAPIJE
    'Endodontski tretman': 'odontogram-endo',
    'Vađenje': 'odontogram-extract',
    'Apikotomija': 'odontogram-apico',
    'Implantacija': 'odontogram-implant',
    'Fisure zatvorene': 'odontogram-fissure',
    'Lečenje pulpitisa': 'odontogram-pulpitis',
    'Zamena ispuna': 'odontogram-replacefill',
    'Izrada krunice': 'odontogram-crownwork',
    'Izrada mosta': 'odontogram-bridgework',
    'Protetika': 'odontogram-prosthetic',
  }
  return map[status] || ''
}

function applyGroupedStatus() {
  selectionGroups.value.forEach(group => {
    group.ids.forEach(id => {
      statuses[id] = {
        status: selectionState[group.type].selected,
        note: selectionState[group.type].note,
        type: selectionState[group.type].mode
      }
    })
    selectionState[group.type].selected = ''
    selectionState[group.type].note = ''
    selectionState[group.type].mode = 'status'
  })
  nextTick(() => {
    updateSvgStatusOnly()
    selectedSurfaces.value = []
  })
}

function clearSelection() {
  selectedSurfaces.value = []
  updateSvgSelection()
}

const bindSvgEvents = (e, toothNum) => {
  const svg = e.currentTarget.querySelector('svg')
  if (!svg) return

  svg.querySelectorAll('.clickable').forEach(el => {
    el.onmouseenter = evt => {
      let t = el.getAttribute('data-title')
      if (!t && statuses[el.id]?.note) t = statuses[el.id]?.note
      if (!t && statuses[el.id]?.status) t = statuses[el.id]?.status
      if (t) showTooltip(t, evt)
    }
    el.onmousemove = evt => {
      if (tooltip.show) {
        tooltip.style = {
          top: evt.clientY + 10 + 'px',
          left: evt.clientX + 10 + 'px',
          position: 'fixed'
        }
      }
    }
    el.onmouseleave = hideTooltip

    el.onclick = ev => {
      ev.stopPropagation()
      const id = el.id
      if (selectedSurfaces.value.includes(id)) {
        selectedSurfaces.value = selectedSurfaces.value.filter(x => x !== id)
      } else {
        selectedSurfaces.value.push(id)
      }
      updateSvgSelection()
    }
  })
  updateSvgSelection()
}

function updateSvgSelection() {
  setTimeout(() => {
    document.querySelectorAll('.svg-container svg').forEach(svg => {
      svg.querySelectorAll('.clickable').forEach(el => {
        let base = 'clickable'
        const st = statuses[el.id]
        if (st) base += ' ' + statusClass(st.status)
        if (selectedSurfaces.value.includes(el.id)) base += ' surface-selected'
        el.setAttribute('class', base)
      })
    })
  }, 30)
}
function updateSvgStatusOnly() {
  setTimeout(() => {
    document.querySelectorAll('.svg-container svg').forEach(svg => {
      svg.querySelectorAll('.clickable').forEach(el => {
        let base = 'clickable'
        const st = statuses[el.id]
        if (st) base += ' ' + statusClass(st.status)
        el.setAttribute('class', base)
      })
    })
  }, 30)
}
watch(selectedSurfaces, updateSvgSelection)
watch(statuses, updateSvgStatusOnly, { deep: true })
</script>

<style scoped>
/* STATUSI */
::v-deep .odontogram-caries {
  fill: #dc2626 !important;
  opacity: 1 !important;
}

::v-deep .odontogram-filling {
  fill: #2563eb !important;
  opacity: 1 !important;
}

::v-deep .odontogram-crown {
  fill: #fbbf24 !important;
  opacity: 1 !important;
}

::v-deep .odontogram-endo {
  fill: #a855f7 !important;
  opacity: 1 !important;
}

::v-deep .odontogram-extract {
  fill: #64748b !important;
  opacity: 0.5 !important;
}

::v-deep .odontogram-implant {
  fill: #57534e !important;
  opacity: 1 !important;
}

::v-deep .odontogram-bridge {
  fill: #f59e42 !important;
  opacity: 1 !important;
}

::v-deep .odontogram-healthy {
  fill: #4ade80 !important;
  opacity: 1 !important;
}

::v-deep .odontogram-missingfill {
  fill: #0ea5e9 !important;
  opacity: 1 !important;
}

::v-deep .odontogram-fracture {
  fill: #ef4444 !important;
  opacity: 1 !important;
}

::v-deep .odontogram-pigment {
  fill: #5eead4 !important;
  opacity: 1 !important;
}

::v-deep .odontogram-ortho {
  fill: #f472b6 !important;
  opacity: 1 !important;
}

::v-deep .odontogram-cyst {
  fill: #f43f5e !important;
  opacity: 1 !important;
}

::v-deep .odontogram-granulom {
  fill: #eab308 !important;
  opacity: 1 !important;
}

::v-deep .odontogram-periapex {
  fill: #d946ef !important;
  opacity: 1 !important;
}

::v-deep .odontogram-parodontitis {
  fill: #22d3ee !important;
  opacity: 1 !important;
}

::v-deep .odontogram-healthy-root {
  fill: #16a34a !important;
  opacity: 1 !important;
}

/* TERAPIJE */
::v-deep .odontogram-fissure {
  fill: #a3e635 !important;
  opacity: 1 !important;
}

::v-deep .odontogram-pulpitis {
  fill: #c026d3 !important;
  opacity: 1 !important;
}

::v-deep .odontogram-replacefill {
  fill: #7dd3fc !important;
  opacity: 1 !important;
}

::v-deep .odontogram-crownwork {
  fill: #fde68a !important;
  opacity: 1 !important;
}

::v-deep .odontogram-bridgework {
  fill: #fbbf24 !important;
  opacity: 1 !important;
}

::v-deep .odontogram-prosthetic {
  fill: #60a5fa !important;
  opacity: 1 !important;
}

/* Selektovan deo */
::v-deep .surface-selected {
  opacity: 0.6 !important;
}

::v-deep .odontogram-svg svg {
  width: 100%;
  max-width: 1600px;
  margin: 0 auto;
}

::v-deep .svg-tooltip {
  position: absolute;
  pointer-events: none;
  background: rgba(0, 0, 0, 0.75);
  color: #fff;
  padding: 2px 6px;
  border-radius: 3px;
  font-size: 12px;
  white-space: nowrap;
  z-index: 1000;
  transform: translate(8px, 8px);
  display: none;
}

::v-deep .surface-selected {
  opacity: 0.6 !important;
}

/* your ::v-deep .st0 … ::v-deep .st318 definitions can stay in each SVG */
::v-deep .clickable:hover {
  opacity: 0.2;
  fill: #000000;
}

::v-deep .clickable {
  opacity: 0;
  fill: #000000;
  cursor: pointer;
  position: relative;
}

::v-deep .st0 {
  fill: #F3F4F4;
}

::v-deep .st1 {
  fill: #E9E9E9;
}

::v-deep .st2 {
  fill: #DFDFDF;
}

::v-deep .st3 {
  fill: #D6D6D6;
}

::v-deep .st4 {
  fill: #CCCCCC;
}

::v-deep .st5 {
  fill: #CCC6B9;
}

::v-deep .st6 {
  fill: #DFD9CA;
}

::v-deep .st7 {
  fill: #BCB5AA;
}

::v-deep .st8 {
  fill: #DCD2C3;
}

::v-deep .st9 {
  fill: #D0CABC;
}

::v-deep .st10 {
  fill: #F5EEE2;
}

::v-deep .st11 {
  fill: #D0C8BF;
}

::v-deep .st12 {
  fill: #C2BCB1;
}

::v-deep .st13 {
  fill: #CEC6B9;
}

::v-deep .st14 {
  fill: #C8C3B8;
}

::v-deep .st15 {
  fill: #CCC7BF;
}

::v-deep .st16 {
  fill: #CAC0B4;
}

::v-deep .st17 {
  fill: #C8C2BA;
}

::v-deep .st18 {
  fill: #D1CBC1;
}

::v-deep .st19 {
  fill: #E6E2D6;
}

::v-deep .st20 {
  fill: #EBE2CF;
}

::v-deep .st21 {
  fill: #DED9D1;
}

::v-deep .st22 {
  fill: #E0D8C7;
}

::v-deep .st23 {
  fill: #D3C9BC;
}

::v-deep .st24 {
  fill: #B5ACA1;
}

::v-deep .st25 {
  fill: #BDB5A9;
}

::v-deep .st26 {
  fill: #D7D1CB;
}

::v-deep .st27 {
  fill: #D0CAC5;
}

::v-deep .st28 {
  fill: #CEC6B7;
}

::v-deep .st29 {
  fill: #C2BAAD;
}

::v-deep .st30 {
  fill: #D6CDBD;
}

::v-deep .st31 {
  fill: #CFC9C2;
}

::v-deep .st32 {
  fill: #CDC6BF;
}

::v-deep .st33 {
  fill: #B5ACA2;
}

::v-deep .st34 {
  fill: #C4BEB5;
}

::v-deep .st35 {
  fill: #D8D1C8;
}

::v-deep .st36 {
  fill: #C7BDB0;
}

::v-deep .st37 {
  fill: #DBD2C3;
}

::v-deep .st38 {
  fill: #DFD6C7;
}

::v-deep .st39 {
  fill: #EAE3D2;
}

::v-deep .st40 {
  fill: #C2BAB0;
}

::v-deep .st41 {
  fill: #ABA298;
}

::v-deep .st42 {
  fill: #B4ABA0;
}

::v-deep .st43 {
  fill: #E3DBCC;
}

::v-deep .st44 {
  fill: #F1E9D9;
}

::v-deep .st45 {
  fill: #FAF7F1;
}

::v-deep .st46 {
  fill: #CBC4BB;
}

::v-deep .st47 {
  fill: #FFFFFF;
}

::v-deep .st48 {
  fill: #F5F1EC;
}

::v-deep .st49 {
  fill: #D7D3CC;
}

::v-deep .st50 {
  fill: #D2CDC5;
}

::v-deep .st51 {
  fill: #DBD7D0;
}

::v-deep .st52 {
  fill: #BBB4AC;
}

::v-deep .st53 {
  fill: #EBE8E4;
}

::v-deep .st54 {
  fill: #EAE3D7;
}

::v-deep .st55 {
  fill: #C2B9AC;
}

::v-deep .st56 {
  fill: #C9C0B1;
}

::v-deep .st57 {
  fill: #E4DFDA;
}

::v-deep .st58 {
  fill: #DCD6D0;
}

::v-deep .st59 {
  fill: #F9F7F6;
}

::v-deep .st60 {
  fill: #E6E1DC;
}

::v-deep .st61 {
  fill: #D6D1CC;
}

::v-deep .st62 {
  fill: #C8C0BA;
}

::v-deep .st63 {
  fill: #E5DFD7;
}

::v-deep .st64 {
  fill: #E0DAD0;
}

::v-deep .st65 {
  fill: #BAB1A6;
}

::v-deep .st66 {
  fill: #FAF6F1;
}

::v-deep .st67 {
  fill: #F3F0EB;
}

::v-deep .st68 {
  fill: #EBE8E3;
}

::v-deep .st69 {
  fill: #E0DDD7;
}

::v-deep .st70 {
  fill: #EAE8E2;
}

::v-deep .st71 {
  fill: #F0EEEB;
}

::v-deep .st72 {
  fill: #F2EFEA;
}

::v-deep .st73 {
  fill: #F1EEE9;
}

::v-deep .st74 {
  fill: #E7E2DD;
}

::v-deep .st75 {
  fill: #EDE9E4;
}

::v-deep .st76 {
  fill: #E9E4DF;
}

::v-deep .st77 {
  fill: none;
}

::v-deep .st78 {
  opacity: 0;
  fill: #000000;
  enable-background: new;
}

::v-deep .st79 {
  opacity: 0;
  fill: #000000;
  enable-background: new;
}

::v-deep .st80 {
  fill: #BFB7AC;
}

::v-deep .st81 {
  fill: #CDC7BA;
}

::v-deep .st82 {
  fill: #F3F3F3;
}

::v-deep .st83 {
  fill: #D1C9BC;
}

::v-deep .st84 {
  fill: #CAC5BC;
}

::v-deep .st85 {
  fill: #CEC5BC;
}

::v-deep .st86 {
  fill: #D0CBBD;
}

::v-deep .st87 {
  fill: #DCD4C6;
}

::v-deep .st88 {
  fill: #F2EAD9;
}

::v-deep .st89 {
  fill: #D2CCC2;
}

::v-deep .st90 {
  fill: #D7D0C2;
}

::v-deep .st91 {
  fill: #DED6CD;
}

::v-deep .st92 {
  fill: #C9BEB2;
}

::v-deep .st93 {
  fill: #C8C2B8;
}

::v-deep .st94 {
  fill: #D4CFC1;
}

::v-deep .st95 {
  fill: #CFC6C0;
}

::v-deep .st96 {
  fill: #C2BAB3;
}

::v-deep .st97 {
  fill: #D7D0CB;
}

::v-deep .st98 {
  fill: #CFCAC3;
}

::v-deep .st99 {
  fill: #CCC3B7;
}

::v-deep .st100 {
  fill: #B5ADA3;
}

::v-deep .st101 {
  fill: #C8C1BB;
}

::v-deep .st102 {
  fill: #D7CFC6;
}

::v-deep .st103 {
  fill: #E5E1D5;
}

::v-deep .st104 {
  fill: #DCD3C4;
}

::v-deep .st105 {
  fill: #ECE4D4;
}

::v-deep .st106 {
  fill: #E7DECF;
}

::v-deep .st107 {
  fill: #BAB3AC;
}

::v-deep .st108 {
  fill: #DBD7CE;
}

::v-deep .st109 {
  fill: #F7F2ED;
}

::v-deep .st110 {
  fill: #F2E9D9;
}

::v-deep .st111 {
  fill: #F4EEE1;
}

::v-deep .st112 {
  fill: #D5D1CA;
}

::v-deep .st113 {
  fill: #FBFAF9;
}

::v-deep .st114 {
  fill: #DCD7D0;
}

::v-deep .st115 {
  fill: #CCC5C0;
}

::v-deep .st116 {
  fill: #DED6CB;
}

::v-deep .st117 {
  fill: #F4EDE0;
}

::v-deep .st118 {
  fill: #DFE0DF;
}

::v-deep .st119 {
  fill: #E5E1DC;
}

::v-deep .st120 {
  fill: #E1DFD7;
}

::v-deep .st121 {
  fill: #D7D2CD;
}

::v-deep .st122 {
  fill: #F4F0EC;
}

::v-deep .st123 {
  fill: #EEEAE5;
}

::v-deep .st124 {
  fill: #EEECE9;
}

::v-deep .st125 {
  fill: #E1DDD7;
}

::v-deep .st126 {
  fill: #DCD8D2;
}

::v-deep .st127 {
  fill: #E4DED7;
}

::v-deep .st128 {
  fill: #D7D7D6;
}

::v-deep .st129 {
  fill: #F4F4F4;
}

::v-deep .st130 {
  fill: #EAE9E9;
}

::v-deep .st131 {
  fill: #ECE4DC;
}

::v-deep .st132 {
  fill: #B9B2A8;
}

::v-deep .st133 {
  fill: #C0B8AC;
}

::v-deep .st134 {
  fill: #DCD5CB;
}

::v-deep .st135 {
  fill: #D1C6B8;
}

::v-deep .st136 {
  fill: #C3BAAE;
}

::v-deep .st137 {
  fill: #CCC1B4;
}

::v-deep .st138 {
  fill: #BDB7AC;
}

::v-deep .st139 {
  fill: #CAC0B3;
}

::v-deep .st140 {
  fill: #C5BCAF;
}

::v-deep .st141 {
  fill: #C2BBB0;
}

::v-deep .st142 {
  fill: #CAC3BB;
}

::v-deep .st143 {
  fill: #C5BEB6;
}

::v-deep .st144 {
  fill: #C3BCB2;
}

::v-deep .st145 {
  fill: #DBD2CB;
}

::v-deep .st146 {
  fill: #D3C9C1;
}

::v-deep .st147 {
  fill: #E2DAD5;
}

::v-deep .st148 {
  fill: #F2EBE6;
}

::v-deep .st149 {
  fill: #D1CAC5;
}

::v-deep .st150 {
  fill: #F2EADF;
}

::v-deep .st151 {
  fill: #E7E2DB;
}

::v-deep .st152 {
  fill: #BDB4AD;
}

::v-deep .st153 {
  fill: #E3DED6;
}

::v-deep .st154 {
  fill: #D3CEC7;
}

::v-deep .st155 {
  fill: #C3BAB4;
}

::v-deep .st156 {
  fill: #FCFAF8;
}

::v-deep .st157 {
  fill: #F7F1E7;
}

::v-deep .st158 {
  fill: #F6F2EC;
}

::v-deep .st159 {
  fill: #F8F4F0;
}

::v-deep .st160 {
  fill: #FCF9F3;
}

::v-deep .st161 {
  fill: #E9E3D3;
}

::v-deep .st162 {
  fill: #F0EDE8;
}

::v-deep .st163 {
  fill: #E0E0E0;
}

::v-deep .st164 {
  fill: #BBB4A9;
}

::v-deep .st165 {
  fill: #EBE4DD;
}

::v-deep .st166 {
  fill: #CCC2B4;
}

::v-deep .st167 {
  fill: #C3BAAF;
}

::v-deep .st168 {
  fill: #E6E1DA;
}

::v-deep .st169 {
  fill: #B6AFA5;
}

::v-deep .st170 {
  fill: #C9C2B9;
}

::v-deep .st171 {
  fill: #C3BBB1;
}

::v-deep .st172 {
  fill: #C3BDB3;
}

::v-deep .st173 {
  fill: #CBC1B4;
}

::v-deep .st174 {
  fill: #D1C6BF;
}

::v-deep .st175 {
  fill: #D5CBC4;
}

::v-deep .st176 {
  fill: #D6CFC9;
}

::v-deep .st177 {
  fill: #D2C8BA;
}

::v-deep .st178 {
  fill: #DED7D1;
}

::v-deep .st179 {
  fill: #DFD9D1;
}

::v-deep .st180 {
  fill: #D6CFC6;
}

::v-deep .st181 {
  fill: #D7D0C3;
}

::v-deep .st182 {
  fill: #CCC6BD;
}

::v-deep .st183 {
  fill: #E5DDCF;
}

::v-deep .st184 {
  fill: #F5F1EE;
}

::v-deep .st185 {
  fill: #E0D9CA;
}

::v-deep .st186 {
  fill: #F7F3EE;
}

::v-deep .st187 {
  fill: #C9C0B8;
}

::v-deep .st188 {
  fill: #E1DBD1;
}

::v-deep .st189 {
  fill: #F9F3EA;
}

::v-deep .st190 {
  fill: #F6F2ED;
}

::v-deep .st191 {
  fill: #E8E3D9;
}

::v-deep .st192 {
  fill: #D7D6D6;
}

::v-deep .st193 {
  fill: #C6BEB2;
}

::v-deep .st194 {
  fill: #C4BBB0;
}

::v-deep .st195 {
  fill: #BCB5AB;
}

::v-deep .st196 {
  fill: #CBC5BA;
}

::v-deep .st197 {
  fill: #D8D3CA;
}

::v-deep .st198 {
  fill: #D0C9BF;
}

::v-deep .st199 {
  fill: #CFC5B8;
}

::v-deep .st200 {
  fill: #C7BFB7;
}

::v-deep .st201 {
  fill: #CFCABF;
}

::v-deep .st202 {
  fill: #ECE3DB;
}

::v-deep .st203 {
  fill: #E2DAD2;
}

::v-deep .st204 {
  fill: #DAD5CB;
}

::v-deep .st205 {
  fill: #ECE7E1;
}

::v-deep .st206 {
  fill: #E0D9CB;
}

::v-deep .st207 {
  fill: #F9F6F1;
}

::v-deep .st208 {
  fill: #F7F1E5;
}

::v-deep .st209 {
  fill: #F6F1EA;
}

::v-deep .st210 {
  fill: #E2DED5;
}

::v-deep .st211 {
  fill: #E4DED2;
}

::v-deep .st212 {
  fill: #EFE9DE;
}

::v-deep .st213 {
  fill: #C9C5B8;
}

::v-deep .st214 {
  fill: #BBB5AA;
}

::v-deep .st215 {
  fill: #CBC0B5;
}

::v-deep .st216 {
  fill: #C4BFB3;
}

::v-deep .st217 {
  fill: #B9B0A6;
}

::v-deep .st218 {
  fill: #C5BAAF;
}

::v-deep .st219 {
  fill: #BEB6AC;
}

::v-deep .st220 {
  fill: #C6BEB3;
}

::v-deep .st221 {
  fill: #D0C9BC;
}

::v-deep .st222 {
  fill: #E7DFD0;
}

::v-deep .st223 {
  fill: #DAD4CB;
}

::v-deep .st224 {
  fill: #E1DCD4;
}

::v-deep .st225 {
  fill: #E9E9E8;
}

::v-deep .st226 {
  fill: #CFC7BD;
}

::v-deep .st227 {
  fill: #DBD4CC;
}

::v-deep .st228 {
  fill: #DFDAD3;
}

::v-deep .st229 {
  fill: #DDD3CC;
}

::v-deep .st230 {
  fill: #DFD6C8;
}

::v-deep .st231 {
  fill: #EAE7E1;
}

::v-deep .st232 {
  fill: #E8DFD9;
}

::v-deep .st233 {
  fill: #E2DAD3;
}

::v-deep .st234 {
  fill: #F2EEEA;
}

::v-deep .st235 {
  fill: #E5E0DB;
}

::v-deep .st236 {
  fill: #E9E5DF;
}

::v-deep .st237 {
  fill: #F7F3F0;
}

::v-deep .st238 {
  fill: #EFE9E5;
}

::v-deep .st239 {
  fill: #EDE9E6;
}

::v-deep .st240 {
  fill: #ED2024;
}

::v-deep .st241 {
  fill: #C8C4B7;
}

::v-deep .st242 {
  fill: #E8E4DE;
}

::v-deep .st243 {
  fill: #B3A9A0;
}

::v-deep .st244 {
  fill: #D7D1C3;
}

::v-deep .st245 {
  fill: #CCC1B6;
}

::v-deep .st246 {
  fill: #C4BEB2;
}

::v-deep .st247 {
  fill: #D1CAC1;
}

::v-deep .st248 {
  fill: #C2B6AB;
}

::v-deep .st249 {
  fill: #BAAFA6;
}

::v-deep .st250 {
  fill: #BEB7AC;
}

::v-deep .st251 {
  fill: #B7B0A5;
}

::v-deep .st252 {
  fill: #CAC4B8;
}

::v-deep .st253 {
  fill: #C9BFB5;
}

::v-deep .st254 {
  fill: #D0C8BE;
}

::v-deep .st255 {
  fill: #DAD3C4;
}

::v-deep .st256 {
  fill: #CFC9BB;
}

::v-deep .st257 {
  fill: #DACEC7;
}

::v-deep .st258 {
  fill: #DFD9D2;
}

::v-deep .st259 {
  fill: #E8E2D1;
}

::v-deep .st260 {
  fill: #E2DDD5;
}

::v-deep .st261 {
  fill: #E3DDD1;
}

::v-deep .st262 {
  fill: #E9E0DA;
}

::v-deep .st263 {
  fill: #F0EAE6;
}

::v-deep .st264 {
  fill: #F3EEEA;
}

::v-deep .st265 {
  fill: #F6EFE3;
}

::v-deep .st266 {
  fill: #D6D6D5;
}

::v-deep .st267 {
  fill: #CCCDCC;
}

::v-deep .st268 {
  opacity: 0.8;
  fill: #ED2024;
  enable-background: new;
}

::v-deep .st269 {
  fill: #E0E0DF;
}

::v-deep .st270 {
  fill: #CDCDCC;
}

::v-deep .st271 {
  fill: #C8BFB2;
}

::v-deep .st272 {
  fill: #C5BAAD;
}

::v-deep .st273 {
  fill: #C9C1B5;
}

::v-deep .st274 {
  fill: #C3BAB0;
}

::v-deep .st275 {
  fill: #B0A79D;
}

::v-deep .st276 {
  fill: #CEC9BF;
}

::v-deep .st277 {
  fill: #C1BAB1;
}

::v-deep .st278 {
  fill: #C9C3B9;
}

::v-deep .st279 {
  fill: #BAB3AB;
}

::v-deep .st280 {
  fill: #DAD2C4;
}

::v-deep .st281 {
  fill: #E9E8E8;
}

::v-deep .st282 {
  fill: #DAD2C9;
}

::v-deep .st283 {
  fill: #E9E3DE;
}

::v-deep .st284 {
  fill: #DAD3CA;
}

::v-deep .st285 {
  fill: #DCD4CC;
}

::v-deep .st286 {
  fill: #E7E0D0;
}

::v-deep .st287 {
  fill: #E3DDD0;
}

::v-deep .st288 {
  fill: #E1DDD4;
}

::v-deep .st289 {
  fill: #E5DFD9;
}

::v-deep .st290 {
  fill: #E1DAD3;
}

::v-deep .st291 {
  fill: #E0DAD2;
}

::v-deep .st292 {
  fill: #E8DFDA;
}

::v-deep .st293 {
  fill: #F8F3EA;
}

::v-deep .st294 {
  fill: #F2ECE3;
}

::v-deep .st295 {
  fill: #EAE7E2;
}

::v-deep .st296 {
  fill: #F0EBE6;
}

::v-deep .st297 {
  fill: #C4BBB1;
}

::v-deep .st298 {
  fill: #CBC2B8;
}

::v-deep .st299 {
  fill: #C1B9AE;
}

::v-deep .st300 {
  fill: #C8C0B4;
}

::v-deep .st301 {
  fill: #CFC9BF;
}

::v-deep .st302 {
  fill: #BFB6AB;
}

::v-deep .st303 {
  fill: #DDD4C6;
}

::v-deep .st304 {
  fill: #CFC9BC;
}

::v-deep .st305 {
  fill: #CEC2B5;
}

::v-deep .st306 {
  fill: #DAD1C9;
}

::v-deep .st307 {
  fill: #EAE3D3;
}

::v-deep .st308 {
  fill: #F0E9E5;
}

::v-deep .st309 {
  fill: #E8E3DD;
}

::v-deep .st310 {
  fill: #EBE7E2;
}

::v-deep .st311 {
  fill: #E6E0D9;
}

::v-deep .st312 {
  fill: #F3EEEB;
}

::v-deep .st313 {
  fill: #F2ECE4;
}

::v-deep .st314 {
  fill: #FBF7F1;
}

::v-deep .st315 {
  fill: #F6F0E3;
}

::v-deep .st316 {
  fill: #E0DCD4;
}

::v-deep .st317 {
  fill: #E2DDD0;
}

::v-deep .st318 {
  fill: #EFECE8;
}
</style>
