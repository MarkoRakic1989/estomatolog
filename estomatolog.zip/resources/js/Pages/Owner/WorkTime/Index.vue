<template>
  <OwnerLayout>
    <template #header>
      <h2 class="text-2xl font-semibold">Radno vreme – kalendar</h2>
    </template>

    <div class="container mx-auto px-4 pt-20">
      <!-- Navigacija između nedelja -->
      <div class="flex justify-between items-center mb-4">
        <button @click="prevWeek" class="btn btn-sm btn-outline">← Prethodna</button>
        <h2 class="text-lg font-semibold">
          Nedelja: {{ formatDate(weekStart) }} – {{ formatDate(weekEnd) }}
        </h2>
        <button @click="nextWeek" class="btn btn-sm btn-outline">Sledeća →</button>
      </div>

      <!-- Tabela radnog vremena -->
      <div class="overflow-x-auto card bg-base-100 shadow rounded-lg">
        <table class="table table-zebra w-full">
          <thead>
            <tr>
              <th>Zaposleni</th>
              <th v-for="day in weekDays" :key="day" class="text-center">
                {{ formatDay(day) }}<br />{{ formatDateShort(day) }}
              </th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="emp in employees" :key="emp.id">
              <td class="font-medium">{{ emp.name }}</td>

              <td v-for="day in weekDays" :key="day" class="text-center" @dragover.prevent
                @drop="e => onDrop(e, emp.id, day)">
                <!-- Postojeće radno vreme -->
                <div v-if="hasWorkTime(emp.id, day)" class="space-y-1">
                  <div :draggable="canModify(emp.id, day)" @dragstart="e => onDragStart(e, emp.id, day)"
                    class="badge badge-primary cursor-move">
                    {{ formatTime(getWorkTime(emp.id, day).start_time) }} –
                    {{ formatTime(getWorkTime(emp.id, day).end_time) }}
                  </div>
                  <div class="flex justify-center space-x-1">
                    <button v-if="canModify(emp.id, day)"
                      @click.stop="openModal(emp, day, getWorkTime(emp.id, day).start_time, getWorkTime(emp.id, day).end_time, getWorkTime(emp.id, day).id)"
                      class="btn btn-xs btn-ghost" title="Izmeni">
                      ✏️
                    </button>
                    <button v-if="canModify(emp.id, day)" @click.stop="deleteWorkTime(getWorkTime(emp.id, day).id)"
                      class="btn btn-xs btn-error" title="Obriši">
                      🗑️
                    </button>
                  </div>
                </div>

                <!-- Nema radnog vremena -->
                <div v-else class="space-y-1">
                  <button @click="canModify(emp.id, day) && openModal(emp, day)" :disabled="!canModify(emp.id, day)"
                    class="btn btn-xs btn-outline disabled:opacity-50">
                    unesi
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Modal za radno vreme -->
      <WorkTimeModal v-if="modalOpen" :key="modalEmployee.id + '-' + modalPayload.date + '-' + modalPayload.id"
        :salon-id="props.salonId" :employee="modalEmployee" :worktimes="props.worktimes" :initial-date="modalPayload"
        @close="closeModal" @saved="reloadWeek" />
    </div>
  </OwnerLayout>
</template>

<script setup>
import { ref, computed } from 'vue'
import { router } from '@inertiajs/vue3'
import dayjs from 'dayjs'
import isoWeek from 'dayjs/plugin/isoWeek'
import WorkTimeModal from '@/Pages/Owner/WorkTime/WorkTimeModal.vue'
import OwnerLayout from '@/Layouts/OwnerLayout.vue'

dayjs.extend(isoWeek)

const props = defineProps({
  salonId: Number,
  employees: Array,
  worktimes: Array,
  week_start: String
})
const today = dayjs()
const currentWeekStart = ref(dayjs(props.week_start).startOf('isoWeek'))

const weekStart = computed(() => currentWeekStart.value)
const weekEnd = computed(() => currentWeekStart.value.add(6, 'day'))
const weekDays = computed(() =>
  Array.from({ length: 7 }, (_, i) => currentWeekStart.value.add(i, 'day'))
)

function isPast(day) {
  return day.startOf('day').isBefore(today.startOf('day'))
}

function isStarted(empId, day) {
  const wt = props.worktimes.find(
    w => w.employee_id === empId && w.date === day.format('YYYY-MM-DD')
  )
  if (!wt) return false
  const start = dayjs(`${wt.date} ${wt.start_time}`)
  return today.isAfter(start) || today.isSame(start)
}

function canModify(empId, day) {
  return !isPast(day) && !isStarted(empId, day)
}

function onDragStart(event, empId, day) {
  if (!canModify(empId, day)) return
  const wt = props.worktimes.find(
    w => w.employee_id === empId && w.date === day.format('YYYY-MM-DD')
  )
  if (!wt) return
  event.dataTransfer.setData('firstWorktimeId', wt.id)
}

async function onDrop(event, empId, day) {
  if (!canModify(empId, day)) return
  const firstId = event.dataTransfer.getData('firstWorktimeId')
  if (!firstId) return

  const targetDate = day.format('YYYY-MM-DD')
  const srcWT = props.worktimes.find(w => w.id === Number(firstId))
  const dstWT = props.worktimes.find(
    w => w.employee_id === empId && w.date === targetDate
  )

  if (dstWT) {
    await router.post(
      route('owner.worktimes.swap'),
      { first_id: srcWT.id, second_id: dstWT.id },
      { preserveState: true, onSuccess: reloadWeek }
    )
  } else {
    await router.post(
      route('owner.worktimes.copy', { salon: props.salonId, worktime: srcWT.id }),
      { target_date: targetDate, employee_id: empId },
      { preserveState: true, onSuccess: reloadWeek }
    )
  }
}

function hasWorkTime(empId, day) {
  return props.worktimes.some(
    w => w.employee_id === empId && w.date === day.format('YYYY-MM-DD')
  )
}

function getWorkTime(empId, day) {
  return (
    props.worktimes.find(
      w => w.employee_id === empId && w.date === day.format('YYYY-MM-DD')
    ) || {}
  )
}

const formatDay = d => d.format('dd')
const formatDateShort = d => d.format('DD.MM.')
const formatDate = d => d.format('DD.MM.YYYY')
const formatTime = t => t?.slice(0, 5) || ''

const modalOpen = ref(false)
const modalPayload = ref({})
const modalEmployee = ref({})

function openModal(emp, day, start_time = '', end_time = '', id = null) {
  modalEmployee.value = emp
  modalPayload.value = {
    id,
    employee_id: emp.id,
    date: day.format('YYYY-MM-DD'),
    start_time: start_time ? start_time.slice(0, 5) : '',
    end_time: end_time ? end_time.slice(0, 5) : ''
  }
  modalOpen.value = true
}

function closeModal() {
  modalOpen.value = false
  modalPayload.value = {}
  modalEmployee.value = {}
}

async function deleteWorkTime(worktimeId) {
  if (!confirm('Da li ste sigurni da želite obrisati radno vreme?')) return
  await router.delete(
    route('owner.worktimes.destroy', { salon: props.salonId, worktime: worktimeId }),
    {},
    { preserveState: true, onSuccess: reloadWeek }
  )
}

function reloadWeek() {
  router.get(
    route('owner.worktimes.index'),
    { salon: props.salonId, week_start: weekStart.value.format('YYYY-MM-DD') },
    { preserveState: true }
  )
}

function prevWeek() {
  currentWeekStart.value = currentWeekStart.value.subtract(1, 'week')
  reloadWeek()
}

function nextWeek() {
  currentWeekStart.value = currentWeekStart.value.add(1, 'week')
  reloadWeek()
}
</script>

<style scoped>
/* Add or override DaisyUI utility classes here if needed */
</style>
