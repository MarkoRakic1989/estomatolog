<template>
  <div class="modal modal-open" @click.self="$emit('close')">
    <div class="modal-box relative max-w-md">
      <!-- Close Button -->
      <button @click="$emit('close')" class="btn btn-sm btn-circle absolute right-2 top-2">✕</button>
      <!-- Title -->
      <h3 class="font-bold text-lg mb-4">
        {{ employee.name }} — {{ dayjs(payloadDate).format('DD.MM.YYYY') }}
      </h3>
      <!-- Form -->
      <form @submit.prevent="handleSave" class="space-y-4">
        <!-- Start Time -->
        <div class="form-control">
          <label class="label"><span class="label-text">Početak:</span></label>
          <select v-model="form.start_time" class="select select-bordered w-full">
            <option value="">-- izaberi --</option>
            <option v-for="t in times" :key="t" :value="t">{{ t }}</option>
          </select>
          <label v-if="form.errors.start_time" class="label">
            <span class="label-text-alt text-error">{{ form.errors.start_time }}</span>
          </label>
        </div>
        <!-- End Time -->
        <div class="form-control">
          <label class="label"><span class="label-text">Kraj:</span></label>
          <select v-model="form.end_time" class="select select-bordered w-full">
            <option value="">-- izaberi --</option>
            <option v-for="t in times" :key="t" :value="t">{{ t }}</option>
          </select>
          <label v-if="form.errors.end_time" class="label">
            <span class="label-text-alt text-error">{{ form.errors.end_time }}</span>
          </label>
        </div>
        <!-- Copy Dates -->
        <div class="form-control">
          <p class="font-medium mb-2">Kopiraj termin na narednih 30 dana:</p>
          <div class="flex flex-wrap gap-2 max-h-40 overflow-auto">
            <label v-for="d in nextDays" :key="d" class="inline-flex items-center">
              <input type="checkbox" v-model="selectedDates" :value="d"
                :disabled="dayjs(d).isBefore(dayjs(payloadDate), 'day')" class="checkbox
         focus:outline-none focus:ring-0
         hover:bg-transparent" />
              <span class="ml-1">{{ dayjs(d).format('DD.MM.') }}</span>
            </label>
          </div>
        </div>
        <!-- Actions -->
        <div class="modal-action justify-end">
          <button type="submit" :disabled="form.processing" class="btn btn-primary">
            {{ form.id ? 'Ažuriraj' : 'Sačuvaj' }}
          </button>
          <button v-if="form.id" type="button" @click="handleDelete" :disabled="form.processing" class="btn btn-error">
            Obriši
          </button>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { useForm, router } from '@inertiajs/vue3'
import dayjs from 'dayjs'
import isoWeek from 'dayjs/plugin/isoWeek'

dayjs.extend(isoWeek)

const props = defineProps({
  salonId: Number,
  employee: Object,
  worktimes: Array,
  initialDate: Object
})
const emit = defineEmits(['close', 'saved'])

const payloadDate = props.initialDate.date

const form = useForm({
  id: props.initialDate.id || null,
  employee_id: props.initialDate.employee_id,
  date: props.initialDate.date,
  start_time: props.initialDate.start_time || '',
  end_time: props.initialDate.end_time || ''
})

watch(() => props.initialDate, (val) => {
  form.reset({
    id: val.id || null,
    employee_id: val.employee_id,
    date: val.date,
    start_time: val.start_time || '',
    end_time: val.end_time || ''
  })
})

// Time slots
const times = []
for (let h = 8; h <= 23; h++) {
  const hh = String(h).padStart(2, '0')
  times.push(`${hh}:00`)
  if (h < 23) times.push(`${hh}:30`)
}

// Next 30 days
const nextDays = computed(() => {
  const base = dayjs(payloadDate)
  const days = []
  for (let i = 1; i <= 30; i++) {
    const d = base.add(i, 'day').format('YYYY-MM-DD')
    if (!props.worktimes.some(w => w.employee_id === props.employee.id && w.date === d)) {
      days.push(d)
    }
  }
  return days
})
const selectedDates = ref([])

async function handleSave() {
  const isUpdate = !!form.id
  const routeName = isUpdate ? 'owner.worktimes.update' : 'owner.worktimes.store'
  const params = isUpdate
    ? { salon: props.salonId, worktime: form.id }
    : { salon: props.salonId }
  const opts = {
    onSuccess: async () => {
      if (selectedDates.value.length) {
        await Promise.all(
          selectedDates.value.map(d =>
            router.post(
              route('owner.worktimes.copy', { salon: props.salonId, worktime: form.id }),
              { target_date: d, employee_id: form.employee_id }
            )
          )
        )
      }
      emit('saved')
      emit('close')
    }
  }

  if (isUpdate) await form.put(route(routeName, params), opts)
  else await form.post(route(routeName, params), { data: form, ...opts })
}

async function handleDelete() {
  if (!confirm('Obrisati smenu?')) return
  await form.delete(
    route('owner.worktimes.destroy', { salon: props.salonId, worktime: form.id }),
    { onSuccess: () => { emit('saved'); emit('close') } }
  )
}
</script>

<style scoped>
.checkbox:hover,
.checkbox:focus {
  background-color: transparent !important;
  box-shadow: none !important;
  outline: none !important;
}
</style>