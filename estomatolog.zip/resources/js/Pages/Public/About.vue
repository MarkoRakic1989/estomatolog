<template>
  <Layout
    :salonSlug="salonSlug"
    :salon="salon"
    :currentRoute="currentRoute"
  >
    <section class="py-16" style="background-color: #ffffff;">
      <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <h3 class="text-3xl font-bold" :style="{ color: salon.secondary_color }">
          About {{ salon.name }}
        </h3>
        <div class="mt-6 prose prose-lg text-gray-700" v-html="aboutHtml"></div>
      </div>
    </section>
  </Layout>
</template>

<script setup>
import { Link } from '@inertiajs/vue3'
import Layout from '@/Pages/Public/Layout.vue'

const props = defineProps({
  salonSlug:    String,
  salon:        Object,
  currentRoute: String,
})

// Koristimo salon.description kao HTML za “about”
const aboutHtml = props.salon.description || '<p>No description available.</p>'
</script>

<style scoped>
/* Dodatni stilovi za About sekciju ako treba */
</style>
