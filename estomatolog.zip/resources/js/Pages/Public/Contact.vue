<template>
  <Layout :salonSlug="salonSlug" :salon="salon" :currentRoute="currentRoute">
    <!-- Page Header -->
    <section class="hero min-h-[25vh] bg-base-200">
      <div class="hero-content text-center">
        <div class="max-w-lg">
          <h1 class="text-5xl font-bold" :style="{ color: salon.primary_color }">
            Kontaktirajte nas
          </h1>
          <p class="py-4 text-lg">
            Javite nam se za informacije, pitanja ili zakazivanje termina!
          </p>
        </div>
      </div>
    </section>

    <!-- Contact Info Cards -->
    <section class="py-12 bg-base-100">
      <div class="max-w-6xl mx-auto px-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <!-- Address -->
        <div class="card bg-base-200 shadow-lg p-6 text-center">
          <svg xmlns="http://www.w3.org/2000/svg" class="mx-auto h-10 w-10 text-secondary" fill="none"
            stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round"
              d="M17.657 16.657L13.414 12.414m4.243 4.243A8 8 0 118.343 7.343a8 8 0 0111.314 11.314z" />
            <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
          <h4 class="text-xl font-semibold mt-4">Adresa</h4>
          <p class="mt-2 text-sm text-gray-600">Ulica Primer 123, Beograd, Srbija</p>
        </div>

        <!-- Hours -->
        <div class="card bg-base-200 shadow-lg p-6 text-center">
          <svg xmlns="http://www.w3.org/2000/svg" class="mx-auto h-10 w-10 text-accent" fill="none"
            stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="10" stroke-linecap="round" stroke-linejoin="round" />
            <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6l4 2" />
          </svg>
          <h4 class="text-xl font-semibold mt-4">Radno vreme</h4>
          <p class="mt-2 text-sm">Pon–Pet: 09:00 – 20:00</p>
          <p class="text-sm">Sub: 10:00 – 18:00</p>
          <p class="text-sm">Ned: Zatvoreno</p>
        </div>

        <!-- Phone -->
        <div class="card bg-base-200 shadow-lg p-6 text-center">
          <svg xmlns="http://www.w3.org/2000/svg" class="mx-auto h-10 w-10 text-primary" fill="none"
            stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round"
              d="M3 5a2 2 0 012-2h3.6a1 1 0 01.9.5l2 3.5a1 1 0 01-.1 1L8 11a11 11 0 005.5 5.5l2-2a1 1 0 011-.1l3.5 2a1 1 0 01.5.9V19a2 2 0 01-2 2h-1C9.163 21 3 14.837 3 7V5z" />
          </svg>
          <h4 class="text-xl font-semibold mt-4">Telefon</h4>
          <p class="mt-2 text-sm">+381 11 123 4567</p>
        </div>

        <!-- Email -->
        <div class="card bg-base-200 shadow-lg p-6 text-center">
          <svg xmlns="http://www.w3.org/2000/svg" class="mx-auto h-10 w-10 text-secondary" fill="none"
            stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round"
              d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8m0 8V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8" />
          </svg>
          <h4 class="text-xl font-semibold mt-4">Email</h4>
          <p class="mt-2 text-sm">info@mysalon.com</p>
        </div>
      </div>
    </section>

    <!-- Map & Contact Form -->
    <section class="py-16 bg-base-100">
      <div class="max-w-6xl mx-auto px-4 grid grid-cols-1 lg:grid-cols-2 gap-12">
        <!-- Styled Map Card -->
        <div class="card bg-base-200 shadow-lg overflow-hidden">
          <div class="relative w-full" style="padding-top: 56.25%;">
            <iframe class="absolute inset-0 w-full h-full"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2830.123456789012!2d20.123456!3d44.123456!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x475a...!2sBeograd!5e0!3m2!1sen!2srs!4v1610000000000!5m2!1sen!2srs"
              frameborder="0" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
          </div>
          <div class="card-body text-center">
            <Link href="https://www.google.com/maps/place/Beograd" target="_blank"
              class="btn btn-outline btn-sm mx-auto">
            Otvori veliku mapu
            </Link>
          </div>
        </div>

        <!-- Contact Form -->
        <div>
          <form @submit.prevent="submitForm" class="space-y-6 bg-base-200 p-8 rounded-lg shadow-lg">
            <div>
              <label for="name" class="label">
                <span class="label-text">Ime</span>
              </label>
              <input v-model="form.name" id="name" name="name" type="text" placeholder="Vaše ime" required
                class="input input-bordered w-full focus:outline-none focus:border-secondary" />
              <p v-if="form.errors.name" class="text-red-600 text-sm mt-1">{{ form.errors.name }}</p>
            </div>

            <div>
              <label for="email" class="label">
                <span class="label-text">Email</span>
              </label>
              <input v-model="form.email" id="email" name="email" type="email" placeholder="Vaš email" required
                class="input input-bordered w-full focus:outline-none focus:border-secondary" />
              <p v-if="form.errors.email" class="text-red-600 text-sm mt-1">{{ form.errors.email }}</p>
            </div>

            <div>
              <label for="message" class="label">
                <span class="label-text">Poruka</span>
              </label>
              <textarea v-model="form.message" id="message" name="message" rows="4" placeholder="Vaša poruka" required
                class="textarea textarea-bordered w-full focus:outline-none focus:border-secondary"></textarea>
              <p v-if="form.errors.message" class="text-red-600 text-sm mt-1">{{ form.errors.message }}</p>
            </div>

            <button type="submit" class="btn w-full"
              :style="{ backgroundColor: salon.secondary_color, color: salon.primary_color }"
              :disabled="form.processing">
              <span v-if="!form.processing">Pošalji poruku</span>
              <span v-else>Šalje se...</span>
            </button>

            <p v-if="statusMessage" class="text-center mt-4" :class="statusClass">{{ statusMessage }}</p>
          </form>
        </div>
      </div>
    </section>
  </Layout>
</template>

<script setup>
import { ref } from 'vue'
import { useForm } from '@inertiajs/vue3'
import Layout from '@/Pages/Public/Layout.vue'

const props = defineProps({
  salonSlug: String,
  salon: Object,
  currentRoute: String,
})

const form = useForm({
  name: '',
  email: '',
  message: '',
})

const statusMessage = ref('')
const statusClass = ref('')

function submitForm() {
  statusMessage.value = ''
  form.post(route('api.contact.send', { salonSlug }), {
    onSuccess: () => {
      statusMessage.value = 'Poruka je uspešno poslata!'
      statusClass.value = 'text-green-600'
      form.reset('name', 'email', 'message')
    },
    onError: () => {
      statusMessage.value = 'Molimo ispravite greške iznad.'
      statusClass.value = 'text-red-600'
    },
  })
}
</script>

<style scoped>
.hero {
  background: linear-gradient(to right, var(--pf-primary), var(--pf-secondary));
}
</style>
