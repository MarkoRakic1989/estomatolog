<template>
  <Layout :salonSlug="salonSlug" :salon="salon" :currentRoute="currentRoute">
    <!-- Hero секција -->
    <section class="relative flex justify-center">
      <!-- Hero Content -->
      <div class="container text-center px-6 pt-0 md:py-20">
        <h1 class="text-5xl md:text-[72px] font-extrabold mb-4 text-base-content">
          For love and care that<br> comes from the heart
        </h1>
        <p class="text-base-content/70 mb-6 max-w-3xl mx-auto">
          We provide gentle, attentive care for every pet.
          From bathing to grooming, everything is done with patience and love.
        </p>
        <div class="space-x-4 mb-16">
          <Link :href="route('booking.step1', { salonSlug })"
            class="btn btn-primary text-primary-content btn-lg hover:bg-secondary hover:text-secondary-content">
          Rezerviši odmah
          </Link>
        </div>

        <!-- Four Image Squares -->
        <div class="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-6 ">
          <div class="rotate-[2deg] shadow-lg aspect-square">
            <img
              src="https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-300.jpg"
              srcset="https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-300.jpg?w=360 360w, https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-300.jpg?w=740 740w, https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-300.jpg?w=826 826w, https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-300.jpg?w=900 900w, https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-300.jpg?w=996 996w, https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-300.jpg?w=1060 1060w, https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-300.jpg?w=1380 1380w, https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-300.jpg?w=1480 1480w, https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-300.jpg?w=1800 1800w, https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-300.jpg?w=2000 2000w"
              width="626" height="626" alt="young happy man and woman in a dental examination at dentist"
              fetchpriority="high"
              sizes="(max-width: 480px) 100vw, (min-aspect-ratio: 626/626) 100%, (max-width: 1096px) calc(100vw - 40px), calc(100vw - 540px)"
              class="size-full object-contain">
          </div>
          <div class="rotate-[-2deg] shadow-lg aspect-square">
            <img
              src="https://img.freepik.com/premium-photo/dental-care-medical-treatment-images-dentist-teeth_1260831-217.jpg"
              srcset="https://img.freepik.com/premium-photo/dental-care-medical-treatment-images-dentist-teeth_1260831-217.jpg?w=360 360w, https://img.freepik.com/premium-photo/dental-care-medical-treatment-images-dentist-teeth_1260831-217.jpg?w=740 740w, https://img.freepik.com/premium-photo/dental-care-medical-treatment-images-dentist-teeth_1260831-217.jpg?w=826 826w, https://img.freepik.com/premium-photo/dental-care-medical-treatment-images-dentist-teeth_1260831-217.jpg?w=900 900w, https://img.freepik.com/premium-photo/dental-care-medical-treatment-images-dentist-teeth_1260831-217.jpg?w=996 996w, https://img.freepik.com/premium-photo/dental-care-medical-treatment-images-dentist-teeth_1260831-217.jpg?w=1060 1060w, https://img.freepik.com/premium-photo/dental-care-medical-treatment-images-dentist-teeth_1260831-217.jpg?w=1380 1380w, https://img.freepik.com/premium-photo/dental-care-medical-treatment-images-dentist-teeth_1260831-217.jpg?w=1480 1480w, https://img.freepik.com/premium-photo/dental-care-medical-treatment-images-dentist-teeth_1260831-217.jpg?w=1800 1800w, https://img.freepik.com/premium-photo/dental-care-medical-treatment-images-dentist-teeth_1260831-217.jpg?w=2000 2000w"
              width="626" height="626" alt="dental care medical treatment images dentist teeth" fetchpriority="high"
              sizes="(max-width: 480px) 100vw, (min-aspect-ratio: 626/626) 100%, (max-width: 1096px) calc(100vw - 40px), calc(100vw - 540px)"
              class="size-full object-contain">
          </div>
          <div class="rotate-[2deg] shadow-lg aspect-square">
            <img
              src="https://img.freepik.com/premium-photo/dentist-making-professional-teeth-cleaning-with-cotton-female-young-patient_763111-293.jpg"
              srcset="https://img.freepik.com/premium-photo/dentist-making-professional-teeth-cleaning-with-cotton-female-young-patient_763111-293.jpg?w=360 360w, https://img.freepik.com/premium-photo/dentist-making-professional-teeth-cleaning-with-cotton-female-young-patient_763111-293.jpg?w=740 740w, https://img.freepik.com/premium-photo/dentist-making-professional-teeth-cleaning-with-cotton-female-young-patient_763111-293.jpg?w=826 826w, https://img.freepik.com/premium-photo/dentist-making-professional-teeth-cleaning-with-cotton-female-young-patient_763111-293.jpg?w=900 900w, https://img.freepik.com/premium-photo/dentist-making-professional-teeth-cleaning-with-cotton-female-young-patient_763111-293.jpg?w=996 996w, https://img.freepik.com/premium-photo/dentist-making-professional-teeth-cleaning-with-cotton-female-young-patient_763111-293.jpg?w=1060 1060w, https://img.freepik.com/premium-photo/dentist-making-professional-teeth-cleaning-with-cotton-female-young-patient_763111-293.jpg?w=1380 1380w, https://img.freepik.com/premium-photo/dentist-making-professional-teeth-cleaning-with-cotton-female-young-patient_763111-293.jpg?w=1480 1480w, https://img.freepik.com/premium-photo/dentist-making-professional-teeth-cleaning-with-cotton-female-young-patient_763111-293.jpg?w=1800 1800w, https://img.freepik.com/premium-photo/dentist-making-professional-teeth-cleaning-with-cotton-female-young-patient_763111-293.jpg?w=2000 2000w"
              width="626" height="626"
              alt="dentist making professional teeth cleaning with the cotton female young patient" fetchpriority="high"
              sizes="(max-width: 480px) 100vw, (min-aspect-ratio: 626/626) 100%, (max-width: 1096px) calc(100vw - 40px), calc(100vw - 540px)"
              class="size-full object-contain">
          </div>
          <div class="rotate-[-2deg] shadow-lg aspect-square">
            <img
              src="https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-298.jpg"
              srcset="https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-298.jpg?w=360 360w, https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-298.jpg?w=740 740w, https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-298.jpg?w=826 826w, https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-298.jpg?w=900 900w, https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-298.jpg?w=996 996w, https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-298.jpg?w=1060 1060w, https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-298.jpg?w=1380 1380w, https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-298.jpg?w=1480 1480w, https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-298.jpg?w=1800 1800w, https://img.freepik.com/premium-photo/young-happy-man-woman-dental-examination-dentist_75922-298.jpg?w=2000 2000w"
              width="626" height="626" alt="young happy man and woman in a dental examination at dentist"
              fetchpriority="high"
              sizes="(max-width: 480px) 100vw, (min-aspect-ratio: 626/626) 100%, (max-width: 1096px) calc(100vw - 40px), calc(100vw - 540px)"
              class="size-full object-contain">
          </div>
        </div>
      </div>
    </section>

    <!-- About Section -->
    <section class="py-20 bg-base-100">
      <div class="container mx-auto px-4 grid grid-cols-1 lg:grid-cols-2 gap-12 ">
        <!-- Slika -->
        <div class="hidden md:block">
          <h2 class="text-4xl font-bold mb-4">O Nama</h2>
          <p class="text-lg text-base-content/80 mb-6">
            Naša misija je da vašim ljubimcima pružimo vrhunsku negu, strpljivo i sa puno ljubavi. Tim
            stručnjaka
            je tu da svaku posetu učini prijatnom, bez stresa i gužve.
          </p>
        </div>

        <!-- Tekstualni deo -->
        <div>

          <!-- Ključni benefiti -->
          <ul class="space-y-6">
            <li class="flex items-start">
              <span class="text-primary text-2xl mr-4">✔️</span>
              <div>
                <h4 class="font-semibold">Individualni pristup</h4>
                <p class="text-base-content/70">Svaki ljubimac dobija tretman prilagođen njegovim
                  potrebama.</p>
              </div>
            </li>
            <li class="flex items-start">
              <span class="text-primary text-2xl mr-4">🕒</span>
              <div>
                <h4 class="font-semibold">Fleksibilni termini</h4>
                <p class="text-base-content/70">Radimo od 9 do 19h, a rezervaciju možete lako napraviti
                  online.</p>
              </div>
            </li>
            <li class="flex items-start">
              <span class="text-primary text-2xl mr-4">🏆</span>
              <div>
                <h4 class="font-semibold">Iskusni tim</h4>
                <p class="text-base-content/70">Više od 5 godina iskustva i preko 1000 zadovoljnih
                  klijenata.</p>
              </div>
            </li>
          </ul>

          <!-- Poziv na akciju -->
          <div class="space-x-4 mt-8">
            <Link :href="route('booking.step1', { salonSlug })"
              class="btn btn-primary text-primary-content btn-lg hover:bg-secondary hover:text-secondary-content">
            Rezerviši odmah
            </Link>
          </div>
        </div>
      </div>
    </section>

    <!-- Services секција -->
    <section class="py-16 bg-base-200">
      <div class="container">
        <h2 class="text-3xl font-bold mb-6 text-center">Naše usluge</h2>

        <swiper class="relative" :slides-per-view="4" :space-between="20" :breakpoints="{
          0: { slidesPerView: 2 },
          640: { slidesPerView: 2 },
          1024: { slidesPerView: 4 }
        }" pagination :style="{ '--swiper-pagination-color': 'var(--color-base-content)' }">
          <swiper-slide v-for="svc in services" :key="svc.id">
            <div class="card shadow-lg overflow-hidden">
              <div class="image">
                <img
                  src="https://img.freepik.com/premium-photo/equipment-dental-instruments-dentist-s-office-dentistry_1077885-1389.jpg"
                  srcset="https://img.freepik.com/premium-photo/equipment-dental-instruments-dentist-s-office-dentistry_1077885-1389.jpg?w=360 360w, https://img.freepik.com/premium-photo/equipment-dental-instruments-dentist-s-office-dentistry_1077885-1389.jpg?w=740 740w, https://img.freepik.com/premium-photo/equipment-dental-instruments-dentist-s-office-dentistry_1077885-1389.jpg?w=826 826w, https://img.freepik.com/premium-photo/equipment-dental-instruments-dentist-s-office-dentistry_1077885-1389.jpg?w=900 900w, https://img.freepik.com/premium-photo/equipment-dental-instruments-dentist-s-office-dentistry_1077885-1389.jpg?w=996 996w, https://img.freepik.com/premium-photo/equipment-dental-instruments-dentist-s-office-dentistry_1077885-1389.jpg?w=1060 1060w, https://img.freepik.com/premium-photo/equipment-dental-instruments-dentist-s-office-dentistry_1077885-1389.jpg?w=1380 1380w, https://img.freepik.com/premium-photo/equipment-dental-instruments-dentist-s-office-dentistry_1077885-1389.jpg?w=1480 1480w, https://img.freepik.com/premium-photo/equipment-dental-instruments-dentist-s-office-dentistry_1077885-1389.jpg?w=1800 1800w, https://img.freepik.com/premium-photo/equipment-dental-instruments-dentist-s-office-dentistry_1077885-1389.jpg?w=2000 2000w"
                  width="626" height="417" alt="equipment and dental instruments in dentist s office dentistry"
                  fetchpriority="high"
                  sizes="(max-width: 480px) 100vw, (min-aspect-ratio: 626/417) 100%, (max-width: 1096px) calc(100vw - 40px), calc(100vw - 540px)"
                  class="size-full object-contain">
              </div>
              <div class="p-4">
                <h3 class="font-semibold mb-2">{{ svc.name }}</h3>
                <p class="text-sm text-gray-600 mb-4">{{ svc.desc }}</p>
                <div class="flex justify-between items-center">
                  <span class="font-bold">{{ svc.price }}</span>
                  <span class="text-sm text-gray-500">{{ svc.duration }} min</span>
                </div>
                <div class="space-x-4 mt-4">
                  <Link :href="route('booking.step1', { salonSlug })"
                    class="btn btn-primary border-secondary btn-sm hover:bg-primary hover:text-secondary">
                  Zakažite
                  </Link>
                </div>
              </div>
            </div>
          </swiper-slide>
        </swiper>
      </div>
    </section>

    <!-- Team секција -->
    <section class="py-20 bg-base-100">
      <div class="container px-4 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <!-- Levo: Naslov i opis -->
        <div>
          <h2 class="text-4xl font-bold mb-4">Naš tim</h2>
          <p class="text-lg text-base-content/80 mb-6">
            Upoznajte stručnjake koji svakodnevno brinu o vašim ljubimcima sa puno pažnje i ljubavi.
          </p>
        </div>

        <!-- Desno: Slider -->
        <div class="relative">
          <swiper :slides-per-view="2.5" :space-between="20" :breakpoints="{
            320: { slidesPerView: 1.2 },
            640: { slidesPerView: 2 },
            1024: { slidesPerView: 2.5 }
          }" pagination :style="{ '--swiper-pagination-color': 'var(--color-base-content)' }">
            <swiper-slide v-for="member in team" :key="member.id">
              <div class="card shadow-lg overflow-hidden">
                <div class="image">
                  <img
                    src="https://img.freepik.com/premium-photo/dentist-examining-patient-s-teeth-dentist-room_104603-1435.jpg"
                    srcset="https://img.freepik.com/premium-photo/dentist-examining-patient-s-teeth-dentist-room_104603-1435.jpg?w=360 360w, https://img.freepik.com/premium-photo/dentist-examining-patient-s-teeth-dentist-room_104603-1435.jpg?w=740 740w, https://img.freepik.com/premium-photo/dentist-examining-patient-s-teeth-dentist-room_104603-1435.jpg?w=826 826w, https://img.freepik.com/premium-photo/dentist-examining-patient-s-teeth-dentist-room_104603-1435.jpg?w=900 900w, https://img.freepik.com/premium-photo/dentist-examining-patient-s-teeth-dentist-room_104603-1435.jpg?w=996 996w, https://img.freepik.com/premium-photo/dentist-examining-patient-s-teeth-dentist-room_104603-1435.jpg?w=1060 1060w, https://img.freepik.com/premium-photo/dentist-examining-patient-s-teeth-dentist-room_104603-1435.jpg?w=1380 1380w, https://img.freepik.com/premium-photo/dentist-examining-patient-s-teeth-dentist-room_104603-1435.jpg?w=1480 1480w, https://img.freepik.com/premium-photo/dentist-examining-patient-s-teeth-dentist-room_104603-1435.jpg?w=1800 1800w, https://img.freepik.com/premium-photo/dentist-examining-patient-s-teeth-dentist-room_104603-1435.jpg?w=2000 2000w"
                    width="626" height="940" alt="dentist examining a patient's teeth in the dentist room"
                    fetchpriority="high"
                    sizes="(max-width: 480px) 100vw, (min-aspect-ratio: 626/940) 100%, (max-width: 1096px) calc(100vw - 40px), calc(100vw - 540px)"
                    class="size-full object-contain">
                </div>
                <div class="p-4">
                  <h4 class="font-semibold">{{ member.name }}</h4>
                  <p class="text-sm text-base-content/70">{{ member.role }}</p>
                </div>
              </div>
            </swiper-slide>
          </swiper>
        </div>
      </div>
    </section>
  </Layout>
</template>


<script setup>
import { Link } from '@inertiajs/vue3'
import Layout from '@/Pages/Public/Layout.vue'
import { Swiper, SwiperSlide } from 'swiper/vue'
import 'swiper/css'
import 'swiper/css/navigation'
import SwiperCore from 'swiper'
import 'swiper/css/pagination';

// import required modules
import { Pagination } from 'swiper/modules';
SwiperCore.use([Pagination])

// —————— Оригинални Inertia props ——————
const props = defineProps({
  salonSlug: String,
  salon: Object,
  currentRoute: String,
})
const { salonSlug, salon, currentRoute } = props
// ————————————————

/*
  Hard-code подаци док не повучемо из CMS:
*/
const services = [
  { id: 1, name: 'Šišanje', desc: 'Klasično muško šišanje.', price: '1.200 RSD', duration: 30, image: 'https://via.placeholder.com/256x160?text=Šišanje' },
  { id: 2, name: 'Boja kose', desc: 'Pehlivan ili celokupan preliv.', price: '3.000 RSD', duration: 60, image: 'https://via.placeholder.com/256x160?text=Boja+kose' },
  { id: 3, name: 'Feniranje', desc: 'Profesionalno suvo feniranje.', price: '800 RSD', duration: 20, image: 'https://via.placeholder.com/256x160?text=Feniranje' },
  { id: 4, name: 'Manikir', desc: 'Obični i gel manikir.', price: '2.000 RSD', duration: 45, image: 'https://via.placeholder.com/256x160?text=Manikir' },
  { id: 5, name: 'Pedikir', desc: 'Standardni pedikir.', price: '2.500 RSD', duration: 50, image: 'https://via.placeholder.com/256x160?text=Pedikir' },
  { id: 6, name: 'Masaža', desc: 'Relaks masaža 30 min.', price: '1.500 RSD', duration: 30, image: 'https://via.placeholder.com/256x160?text=Masaža' },
]

const team = [
  { id: 1, name: 'Ana Marković', role: 'Frizerka', bio: 'Stručnjak za bojenje i šišanje.', avatar: 'https://via.placeholder.com/150x150?text=Ana' },
  { id: 2, name: 'Petar Petrović', role: 'Masoterapeut', bio: 'Fond za relaks masaže.', avatar: 'https://via.placeholder.com/150x150?text=Petar' },
  { id: 3, name: 'Jelena Jović', role: 'Manikirka', bio: 'Majstor za nokte i stilizaciju.', avatar: 'https://via.placeholder.com/150x150?text=Jelena' },
  { id: 4, name: 'Marko Marković', role: 'Pedikir', bio: 'Specijalista za stopala.', avatar: 'https://via.placeholder.com/150x150?text=Marko' },
]
</script>

<style scoped>
/* По дифолту bullets су беле – овим промениш њихов background-color */
.swiper-pagination-bullet {
  opacity: 0.5;
}

.swiper-pagination-bullet-active {
  opacity: 1;
}

/* Позиционирамо pagination централно испод carousel-а */
.swiper {
  padding-bottom: 2.5rem;
  /* место за bullets */
}

.swiper-pagination {
  bottom: 0.5rem !important;
}
</style>
