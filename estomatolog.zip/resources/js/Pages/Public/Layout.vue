<template>
  <div class="min-h-screen flex flex-col">
    <!-- Desktop Header -->
    <div class="hidden md:flex flex-col fixed top-0 w-full z-50">
      <div class="bg-primary text-sm text-primary-content">
        <div class="container flex justify-between items-center py-2">
          <span>Serbia, Street Number 12</span>
          <span>060/1234-56789</span>
          <span>Monday – Friday: 9:00 AM – 7:00 PM</span>
        </div>
      </div>
      <header class="hidden md:flex items-center px-8 py-4 bg-base-200 text-base-content shadow">
        <div class="container flex items-center justify-between">
          <!-- Logo -->
          <div class="flex items-center space-x-2">
            <img v-if="salon.logo" :src="salon.logo" alt="Logo" class="h-10 w-10 object-cover rounded-full" />
            <img v-else :src="route('photos.show', ['filename', 'logo.svg'])" alt="Default Logo" class="h-12" />
          </div>

          <!-- Nav Links -->
          <nav class="flex space-x-6">
            <Link :href="route('public.home', { salonSlug })" class="hover:underline"
              :class="{ 'underline font-semibold': isActive('public.home') }">Početna</Link>
            <Link :href="route('public.services', { salonSlug })" class="hover:underline"
              :class="{ 'underline font-semibold': isActive('public.services') }">Usluge</Link>
            <Link :href="route('public.contact', { salonSlug })" class="hover:underline"
              :class="{ 'underline font-semibold': isActive('public.contact') }">Kontakt</Link>
          </nav>

          <!-- CTA + Avatar + Lang -->
          <div class="flex items-center space-x-4">
            <Link :href="route('booking.step1', { salonSlug })"
              class="btn btn-primary text-primary-content btn-sm hover:bg-secondary hover:text-secondary-content">
            Zakažite</Link>

            <!-- only show profile dropdown if logged in -->
            <div v-if="isLoggedIn && auth.user.role == 'client'" class="dropdown dropdown-end">
              <label tabindex="0" class="btn btn-circle bg-primary text-primary-content avatar">
                <span class="w-10 rounded-full flex items-center justify-center">
                  {{ initials }}
                </span>
              </label>
              <ul tabindex="0"
                class="dropdown-content menu p-2 shadow bg-secondary text-secondary-content rounded-box w-52">
                <li>
                  <Link :href="route('owner.users.index', { salonSlug })">Profil</Link>
                </li>
                <li>
                  <Link :href="route('client.appointment.index', { salonSlug })">Termini</Link>
                </li>
                <li>
                  <button @click="logout()">Logout</button>
                </li>
              </ul>
            </div>

            <!-- language switch -->
            <div class="dropdown">
              <label tabindex="0" class="cursor-pointer">🌐</label>
              <ul tabindex="0"
                class="dropdown-content menu p-2 shadow bg-secondary text-secondary-content rounded-box w-32">
                <li><button @click.prevent="switchLang('sr')">🇷🇸 SR</button></li>
                <li><button @click.prevent="switchLang('en')">🇬🇧 EN</button></li>
              </ul>
            </div>
          </div>
        </div>
      </header>
    </div>

    <!-- Mobile Dock -->
    <div class="fixed bottom-0 inset-x-0 md:hidden flex justify-around py-2 bg-secondary text-secondary-content z-50">
      <Link :href="route('public.home', { salonSlug })" class="flex flex-col items-center text-sm">
      <!-- home icon -->
      <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mb-1" fill="none" viewBox="0 0 24 24"
        stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l9-9 9 9M4 10v10h16V10" />
      </svg>
      <span>Početna</span>
      </Link>

      <Link :href="route('client.appointment.index', { salonSlug })" class="flex flex-col items-center text-sm">
      <!-- calendar icon -->
      <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mb-1" fill="none" viewBox="0 0 24 24"
        stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
          d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
      </svg>
      <span>Termini</span>
      </Link>

      <Link :href="route('public.services', { salonSlug })" class="flex flex-col items-center text-sm">
      <!-- services icon -->
      <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mb-1" fill="none" viewBox="0 0 24 24"
        stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
          d="M12 12h.01M6 12h.01M18 12h.01M8 21h8a2 2 0 002-2v-5H6v5a2 2 0 002 2zM16 5V3H8v2H3v4h18V5h-5z" />
      </svg>
      <span>Usluge</span>
      </Link>

      <!-- mobile profile button -->
      <button v-if="isLoggedIn && auth.user.role == 'client'" class="flex flex-col items-center text-sm"
        @click="openProfileModal = true">
        <!-- profile icon -->
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mb-1" fill="none" viewBox="0 0 24 24"
          stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
            d="M5.121 17.804A9 9 0 1118.879 6.196 9 9 0 015.12 17.804zM15 11a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
        <span>Profil</span>
      </button>
    </div>

    <!-- Profile Modal -->
    <div v-if="isLoggedIn && auth.user.role == 'client' && openProfileModal"
      class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div class="bg-secondary text-secondary-content rounded-lg p-6 w-11/12 max-w-sm">
        <h2 class="text-xl font-bold mb-4">Profil</h2>
        <p><strong>Ime:</strong> {{ auth.user.name }}</p>
        <p><strong>Email:</strong> {{ auth.user.email }}</p>
        <p class="mt-4"><strong>Termini:</strong></p>
        <ul class="list-disc list-inside mb-4">
          <li v-for="apt in auth.user.appointments" :key="apt.id">
            {{ apt.date }} — {{ apt.service_name }}
          </li>
        </ul>
        <button class="btn btn-outline btn-primary w-full mb-2">Kontakt</button>
        <button class="btn btn-error w-full" @click="logout()">Logout</button>
        <button class="mt-2 text-sm text-center w-full" @click="openProfileModal = false">
          Zatvori
        </button>
      </div>
    </div>

    <!-- Main Content -->
    <main class="flex-1 overflow-auto pb-0 pt-16 md:pt-[150px]">
      <slot />
    </main>

    <!-- Footer -->
    <div class="bg-neutral">
      <footer class="footer sm:footer-horizontal bg-neutral text-neutral-content container p-4">
        <aside class="grid-flow-col items-center">
          <!-- logo + copyright -->
          <svg width="36" height="36" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd"
            clip-rule="evenodd" class="fill-current">
            <path d="M22.672 15.226l-2.432.811.841 2.515c..." />
          </svg>
          <p>Copyright © {{ new Date().getFullYear() }} - All rights reserved</p>
        </aside>
        <nav class="grid-flow-col gap-4 md:place-self-center md:justify-self-end">
          <a><!-- twitter svg --></a>
          <a><!-- youtube svg --></a>
          <a><!-- facebook svg --></a>
        </nav>
      </footer>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import { Link, router } from '@inertiajs/vue3'
import { usePage } from '@inertiajs/vue3'

const { salonSlug, salon, currentRoute, auth, theme } = usePage().props

const openProfileModal = ref(false)

// inicijali iz auth.user.name
const initials = computed(() => {
  const name = auth.user?.name || ''
  return name
    .split(' ')
    .map(n => n[0] || '')
    .join('')
    .slice(0, 2)
    .toUpperCase()
})

const isLoggedIn = computed(() => Boolean(auth.user))

function isActive(routeName) {
  return currentRoute === routeName
}

function switchLang(lang) {
  // tvoja logika za menjanje jezika
  console.log('Switch to', lang)
}

function logout() {
  router.post(route('logout'))
}

// PWA install prompt
const deferredPrompt = ref(null)
onMounted(() => {
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault()
    deferredPrompt.value = e
  })
})
function promptInstall() {
  if (deferredPrompt.value) {
    deferredPrompt.value.prompt()
    deferredPrompt.value.userChoice.then(() => {
      deferredPrompt.value = null
    })
  }
}

// Tema
onMounted(() => {
  document.documentElement.setAttribute('data-theme', theme)
})
watch(
  () => theme,
  (t) => {
    document.documentElement.setAttribute('data-theme', t)
  }
)
</script>

<style scoped>
/* po potrebi custom stilovi */
</style>
