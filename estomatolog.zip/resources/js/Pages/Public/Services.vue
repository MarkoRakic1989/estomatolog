<template>
  <Layout :salonSlug="salonSlug" :salon="salon" :currentRoute="currentRoute">
    <section class="py-16 bg-base-100">
      <div class="max-w-5xl mx-auto px-4">
        <h2 class="text-3xl font-semibold text-center mb-8">Usluge</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          <!-- Skeleton loader -->
          <template v-if="loading">
            <div v-for="n in 16" :key="n" class="card bg-base-100 shadow-xl">
              <figure>
                <div class="bg-base-300 h-48 w-full animate-pulse rounded"></div>
              </figure>
              <div class="card-body space-y-2">
                <div class="h-6 bg-base-300 w-1/2 animate-pulse rounded"></div>
                <div class="h-4 bg-base-300 w-full animate-pulse rounded"></div>
                <div class="h-4 bg-base-300 w-3/4 animate-pulse rounded"></div>
                <div class="card-actions justify-between items-center mt-4">
                  <div class="h-6 bg-base-300 w-16 animate-pulse rounded"></div>
                  <div class="h-6 bg-base-300 w-24 animate-pulse rounded"></div>
                </div>
              </div>
            </div>
          </template>

          <!-- Real content -->
          <template v-else>
            <div v-for="svc in services" :key="svc.id"
              class="card bg-base-100 shadow-xl hover:shadow-2xl transition cursor-pointer">
              <div class="h-40 bg-base-300 animate-pulse"></div>
              <div class="card-body">
                <h2 class="card-title">{{ svc.name }}</h2>
                <p class="line-clamp-3">{{ svc.description }}</p>
                <div class="card-actions justify-between items-center mt-4">
                  <span class="badge badge-primary">{{ svc.price }}€</span>
                  <Link :href="route('booking.step1', { salonSlug, serviceId: svc.id })"
                    class="btn btn-sm btn-secondary">
                  Rezerviši
                  </Link>
                </div>
              </div>
            </div>
          </template>
        </div>
      </div>
    </section>
  </Layout>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import Layout from '@/Pages/Public/Layout.vue'
import { Link } from '@inertiajs/vue3'

const props = defineProps({
  salonSlug: String,
  salon: Object,
  currentRoute: String,
})

// Hardkodirane usluge dok nemaš bazu
const services = [
  { id: 1, name: 'Frizura', description: 'Klasična ženska ili muška frizura po vašoj želji.', price: 25, image_url: 'https://via.placeholder.com/400x300?text=Frizura' },
  { id: 2, name: 'Farbanje kose', description: 'Profesionalno bojenje uz negu i toniranje.', price: 50, image_url: 'https://via.placeholder.com/400x300?text=Farbanje+Kose' },
  { id: 3, name: 'Manikir', description: 'Oblikovanje noktiju, lakiranje i nega.', price: 20, image_url: 'https://via.placeholder.com/400x300?text=Manikir' },
  { id: 4, name: 'Pedikir', description: 'Potpuni pedikir sa pilingom i masažom.', price: 30, image_url: 'https://via.placeholder.com/400x300?text=Pedikir' },
  { id: 5, name: 'Tretman lica', description: 'Dubinsko čišćenje i hidratacija lica.', price: 45, image_url: 'https://via.placeholder.com/400x300?text=Tretman+Lica' },
  { id: 6, name: 'Masaža', description: 'Opustite se uz relax masažu celog tela.', price: 60, image_url: 'https://via.placeholder.com/400x300?text=Masa%C5%BEa' },
  { id: 7, name: 'Šminkanje', description: 'Večernje ili dnevno profesionalno šminkanje.', price: 35, image_url: 'https://via.placeholder.com/400x300?text=%C5%A0minkanje' },
  { id: 8, name: 'Stilizovanje kose', description: 'Fleksibilni styling za sve prilike.', price: 40, image_url: 'https://via.placeholder.com/400x300?text=Stilizovanje+Kose' },
  { id: 9, name: 'Depilacija', description: 'Uklanjanje dlačica voskom ili šećernom pastom.', price: 25, image_url: 'https://via.placeholder.com/400x300?text=Depilacija' },
  { id: 10, name: 'Oblikovanje obrva', description: 'Precizno čupanje ili voskiranje obrva.', price: 15, image_url: 'https://via.placeholder.com/400x300?text=Oblikovanje+Obrva' },
  { id: 11, name: 'Brijač', description: 'Moderni muškarci frizura i brijanje brade.', price: 30, image_url: 'https://via.placeholder.com/400x300?text=Brija%C4%8D' },
  { id: 12, name: 'Tretman kose', description: 'Hranljivi paketi za regeneraciju kose.', price: 55, image_url: 'https://via.placeholder.com/400x300?text=Tretman+Kose' },
  { id: 13, name: 'Body scrub', description: 'Piling tela za glatku i negovanu kožu.', price: 50, image_url: 'https://via.placeholder.com/400x300?text=Body+Scrub' },
  { id: 14, name: 'Spa paket', description: 'Kompletan spa ritual u trajanju od 2h.', price: 100, image_url: 'https://via.placeholder.com/400x300?text=Spa+Paket' },
  { id: 15, name: 'Brow tint', description: 'Boja i popunjavanje obrva za prirodan izgled.', price: 18, image_url: 'https://via.placeholder.com/400x300?text=Brow+Tint' },
  { id: 16, name: 'Masaža glave', description: 'Stimulativna masaža vlasišta.', price: 35, image_url: 'https://via.placeholder.com/400x300?text=Masa%C5%BEa+Glave' },
]

// Flag za prikaz skeletona
const loading = ref(true)

onMounted(() => {
  // simuliramo kratko kašnjenje učitavanja
  setTimeout(() => {
    loading.value = false
  }, 500)
})
</script>

<style scoped>
.line-clamp-3 {
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
</style>
