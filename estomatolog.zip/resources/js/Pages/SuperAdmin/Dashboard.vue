<template>
    <AuthenticatedLayout>
        <template #header>
            <h1 class="text-3xl font-bold">Dashboard</h1>
        </template>

        <div class="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <!-- Total Salons -->
            <div class="stats shadow">
                <div class="stat">
                    <div class="stat-title">Saloni</div>
                    <div class="stat-value">{{ totalSalons }}</div>
                </div>
            </div>

            <!-- Total Users -->
            <div class="stats shadow">
                <div class="stat">
                    <div class="stat-title">Korisnici</div>
                    <div class="stat-value">{{ totalUsers }}</div>
                </div>
            </div>

            <!-- Total Packages -->
            <div class="stats shadow">
                <div class="stat">
                    <div class="stat-title">Paketi</div>
                    <div class="stat-value">{{ totalPackages }}</div>
                </div>
            </div>

            <!-- Revenue This Month -->
            <div class="stats shadow">
                <div class="stat">
                    <div class="stat-title">Prihod (ovog meseca)</div>
                    <div class="stat-value">${{ revenueThisMonth.toFixed(2) }}</div>
                </div>
            </div>

            <!-- Active Subscriptions -->
            <div class="stats shadow">
                <div class="stat">
                    <div class="stat-title">Aktivne pretplate</div>
                    <div class="stat-value">{{ activeSubs }}</div>
                </div>
            </div>

            <!-- Pending Subscriptions -->
            <div class="stats shadow">
                <div class="stat">
                    <div class="stat-title">Na čekanju</div>
                    <div class="stat-value">{{ pendingSubs }}</div>
                </div>
            </div>

            <!-- Expired Subscriptions -->
            <div class="stats shadow">
                <div class="stat">
                    <div class="stat-title">Istekle pretplate</div>
                    <div class="stat-value">{{ expiredSubs }}</div>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import { usePage } from '@inertiajs/vue3'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue'

const {
    totalSalons,
    totalUsers,
    totalPackages,
    activeSubs,
    pendingSubs,
    expiredSubs,
    revenueThisMonth
} = defineProps({
    totalSalons: Number,
    totalUsers: Number,
    totalPackages: Number,
    activeSubs: Number,
    pendingSubs: Number,
    expiredSubs: Number,
    revenueThisMonth: Number,
})
</script>

<style scoped>
/* adjust stat card heights if needed */
.stats {
    background: var(--p-bg);
    /* inherit your theme’s base-100 */
}
</style>
