<template>
    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-2xl font-semibold">Novi paket</h2>
        </template>

        <form @submit.prevent="submit" class="space-y-4 mt-6">
            <!-- Name -->
            <div>
                <label class="label"><span class="label-text">Naziv paketa</span></label>
                <input v-model="form.name" type="text" class="input input-bordered w-full" />
                <p v-if="form.errors.name" class="text-red-600 text-sm">
                    {{ form.errors.name }}
                </p>
            </div>

            <!-- Price -->
            <div>
                <label class="label"><span class="label-text">Cena (RSD)</span></label>
                <input v-model="form.price" type="number" step="0.01" class="input input-bordered w-full" />
                <p v-if="form.errors.price" class="text-red-600 text-sm">
                    {{ form.errors.price }}
                </p>
            </div>

            <!-- Duration -->
            <div>
                <label class="label"><span class="label-text">Trajanje (meseci)</span></label>
                <input v-model="form.duration" type="number" class="input input-bordered w-full" />
                <p v-if="form.errors.duration" class="text-red-600 text-sm">
                    {{ form.errors.duration }}
                </p>
            </div>

            <!-- Description -->
            <div>
                <label class="label"><span class="label-text">Opis paketa</span></label>
                <textarea v-model="form.description" rows="4" class="textarea textarea-bordered w-full"
                    placeholder="Unesite detaljan opis paketa..."></textarea>
                <p v-if="form.errors.description" class="text-red-600 text-sm">
                    {{ form.errors.description }}
                </p>
            </div>

            <!-- Active Toggle -->
            <div class="form-control">
                <label class="label cursor-pointer flex items-center space-x-2">
                    <input type="checkbox" v-model="form.is_active" class="checkbox checkbox-primary" />
                    <span class="label-text">Aktivan paket</span>
                </label>
                <p v-if="form.errors.is_active" class="text-red-600 text-sm">
                    {{ form.errors.is_active }}
                </p>
            </div>

            <!-- Submit -->
            <div class="text-right">
                <Link class="btn btn-outline mr-2" :href="route('superadmin.packages.index')">
                Otkaži
                </Link>
                <button :disabled="form.processing" type="submit" class="btn btn-primary">
                    <span v-if="!form.processing">Sačuvaj</span>
                    <span v-else>Čuvanje...</span>
                </button>
            </div>
        </form>
    </AuthenticatedLayout>
</template>

<script setup>
import { useForm, Link } from '@inertiajs/vue3'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue'

const form = useForm({
    name: '',
    price: '',
    duration: '',
    description: '',
    is_active: true,
})

function submit() {
    form.post(route('superadmin.packages.store'))
}
</script>
