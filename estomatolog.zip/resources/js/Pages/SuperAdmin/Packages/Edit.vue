<template>
    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-2xl font-semibold">Uredi paket</h2>
        </template>

        <form @submit.prevent="submit" class="space-y-4 mt-6">
            <!-- Name -->
            <div>
                <label class="label"><span class="label-text">Naziv paketa</span></label>
                <input v-model="form.name" type="text" class="input input-bordered w-full" />
                <p v-if="form.errors.name" class="text-red-600 text-sm">
                    {{ form.errors.name }}
                </p>
            </div>

            <!-- Price -->
            <div>
                <label class="label"><span class="label-text">Cena (USD)</span></label>
                <input v-model="form.price" type="number" step="0.01" class="input input-bordered w-full" />
                <p v-if="form.errors.price" class="text-red-600 text-sm">
                    {{ form.errors.price }}
                </p>
            </div>

            <!-- Duration -->
            <div>
                <label class="label"><span class="label-text">Trajanje (meseci)</span></label>
                <input v-model="form.duration" type="number" class="input input-bordered w-full" />
                <p v-if="form.errors.duration" class="text-red-600 text-sm">
                    {{ form.errors.duration }}
                </p>
            </div>

            <!-- Submit -->
            <div class="text-right">
                <Link class="btn btn-outline mr-2" :href="route('superadmin.packages.index')">
                Otkaži
                </Link>
                <button :disabled="form.processing" type="submit" class="btn btn-primary">
                    <span v-if="!form.processing">Ažuriraj</span>
                    <span v-else>Ažuriranje...</span>
                </button>
            </div>
        </form>
    </AuthenticatedLayout>
</template>

<script setup>
import { useForm, Link } from '@inertiajs/vue3'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue'

const props = defineProps({
    package: Object,
})

const form = useForm({
    name: props.package.name,
    price: props.package.price,
    duration: props.package.duration,
})

function submit() {
    form.put(route('superadmin.packages.update', props.package.id))
}
</script>
