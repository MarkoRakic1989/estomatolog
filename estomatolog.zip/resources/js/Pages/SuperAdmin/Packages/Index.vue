<template>
    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-2xl font-semibold">Paketi</h2>
        </template>

        <div class="mt-6">
            <Link class="btn btn-primary mb-4" :href="route('superadmin.packages.create')">
            Novi paket
            </Link>

            <div class="overflow-x-auto">
                <table class="table table-zebra w-full">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Naziv</th>
                            <th>Cena</th>
                            <th>Trajanje (meseci)</th>
                            <th>Aktivan</th>
                            <th class="text-center">Akcije</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="pkg in packages.data" :key="pkg.id">
                            <td>{{ pkg.id }}</td>
                            <td>{{ pkg.name }}</td>
                            <td>{{ pkg.price }} RSD</td>
                            <td>{{ pkg.duration }}</td>
                            <td>
                                <span v-if="pkg.is_active" class="badge badge-success">Da</span>
                                <span v-else class="badge badge-warning">Coming Soon</span>
                            </td>
                            <td class="text-center space-x-2">
                                <Link class="btn btn-sm btn-info" :href="route('superadmin.packages.edit', pkg.id)">
                                Uredi
                                </Link>
                                <button class="btn btn-sm btn-error" @click="destroy(pkg.id)">
                                    Obriši
                                </button>
                                <button class="btn btn-sm btn-outline" @click="openModal(pkg)">
                                    Opis
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="mt-4 flex justify-center space-x-2">
                <button v-for="link in packages.links" :key="link.label" v-html="link.label" :disabled="!link.url"
                    :class="{
                        'btn btn-sm': true,
                        'btn-primary': link.active,
                        'btn-outline': !link.active
                    }" @click="goTo(link.url)"></button>
            </div>
        </div>

        <!-- Opis paketa Modal -->
        <div v-if="showModal" class="modal modal-open">
            <div class="modal-box">
                <h3 class="font-bold text-lg">{{ selected.name }}</h3>
                <p class="py-4 whitespace-pre-line">
                    {{ selected.description || 'Nema opisa za ovaj paket.' }}
                </p>
                <div class="modal-action">
                    <button class="btn" @click="showModal = false">Zatvori</button>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import { ref } from 'vue'
import { useForm, Link, usePage } from '@inertiajs/vue3'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue'

const props = defineProps({
    packages: Object,
})

const form = useForm()
const showModal = ref(false)
const selected = ref({ name: '', description: '', is_active: false })

function destroy(id) {
    if (!confirm('Da li ste sigurni da želite da obrišete ovaj paket?'))
        return
    form.delete(route('superadmin.packages.destroy', id))
}

function goTo(url) {
    form.get(url, {}, { preserveState: true })
}

function openModal(pkg) {
    selected.value = pkg
    showModal.value = true
}
</script>
