<template>
    <AuthenticatedLayout>

        <Head title="Create Permission" />

        <div class="max-w-md mx-auto py-8">
            <h1 class="text-2xl font-bold mb-6">Create Permission</h1>

            <form @submit.prevent="submit" class="space-y-6">
                <div>
                    <label class="block mb-1 font-medium">Name</label>
                    <input v-model="form.name" type="text" class="input input-bordered w-full" />
                    <p v-if="form.errors.name" class="text-red-600 text-sm">
                        {{ form.errors.name }}
                    </p>
                </div>

                <div>
                    <label class="block mb-1 font-medium">Guard Name</label>
                    <input v-model="form.guard_name" type="text" class="input input-bordered w-full" />
                    <p v-if="form.errors.guard_name" class="text-red-600 text-sm">
                        {{ form.errors.guard_name }}
                    </p>
                </div>

                <div class="flex justify-end space-x-2">
                    <Link :href="route('superadmin.permissions.index')" class="btn btn-ghost">Cancel</Link>
                    <button type="submit" class="btn btn-primary" :disabled="form.processing">
                        <span v-if="!form.processing">Create</span>
                        <span v-else>…</span>
                    </button>
                </div>
            </form>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import { useForm, Head, Link } from '@inertiajs/vue3'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue'

const form = useForm({
    name: '',
    guard_name: 'web',
})

function submit() {
    form.post(route('superadmin.permissions.store'))
}
</script>
