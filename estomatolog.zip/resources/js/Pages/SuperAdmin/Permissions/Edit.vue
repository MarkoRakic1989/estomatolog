<template>
    <AuthenticatedLayout>

        <Head :title="`Edit Permission: ${permission.name}`" />

        <div class="max-w-md mx-auto py-8">
            <h1 class="text-2xl font-bold mb-6">Edit Permission</h1>

            <form @submit.prevent="submit" class="space-y-6">
                <div>
                    <label class="block mb-1 font-medium">Name</label>
                    <input v-model="form.name" type="text" class="input input-bordered w-full" />
                    <p v-if="form.errors.name" class="text-red-600 text-sm">
                        {{ form.errors.name }}
                    </p>
                </div>

                <div>
                    <label class="block mb-1 font-medium">Guard Name</label>
                    <input v-model="form.guard_name" type="text" class="input input-bordered w-full" />
                    <p v-if="form.errors.guard_name" class="text-red-600 text-sm">
                        {{ form.errors.guard_name }}
                    </p>
                </div>

                <div class="flex justify-end space-x-2">
                    <Link :href="route('superadmin.permissions.index')" class="btn btn-ghost">Cancel</Link>
                    <button type="submit" class="btn btn-primary" :disabled="form.processing">
                        <span v-if="!form.processing">Save</span>
                        <span v-else>…</span>
                    </button>
                </div>
            </form>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import { useForm, Head, Link } from '@inertiajs/vue3'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue'

const props = defineProps({
    permission: Object, // { id, name, guard_name }
})

const form = useForm({
    name: props.permission.name,
    guard_name: props.permission.guard_name,
})

function submit() {
    form.patch(route('superadmin.permissions.update', props.permission.id))
}
</script>
