<template>
    <AuthenticatedLayout>

        <Head title="Permissions" />

        <div class="max-w-6xl mx-auto py-8">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold">Permissions</h1>
                <Link :href="route('superadmin.permissions.create')" class="btn btn-primary">
                New Permission
                </Link>
            </div>

            <table class="table w-full">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Guard</th>
                        <th class="text-right">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="perm in permissions.data" :key="perm.id">
                        <td>{{ perm.name }}</td>
                        <td>{{ perm.guard_name }}</td>
                        <td class="text-right space-x-2">
                            <Link :href="route('superadmin.permissions.edit', perm.id)" class="btn btn-sm btn-ghost">
                            Edit</Link>
                            <button @click="destroy(perm.id)" class="btn btn-sm btn-error text-white">Delete</button>
                        </td>
                    </tr>
                </tbody>
            </table>
            <!-- Paginacija -->
            <div class="mt-4 flex justify-center space-x-2">
                <button v-for="link in permissions.links" :key="link.label" v-html="link.label" :disabled="!link.url"
                    :class="{
                        'btn btn-sm': true,
                        'btn-primary': link.active,
                        'btn-outline': !link.active
                    }" @click="goTo(link.url)"></button>
            </div>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import { useForm } from '@inertiajs/vue3'
import { Link, Head } from '@inertiajs/vue3'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue'

const props = defineProps({
    permissions: Object, // { data: [...], links: [...] }
})

const form = useForm()
function destroy(id) {
    if (!confirm('Are you sure?')) return
    form.delete(route('superadmin.permissions.destroy', id))
}
</script>
