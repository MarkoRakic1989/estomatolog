<template>
    <AuthenticatedLayout>

        <Head :title="`Edit Role: ${role.name}`" />

        <div class="max-w-md mx-auto py-8">
            <h1 class="text-2xl font-bold mb-6">Edit Role</h1>

            <form @submit.prevent="submit" class="space-y-6">
                <!-- name -->
                <div>
                    <label class="block mb-1 font-medium">Name</label>
                    <input v-model="form.name" type="text" class="input input-bordered w-full" />
                    <p v-if="form.errors.name" class="text-red-600 text-sm">
                        {{ form.errors.name }}
                    </p>
                </div>

                <!-- permissions -->
                <div>
                    <label class="block mb-1 font-medium">Permissions</label>
                    <div class="grid grid-cols-2 gap-2">
                        <label v-for="perm in permissions" :key="perm.name" class="flex items-center space-x-2">
                            <input type="checkbox" :value="perm.name" v-model="form.permissions"
                                class="checkbox checkbox-primary" />
                            <span>{{ perm.name }}</span>
                        </label>
                    </div>
                    <p v-if="form.errors.permissions" class="text-red-600 text-sm">
                        {{ form.errors.permissions }}
                    </p>
                </div>

                <div class="flex justify-end space-x-2">
                    <Link :href="route('superadmin.roles.index')" class="btn btn-ghost">Cancel</Link>
                    <button type="submit" class="btn btn-primary" :disabled="form.processing">
                        <span v-if="!form.processing">Save</span>
                        <span v-else>…</span>
                    </button>
                </div>
            </form>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import { useForm, Head, Link } from '@inertiajs/vue3'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue'

const props = defineProps({
    role: Object, // { id, name, permissions: ['perm1',…] }
    permissions: Array,
})

const form = useForm({
    name: props.role.name,
    permissions: props.role.permissions,
})

function submit() {
    form.patch(route('superadmin.roles.update', props.role.id))
}
</script>
