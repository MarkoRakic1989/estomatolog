<template>
    <AuthenticatedLayout>

        <Head title="Role Management" />

        <div class="max-w-6xl mx-auto py-8">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold">Role</h1>
                <Link :href="route('superadmin.roles.create')" class="btn btn-primary">
                New Role
                </Link>
            </div>

            <table class="table w-full">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Permissions</th>
                        <th class="text-right">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="role in roles.data" :key="role.id">
                        <td>{{ role.name }}</td>
                        <td>
                            <span v-for="perm in role.permissions" :key="perm"
                                class="badge badge-sm badge-outline mr-1">
                                {{ perm }}
                            </span>
                        </td>
                        <td class="text-right space-x-2">
                            <Link :href="route('superadmin.roles.edit', role.id)" class="btn btn-sm btn-ghost">Edit
                            </Link>
                            <button @click="destroy(role.id)" class="btn btn-sm btn-error text-white">Delete</button>
                        </td>
                    </tr>
                </tbody>
            </table>

            <!-- Paginacija -->
            <div class="mt-4 flex justify-center space-x-2">
                <button v-for="link in roles.links" :key="link.label" v-html="link.label" :disabled="!link.url" :class="{
                    'btn btn-sm': true,
                    'btn-primary': link.active,
                    'btn-outline': !link.active
                }" @click="goTo(link.url)"></button>
            </div>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import { useForm } from '@inertiajs/vue3'
import { Link, Head, usePage } from '@inertiajs/vue3'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue'

const props = defineProps({
    roles: Object, // { data: [...], links: [...] }
})

const form = useForm()
function destroy(id) {
    if (!confirm('Are you sure?')) return
    form.delete(route('superadmin.roles.destroy', id))
}
</script>
