<template>
    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-2xl font-semibold">Novi salon</h2>
        </template>

        <form @submit.prevent="submit" class="space-y-4 mt-6">
            <!-- Category -->
            <div>
                <label class="label"><span class="label-text">Kategorija</span></label>
                <select v-model="form.category_id" class="select select-bordered w-full">
                    <option value="" disabled>Odaberi kategoriju</option>
                    <option v-for="c in categories" :key="c.id" :value="c.id">
                        {{ c.name }}
                    </option>
                </select>
                <p v-if="form.errors.category_id" class="text-red-600 text-sm">
                    {{ form.errors.category_id }}
                </p>
            </div>

            <!-- Name & Slug & Owner Email -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="label"><span class="label-text">Naziv</span></label>
                    <input v-model="form.name" type="text" class="input input-bordered w-full" />
                    <p v-if="form.errors.name" class="text-red-600 text-sm">
                        {{ form.errors.name }}
                    </p>
                </div>
                <div>
                    <label class="label"><span class="label-text">Slug</span></label>
                    <input v-model="form.slug" type="text" class="input input-bordered w-full" />
                    <p v-if="form.errors.slug" class="text-red-600 text-sm">
                        {{ form.errors.slug }}
                    </p>
                </div>
                <div>
                    <label class="label"><span class="label-text">Email vlasnika</span></label>
                    <input v-model="form.owner_email" type="email" class="input input-bordered w-full" />
                    <p v-if="form.errors.owner_email" class="text-red-600 text-sm">
                        {{ form.errors.owner_email }}
                    </p>
                </div>
            </div>

            <!-- Colors & Phone -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="label"><span class="label-text">Primary boja</span></label>
                    <input v-model="form.primary_color" type="color" class="w-full h-10" />
                </div>
                <div>
                    <label class="label"><span class="label-text">Secondary boja</span></label>
                    <input v-model="form.secondary_color" type="color" class="w-full h-10" />
                </div>
                <div>
                    <label class="label"><span class="label-text">Telefon</span></label>
                    <input v-model="form.phone" type="text" class="input input-bordered w-full" />
                </div>
            </div>

            <!-- Theme & Status & Paid Until -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="label"><span class="label-text">Tema</span></label>
                    <input v-model="form.theme" type="text" class="input input-bordered w-full" />
                </div>
                <div class="flex items-center mt-6">
                    <input v-model="form.is_active" type="checkbox" class="toggle toggle-primary mr-2" />
                    <span>Aktivan</span>
                </div>
                <div>
                    <label class="label"><span class="label-text">Važi do</span></label>
                    <input v-model="form.paid_until" type="date" class="input input-bordered w-full" />
                </div>
            </div>

            <!-- Description -->
            <div>
                <label class="label"><span class="label-text">Opis</span></label>
                <textarea v-model="form.description" class="textarea textarea-bordered w-full"></textarea>
            </div>

            <!-- Logo & Cover -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="label"><span class="label-text">Logo</span></label>
                    <input type="file" @change="e => form.logo = e.target.files[0]"
                        class="file-input file-input-bordered w-full" accept="image/*" />
                    <p v-if="form.errors.logo" class="text-red-600 text-sm">
                        {{ form.errors.logo }}
                    </p>
                </div>
                <div>
                    <label class="label"><span class="label-text">Cover slika</span></label>
                    <input type="file" @change="e => form.cover_image = e.target.files[0]"
                        class="file-input file-input-bordered w-full" accept="image/*" />
                    <p v-if="form.errors.cover_image" class="text-red-600 text-sm">
                        {{ form.errors.cover_image }}
                    </p>
                </div>
            </div>

            <!-- Submit -->
            <div class="text-right">
                <button :disabled="form.processing" type="submit" class="btn btn-primary">
                    <span v-if="!form.processing">Sačuvaj</span>
                    <span v-else>Čuvanje...</span>
                </button>
            </div>
        </form>
    </AuthenticatedLayout>
</template>

<script setup>
import { useForm, Link } from '@inertiajs/vue3'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue'

const props = defineProps({
    categories: Array,
})

const form = useForm({
    category_id: '',
    name: '',
    slug: '',
    owner_email: '',
    phone: '',
    theme: '',
    primary_color: '#ffffff',
    secondary_color: '#000000',
    description: '',
    is_active: true,
    paid_until: '',
    dark_mode: false,
    logo: null,
    cover_image: null,
})

function submit() {
    form.post(route('superadmin.salons.store'))
}
</script>
