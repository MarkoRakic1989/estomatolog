<template>
    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-2xl font-semibold">Lista salona</h2>
        </template>

        <div class="mt-6">
            <Link class="btn btn-primary mb-4" :href="route('superadmin.salons.create')">
            Novi salon
            </Link>

            <div class="overflow-x-auto">
                <table class="table table-zebra w-full">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Naziv</th>
                            <th>Kategorija</th>
                            <th>Vlasnik (email)</th>
                            <th>Status</th>
                            <th class="text-center">Akcije</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="salon in salons.data" :key="salon.id">
                            <td>{{ salon.id }}</td>
                            <td>{{ salon.name }}</td>
                            <td>{{ salon.category.name }}</td>
                            <td>{{ salon.owner_email }}</td>
                            <td>
                                <span :class="{
                                    'badge badge-success': salon.is_active,
                                    'badge badge-warning': !salon.is_active
                                }">
                                    {{ salon.is_active ? 'Aktivan' : 'Neaktivan' }}
                                </span>
                            </td>
                            <td class="text-center space-x-2">
                                <Link class="btn btn-sm btn-info" :href="route('superadmin.salons.edit', salon.id)">
                                Uredi
                                </Link>
                                <button class="btn btn-sm btn-error" @click="destroy(salon.id)">
                                    Obriši
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Simple pagination -->
            <div class="mt-4 flex justify-center space-x-2">
                <button v-for="link in salons.links" :key="link.label" v-html="link.label" :disabled="!link.url" :class="{
                    'btn btn-sm': true,
                    'btn-primary': link.active,
                    'btn-outline': !link.active
                }" @click="goTo(link.url)"></button>
            </div>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import { useForm, Link } from '@inertiajs/vue3'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue'

const props = defineProps({
    salons: Object,
})

const form = useForm()

function destroy(id) {
    if (!confirm('Da li ste sigurni da obrišete ovaj salon?')) return
    form.delete(route('superadmin.salons.destroy', id))
}

function goTo(url) {
    form.get(url, {}, { preserveState: true })
}
</script>
