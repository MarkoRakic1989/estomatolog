<template>
    <AuthenticatedLayout>

        <Head title="Nova Pretplata" />

        <div class="max-w-3xl mx-auto py-8">
            <h1 class="text-2xl font-bold mb-6">Kreiraj novu pretplatu</h1>

            <form @submit.prevent="submit" class="space-y-6">
                <!-- Salon -->
                <div>
                    <label class="block mb-1 font-medium">Salon</label>
                    <select v-model="form.salon_id" class="select select-bordered w-full">
                        <option value="" disabled>Izaberite salon</option>
                        <option v-for="s in salons" :key="s.id" :value="s.id">
                            {{ s.name }}
                        </option>
                    </select>
                    <p v-if="form.errors.salon_id" class="text-red-600 text-sm">
                        {{ form.errors.salon_id }}
                    </p>
                </div>

                <!-- Paket -->
                <div>
                    <label class="block mb-1 font-medium">Paket</label>
                    <select v-model="form.package_id" class="select select-bordered w-full">
                        <option value="" disabled>Izaberite paket</option>
                        <option v-for="p in packages" :key="p.id" :value="p.id">
                            {{ p.name }}
                        </option>
                    </select>
                    <p v-if="form.errors.package_id" class="text-red-600 text-sm">
                        {{ form.errors.package_id }}
                    </p>
                </div>

                <!-- Korisnik -->
                <div>
                    <label class="block mb-1 font-medium">Korisnik</label>
                    <select v-model="form.user_id" class="select select-bordered w-full">
                        <option value="" disabled>Izaberite korisnika</option>
                        <option v-for="u in users" :key="u.id" :value="u.id">
                            {{ u.name }}
                        </option>
                    </select>
                    <p v-if="form.errors.user_id" class="text-red-600 text-sm">
                        {{ form.errors.user_id }}
                    </p>
                </div>

                <!-- Početak pretplate -->
                <div>
                    <label class="block mb-1 font-medium">Počinje</label>
                    <input v-model="form.starts_at" type="date" class="input input-bordered w-full" />
                    <p v-if="form.errors.starts_at" class="text-red-600 text-sm">
                        {{ form.errors.starts_at }}
                    </p>
                </div>

                <!-- Kraj pretplate -->
                <div>
                    <label class="block mb-1 font-medium">Ističe</label>
                    <input v-model="form.ends_at" type="date" class="input input-bordered w-full" />
                    <p v-if="form.errors.ends_at" class="text-red-600 text-sm">
                        {{ form.errors.ends_at }}
                    </p>
                </div>

                <!-- Status -->
                <div>
                    <label class="block mb-1 font-medium">Status</label>
                    <select v-model="form.status" class="select select-bordered w-full">
                        <option value="pending">Na čekanju</option>
                        <option value="active">Aktivna</option>
                        <option value="expired">Istekla</option>
                    </select>
                    <p v-if="form.errors.status" class="text-red-600 text-sm">
                        {{ form.errors.status }}
                    </p>
                </div>

                <!-- Dugmad -->
                <div class="flex justify-between">
                    <Link :href="route('superadmin.subscriptions.index')" class="btn btn-ghost">
                    Nazad
                    </Link>
                    <button type="submit" class="btn btn-primary" :disabled="form.processing">
                        <span v-if="!form.processing">Sačuvaj</span>
                        <span v-else>...</span>
                    </button>
                </div>
            </form>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import { useForm, Head, Link } from '@inertiajs/vue3'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue'

const props = defineProps({
    salons: Array,
    packages: Array,
    users: Array,
})

const form = useForm({
    salon_id: '',
    package_id: '',
    user_id: '',
    starts_at: '',
    ends_at: '',
    status: 'pending',
})

function submit() {
    form.post(route('superadmin.subscriptions.store'), {
        onSuccess: () => {
            // Inertia automatski redirect
        },
    })
}
</script>
