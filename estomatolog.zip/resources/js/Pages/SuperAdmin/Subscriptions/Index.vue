<template>
    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-2xl font-semibold">Pretplate</h2>
        </template>

        <div class="mt-6">
            <Link class="btn btn-primary mb-4" :href="route('superadmin.subscriptions.create')">
            Nova pretplata
            </Link>

            <div class="overflow-x-auto">
                <table class="table table-zebra w-full">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Salon</th>
                            <th>Paket</th>
                            <th>Korisnik</th>
                            <th class="text-center">Počinje</th>
                            <th class="text-center">Završava</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Akcije</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="sub in subscriptions.data" :key="sub.id">
                            <td>{{ sub.id }}</td>
                            <td>{{ sub.salon.name }}</td>
                            <td>{{ sub.package.name }}</td>
                            <td>{{ sub.user.name }}</td>
                            <td class="text-center">{{ sub.starts_at }}</td>
                            <td class="text-center">{{ sub.ends_at }}</td>
                            <td class="text-center">{{ sub.status }}</td>
                            <td class="text-center space-x-2">
                                <Link class="btn btn-sm btn-info"
                                    :href="route('superadmin.subscriptions.edit', sub.id)">
                                Uredi
                                </Link>
                                <button class="btn btn-sm btn-error" @click="destroy(sub.id)">
                                    Obriši
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="mt-4 flex justify-center space-x-2">
                <button v-for="link in subscriptions.links" :key="link.label" v-html="link.label" :disabled="!link.url"
                    :class="{
                        'btn btn-sm': true,
                        'btn-primary': link.active,
                        'btn-outline': !link.active
                    }" @click="goTo(link.url)"></button>
            </div>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import { useForm, Link } from '@inertiajs/vue3'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue'

const props = defineProps({
    subscriptions: Object,
})

const form = useForm()

function destroy(id) {
    if (!confirm('Da li ste sigurni da želite da obrišete ovu pretplatu?')) return
    form.delete(route('superadmin.subscriptions.destroy', id))
}

function goTo(url) {
    form.get(url, {}, { preserveState: true })
}
</script>
