<!-- resources/js/Pages/SuperAdmin/Users/Index.vue -->
<template>
    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-2xl font-semibold">Korisnici</h2>
        </template>

        <div class="mt-6">
            <div class="overflow-x-auto">
                <table class="table table-zebra w-full">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Ime</th>
                            <th>Email</th>
                            <th>Uloga</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Akcije</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="user in users.data" :key="user.id">
                            <td>{{ user.id }}</td>
                            <td>{{ user.name }}</td>
                            <td>{{ user.email }}</td>
                            <td>{{ user.role_type || user.roles.join(', ') }}</td>
                            <td class="text-center">
                                <span :class="{
                                    'badge badge-success': !user.is_blocked,
                                    'badge badge-error': user.is_blocked
                                }">
                                    {{ user.is_blocked ? 'Blokiran' : 'Aktivan' }}
                                </span>
                            </td>
                            <td class="text-center space-x-2">
                                <button class="btn btn-sm" :class="user.is_blocked ? 'btn-success' : 'btn-error'"
                                    @click="toggleBlock(user)">
                                    {{ user.is_blocked ? 'Odblokiraj' : 'Blokiraj' }}
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Paginacija -->
            <div class="mt-4 flex justify-center space-x-2">
                <button v-for="link in users.links" :key="link.label" v-html="link.label" :disabled="!link.url" :class="{
                    'btn btn-sm': true,
                    'btn-primary': link.active,
                    'btn-outline': !link.active
                }" @click="goTo(link.url)"></button>
            </div>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import { useForm } from '@inertiajs/vue3'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue'

const props = defineProps({
    users: Object, // očekuje paginirani objekat sa poljima data[] i links[]
})

const form = useForm()

function toggleBlock(user) {
    // pretpostavljamo da rute postoje:
    // PATCH superadmin.users.block    → blokiranje
    // PATCH superadmin.users.unblock  → odblokiravanje
    const routeName = user.is_blocked
        ? 'superadmin.users.unblock'
        : 'superadmin.users.block'

    if (confirm(`Da li ste sigurni?`)) {
        form.patch(route(routeName, user.id))
    }
}

function goTo(url) {
    form.get(url, {}, { preserveState: true })
}
</script>
