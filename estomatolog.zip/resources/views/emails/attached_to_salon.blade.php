<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body>
  <h1>Zdravo, {{ $name }}!</h1>
  <p>Povezali smo Vas sa salonom <strong>{{ $salon }}</strong>.</p>
  <p>Sada možete zakazivati i upravljati terminima.</p>
</body>
</html>
