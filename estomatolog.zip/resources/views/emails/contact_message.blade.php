<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>New Contact Message</title>
</head>
<body>
    <h2>New message from your Salon website</h2>
    <p><strong>Salon:</strong> {{ $salon->name }}</p>
    <p><strong>From:</strong> {{ $name }} ({{ $email }})</p>
    <hr>
    <h4>Message:</h4>
    <p>{{ $message }}</p>
</body>
</html>
