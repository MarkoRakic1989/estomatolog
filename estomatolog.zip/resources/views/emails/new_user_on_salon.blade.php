<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body>
  <h1>Dobrodošli, {{ $name }}!</h1>
  <p>Vaš nalog za salon <strong>{{ $salon }}</strong> je kreiran.</p>
  <p><strong>E-mail:</strong> {{ $email }}<br>
     <strong>Lozinka:</strong> {{ $password }}</p>
  <p>Molimo da se prijavite i promenite lozinku.</p>
</body>
</html>
