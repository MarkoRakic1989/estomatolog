<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: sans-serif; }
    .header { background: #f8f9fa; padding: 20px; text-align: center; }
    .content { margin: 20px; }
    .footer { margin: 20px; font-size: 12px; color: #666; }
  </style>
</head>
<body>
  <div class="header">
    <h1>{{ $subjectText }}</h1>
  </div>
  <div class="content">
    {!! nl2br(e($bodyText)) !!}
  </div>
  <div class="footer">
    <p>If you no longer wish to receive these emails, please ignore or contact us.</p>
  </div>
</body>
</html>
