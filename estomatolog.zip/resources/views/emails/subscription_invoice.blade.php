@component('mail::message')
# Račun za pretplatu – {{ $package->name }}

Pozdrav, {{ $salon->name }},

Izabrali ste paket: **{{ $package->name }}**

Detalji paketa:
{!! $package->description !!}

**Iznos za uplatu:**  
**{{ number_format($package->price, 2, ',', '.') }} RSD**

**Poziv na broj:** {{ $subscription->id }}

**Instrukcije za uplatu:**
- Uplatiti na račun: **123-456789-12** (primer, zameni sa pravim)
- Iznos: **{{ number_format($package->price, 2, ',', '.') }} RSD**
- Svrha uplate: "Pretplata za ordinaciju #{{ $salon->id }}"
- Poziv na broj: **{{ $subscription->id }}**

@component('mail::panel')
Pretplata će biti aktivirana nakon potvrde uplate od strane administratora.
@endcomponent

Za sva pitanja možete nam se javiti putem mejla ili na telefon.

Pozdrav,  
Vaš {{ config('app.name') }} tim
@endcomponent
