<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
    .header { text-align: center; margin-bottom: 20px; }
    .items table { width: 100%; border-collapse: collapse; }
    .items th, .items td { border: 1px solid #333; padding: 5px; }
  </style>
</head>
<body>
  <div class="header">
    <h2>Faktura {{ $invoice->invoice_number }}</h2>
    <p>Datum: {{ $invoice->date->format('d.m.Y') }}</p>
  </div>
  <p><strong>Dobavljač:</strong> {{ $invoice->supplier->name }}</p>
  <div class="items">
    <table>
      <thead>
        <tr>
          <th>Naziv</th><th>Količina</th><th>Cena/jd.</th><th>Ukupno</th>
        </tr>
      </thead>
      <tbody>
      @foreach ($invoice->items as $it)
        <tr>
          <td>{{ $it->service ? $it->service->name : $it->stockItem->name }}</td>
          <td>{{ $it->quantity }}</td>
          <td>{{ number_format($it->unit_price,2) }}</td>
          <td>{{ number_format($it->total,2) }}</td>
        </tr>
      @endforeach
        <tr>
          <td colspan="3" style="text-align:right"><strong>Ukupno:</strong></td>
          <td>{{ number_format($invoice->total,2) }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</body>
</html>
