<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <style>
        body {
            font-family: sans-serif;
            font-size: 12px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background: #f2f2f2;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <h2>Appointments for {{ $date }}</h2>
    <table>
        <thead>
            <tr>
                <th>Time</th>
                <th>Service</th>
                <th>Employee</th>
                <th>Client</th>
            </tr>
        </thead>
        <tbody>
        <tbody>
            @foreach ($appointments as $appt)
                <tr>
                    <td>{{ $appt->start_time }} - {{ $appt->end_time }}</td>

                    <td>
                        @foreach ($appt->services as $svc)
                            {{ $svc->name }}@if (!$loop->last)
                                ,
                            @endif
                        @endforeach
                    </td>
                    <td>{{ optional($appt->employee)->name ?? '—' }}</td>
                    <td>{{ optional($appt->user)->name ?? '—' }}</td>
                </tr>
            @endforeach
        </tbody>
        </tbody>
    </table>
    <p>Generated on {{ now()->format('d.m.Y H:i') }}</p>
</body>

</html>
