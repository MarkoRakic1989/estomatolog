<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Storage;

// -- Kontroleri (EKSPPLICITNO) --
use App\Http\Controllers\CalendarController;
use App\Http\Controllers\PwaController;
use App\Http\Controllers\Client\BookingController as ClientBookingController;
use App\Http\Controllers\Client\AppointmentController as ClientAppointmentController;
use App\Http\Controllers\Owner\DashboardController;
use App\Http\Controllers\Owner\WorkTimeController;
use App\Http\Controllers\Owner\PageController;
use App\Http\Controllers\Owner\GalleryController;
use App\Http\Controllers\Owner\DesignController;
use App\Http\Controllers\Owner\EmployeeController;
use App\Http\Controllers\Owner\UserController;
use App\Http\Controllers\Owner\AppointmentController;
use App\Http\Controllers\Owner\MarketingController;
use App\Http\Controllers\Owner\SubscriptionController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\Owner\DentalChartController;
use App\Http\Controllers\PublicController;
use App\Http\Controllers\Owner\ServiceCategoryController;
use App\Http\Controllers\Owner\ServiceController;
use App\Http\Controllers\Owner\SettingController;
use App\Http\Controllers\SuperAdmin\DashboardController as SuperAdminDashboardController;
use App\Http\Controllers\SuperAdmin\SalonController as SuperAdminSalonController;
use App\Http\Controllers\SuperAdmin\PackageController as SuperAdminPackageController;
use App\Http\Controllers\SuperAdmin\SubscriptionController as SuperAdminSubscriptionController;
use App\Http\Controllers\SuperAdmin\UserController as SuperAdminUserController;
use App\Http\Controllers\SuperAdmin\RoleController as SuperAdminRoleController;
use App\Http\Controllers\SuperAdmin\PermissionController as SuperAdminPermissionController;
// ---------------------------
// FOTOGRAFIJE (public slike)
// ---------------------------
Route::get('photos/{folder}/{filename}', function ($folder, $filename) {
    $path = "images/{$folder}/{$filename}";
    if (! Storage::disk('public')->exists($path)) abort(404);
    return Storage::disk('public')->response($path);
})->where('filename', '.*')->name('photos.show.folder');

Route::get('photos/{filename}', function ($filename) {
    $path = "images/{$filename}";
    if (! Storage::disk('public')->exists($path)) abort(404);
    return Storage::disk('public')->response($path);
})->where('filename', '.*')->name('photos.show');

// ---------------------------
// PUBLIC & CLIENT BOOKING
// ---------------------------
Route::domain('{salonSlug}.myapp.test')->group(function () {
    Route::get('/', [PublicController::class, 'home'])->name('public.home');
    Route::get('/services', [PublicController::class, 'services'])->name('public.services');
    Route::get('/about', [PublicController::class, 'about'])->name('public.about');
    Route::get('/contact', [PublicController::class, 'contact'])->name('public.contact');

    // -- CLIENT (AUTH) BOOKING --
    Route::middleware(['check.salon.membership', 'auth', 'can:isClient'])->group(function () {
        Route::get('/client/appointments', [ClientAppointmentController::class, 'index'])->name('client.appointment.index');
        Route::get('/client/appointments/{appointment}', [ClientAppointmentController::class, 'show'])->name('client.appointment.show');
        Route::put('/client/appointments/{appointmentId}/cancel', [ClientAppointmentController::class, 'cancel'])->name('client.appointment.cancel');
        Route::post('/api/contact/send', [ContactController::class, 'send'])->name('api.contact.send');
        Route::get('/booking/step1', [ClientBookingController::class, 'step1'])->name('booking.step1');
        Route::get('/booking/step2', [ClientBookingController::class, 'showStep2'])->name('booking.step2.show');
        Route::post('/booking/step2', [ClientBookingController::class, 'step2'])->name('booking.step2');
        Route::get('/booking/step3', [ClientBookingController::class, 'step3Form'])->name('booking.step3.form');
        Route::get('/booking/slots', [CalendarController::class, 'computeAvailableSlots'])->name('booking.slots');
        Route::get('/api/calendar/dates', [CalendarController::class, 'getAvailableDates'])->name('api.calendar.dates');
        Route::get('/api/calendar/slots', [CalendarController::class, 'getAvailableSlots'])->name('api.calendar.slots');
        Route::post('/booking/{salonSlug}/confirm', [ClientBookingController::class, 'confirm'])->name('booking.confirm');
        Route::get('/booking/confirmation/{id}', [ClientBookingController::class, 'confirmation'])->name('booking.confirmation');
        Route::middleware('auth')->group(function () {
            Route::patch('/booking/confirm/{appointmentId}', [ClientBookingController::class, 'confirmStatus'])->name('booking.confirm.status');
        });
    });
});

// ---------------------------
// SUPERADMIN PANEL
// ---------------------------
Route::middleware(['auth', 'can:isAdmin'])
    ->prefix('superadmin')
    ->name('superadmin.')
    ->group(function(){
        Route::get('dashboard', [SuperAdminDashboardController::class, 'index'])->name('dashboard');
        Route::resource('salons', SuperAdminSalonController::class)->except(['show']);
        Route::resource('packages', SuperAdminPackageController::class)->except(['show']);
        Route::resource('subscriptions', SuperAdminSubscriptionController::class)->except(['show']);
        Route::get('users', [SuperAdminUserController::class, 'index'])->name('users.index');
        Route::patch('users/{user}/block', [SuperAdminUserController::class, 'block'])->name('users.block');
        Route::patch('users/{user}/unblock', [SuperAdminUserController::class, 'unblock'])->name('users.unblock');
        Route::resource('roles', SuperAdminRoleController::class)->except(['show']);
        Route::resource('permissions', SuperAdminPermissionController::class)->except(['show']);
        Route::resource('subscription-payments', \App\Http\Controllers\SuperAdmin\SubscriptionPaymentController::class)
            ->only(['index', 'store']);
    });

// ---------------------------
// OWNER PANEL (sa permisijama i paketima)
// ---------------------------
Route::middleware(['auth', 'check.subscription', 'permission:dashboard.view'])
    ->prefix('owner')->name('owner.')
    ->group(function () {

    // Dashboard
    Route::get('dashboard', [DashboardController::class, 'index'])
        ->name('dashboard')
        ->middleware('permission:dashboard.view');
    Route::get('dashboard/export-pdf', [DashboardController::class, 'exportTodayPdf'])
        ->name('dashboard.exportPdf')
        ->middleware('permission:dashboard.view');

    // Settings
    Route::get('settings/roles', [SettingController::class, 'rolesIndex'])
        ->name('settings.roles.index')
        ->middleware('permission:settings.manage');
    Route::post('settings/roles', [SettingController::class, 'updateRoles'])
        ->name('settings.roles.update')
        ->middleware('permission:settings.manage');



    // Services i Service Categories (osnovno za sve)
    Route::resource('services', ServiceController::class)->middleware([
        'index'   => 'permission:services.view',
        'show'    => 'permission:services.view',
        'create'  => 'permission:services.manage',
        'store'   => 'permission:services.manage',
        'edit'    => 'permission:services.manage',
        'update'  => 'permission:services.manage',
        'destroy' => 'permission:services.manage',
    ]);
    Route::patch('services/{service}/toggle-self-bookable', [ServiceController::class, 'toggleSelfBookable'])
        ->name('services.toggleSelfBookable')
        ->middleware('permission:services.manage');
    Route::resource('service-categories', ServiceCategoryController::class)->middleware([
        'index'   => 'permission:service-categories.view',
        'show'    => 'permission:service-categories.view',
        'create'  => 'permission:service-categories.manage',
        'store'   => 'permission:service-categories.manage',
        'edit'    => 'permission:service-categories.manage',
        'update'  => 'permission:service-categories.manage',
        'destroy' => 'permission:service-categories.manage',
    ]);

    // Appointments (sve tvoje rute, granularno po permisiji)
    Route::get('appointments', [AppointmentController::class,'index'])
        ->name('appointments.index')
        ->middleware('permission:appointments.view');
    Route::get('appointments/create', [AppointmentController::class,'create'])
        ->name('appointments.create')
        ->middleware('permission:appointments.manage');
    Route::post('appointments/create', [AppointmentController::class,'storeUser'])
        ->name('appointments.storeUser')
        ->middleware('permission:appointments.manage');
    Route::get('appointments/services', [AppointmentController::class,'selectServices'])
        ->name('appointments.services.index')
        ->middleware('permission:appointments.manage');
    Route::post('appointments/services', [AppointmentController::class,'storeServices'])
        ->name('appointments.services.store')
        ->middleware('permission:appointments.manage');
    Route::get('appointments/schedule', [AppointmentController::class,'selectSchedule'])
        ->name('appointments.schedule.index')
        ->middleware('permission:appointments.manage');
    Route::post('appointments', [AppointmentController::class,'store'])
        ->name('appointments.store')
        ->middleware('permission:appointments.manage');
    Route::get('appointments/{id}/confirmation', [AppointmentController::class,'confirmation'])
        ->name('appointments.confirmation')
        ->middleware('permission:appointments.view');

    // Dental chart & Tooth reports
    Route::get('users/{user}/dental-chart',[UserController::class,'dentalChart'])
        ->name('users.dentalChart')
        ->middleware('permission:dental_chart.view');
    Route::post('users/{user}/appointments/{appointment}/report', [UserController::class,'report'])
        ->name('users.report')
        ->middleware('permission:users.manage');

    // Worktime (drag & drop)
    Route::resource('worktimes', WorkTimeController::class)->middleware('permission:worktime.manage');
    Route::post('api/worktime/resize', [WorkTimeController::class, 'resize'])
        ->middleware('permission:worktime.manage')
        ->name('api.worktime.resize');
    Route::post('api/worktime/move',   [WorkTimeController::class, 'move'])
        ->middleware('permission:worktime.manage')
        ->name('api.worktime.move');
    Route::get('api/calendar/dates', [AppointmentController::class, 'getAvailableDates'])
        ->name('api.calendar.dates');
    Route::get('api/calendar/slots', [AppointmentController::class, 'getAvailableSlots'])
        ->name('api.calendar.slots');
    Route::post('worktimes/{worktime}/copy', [WorkTimeController::class, 'copy'])
        ->middleware('permission:worktime.manage')
        ->name('worktimes.copy');
    Route::post('worktimes/swap', [WorkTimeController::class, 'swap'])
        ->name('worktimes.swap');

    // Pages, Galleries, Design (Standard/Premium)
    Route::resource('pages', PageController::class)->middleware('permission:pages.manage','package:files');
    Route::resource('galleries', GalleryController::class)->middleware('permission:galleries.manage','package:files');
    Route::get('design', [DesignController::class, 'edit'])->middleware(['permission:design.manage','package:files'])->name('design.edit');
    Route::patch('design', [DesignController::class, 'update'])->middleware('permission:design.manage','package:files')->name('design.update');

    // Employees
    Route::resource('employees', EmployeeController::class)->middleware('permission:employees.manage');

  // USERS - LISTA, DETALJI, BLOKIRANJE/ODBLOKIRANJE (osnovne permisije)
    Route::get('users', [UserController::class, 'index'])
        ->middleware(['permission:users.view'])
        ->name('users.index');

    Route::get('users/{user}', [UserController::class, 'show'])
        ->middleware(['permission:users.view'])
        ->name('users.show');

    Route::patch('users/{user}/block', [UserController::class, 'block'])
        ->middleware(['permission:users.manage'])
        ->name('users.block');

    Route::patch('users/{user}/unblock', [UserController::class, 'unblock'])
        ->middleware(['permission:users.manage'])
        ->name('users.unblock');

    // KARTON PACIJENTA, ODONTOGRAM, DIJAGNOZE, INTERVENCIJE — BASIC
    Route::get('users/{user}/chart', [DentalChartController::class, 'dashboard'])->middleware(['permission:users.view'])->name('users.chart.dashboard');
    Route::get('users/{user}/chart/osnovni-podaci', [DentalChartController::class, 'basic'])->name('users.chart.basic');
    Route::put('/users/{user}/chart/osnovni-podaci', [DentalChartController::class, 'updateBasic'])->name('users.chart.basic.update');

    Route::get('users/{user}/chart/odontogram', [DentalChartController::class, 'odontogram'])->name('users.chart.odontogram');
    // API rute za status površina zuba (AJAX, Inertia ne koristi klasične API prefikse)
    Route::get('users/{user}/chart/odontogram/statuses', [DentalChartController::class, 'getToothStatuses'])->name('users.chart.odontogram.statuses');
    Route::post('users/{user}/chart/odontogram/status', [DentalChartController::class, 'saveToothStatuses'])->name('users.chart.odontogram.save_status');
    Route::get('users/{user}/chart/istorija-zuba', [DentalChartController::class, 'toothHistory'])->name('users.chart.tooth_history');
    Route::get('users/{user}/chart/intervencije', [DentalChartController::class, 'interventions'])->name('users.chart.interventions');
    Route::get('users/{user}/chart/terapije', [DentalChartController::class, 'therapies'])->name('users.chart.therapies');
    Route::get('users/{user}/chart/dijagnoze', [DentalChartController::class, 'diagnoses'])->name('users.chart.diagnoses');
    Route::get('users/{user}/chart/dokumenti', [DentalChartController::class, 'documents'])->name('users.chart.documents');
    Route::get('users/{user}/chart/anamneza', [DentalChartController::class, 'anamnesis'])->name('users.chart.anamnesis');
    Route::get('users/{user}/chart/plan-terapije', [DentalChartController::class, 'treatmentPlan'])->name('users.chart.treatment_plan');
    Route::get('users/{user}/chart/finansije', [DentalChartController::class, 'financial'])->name('users.chart.financial');
    Route::get('users/{user}/chart/materijali', [DentalChartController::class, 'materials'])->name('users.chart.materials');
    Route::get('users/{user}/chart/posete', [DentalChartController::class, 'visits'])->name('users.chart.visits');
    Route::get('users/{user}/chart/osoblje', [DentalChartController::class, 'staffHistory'])->name('users.chart.staff_history');
    Route::get('users/{user}/chart/log', [DentalChartController::class, 'activityLog'])->name('users.chart.activity_log');
// routes/web.php
    Route::post('users/{user}/chart/odontogram/save-intervention', [DentalChartController::class, 'saveIntervention'])->name('users.chart.odontogram.save_intervention');
    Route::post('users/{user}/chart/odontogram/save-therapy', [DentalChartController::class, 'saveTherapy'])->name('users.chart.odontogram.save_therapy');
    Route::post('users/{user}/chart/odontogram/save-diagnosis', [DentalChartController::class, 'saveDiagnosis'])->name('users.chart.odontogram.save_diagnosis');
    Route::post('users/{user}/chart/odontogram/save-plan', [DentalChartController::class, 'savePlan'])->name('users.chart.odontogram.save_plan');
    // Snimanje anamneze (isti URL kao get, ali PUT metoda)
    Route::put('users/{user}/chart/anamneza', [DentalChartController::class, 'updateAnamnesis'])
        ->name('users.chart.anamnesis.update');

    // Otprema dokumenata (upload)
    Route::post('users/{user}/chart/dokumenti/upload', [DentalChartController::class, 'uploadDocument'])
        ->name('users.chart.documents.upload');

    // Snimanje predračuna i računa u sekciji finansija
    Route::post('users/{user}/chart/finansije/predracun', [DentalChartController::class, 'saveEstimate'])
        ->name('users.chart.financial.save_estimate');
    Route::post('users/{user}/chart/finansije/racun', [DentalChartController::class, 'saveInvoice'])
        ->name('users.chart.financial.save_invoice');

    // Snimanje materijala
    Route::post('users/{user}/chart/materijali', [DentalChartController::class, 'saveMaterial'])
        ->name('users.chart.materials.save');
// Glavna stranica kartona
    // TERMINI PO PACIJENTU — STANDARD
    Route::get('users/{user}/appointments', [AppointmentController::class, 'userAppointments'])
        ->middleware(['permission:users.view', 'package:standard'])
        ->name('users.appointments.index');
    Route::post('users/{user}/appointments', [AppointmentController::class, 'store'])
        ->middleware(['permission:users.manage', 'package:standard'])
        ->name('users.appointments.store');

    // BLOKIRANJE/ODBLOKIRANJE IZDVOJENO ZA SVAKI PACIJENT
    Route::patch('users/{user}/block', [UserController::class, 'block'])
        ->middleware(['permission:users.manage'])
        ->name('users.block');
    Route::patch('users/{user}/unblock', [UserController::class, 'unblock'])
        ->middleware(['permission:users.manage'])
        ->name('users.unblock');

    // IZVEŠTAJ O TERMINU (ili dodatna izmena)
    Route::patch('users/{user}/appointments/{appointment}/report', [UserController::class, 'report'])
        ->middleware(['permission:users.manage'])
        ->name('users.appointment.report');

    // Marketing (Premium)
    Route::get('marketing/email', [MarketingController::class, 'showEmailForm'])->middleware('permission:marketing.manage','package:premium')->name('marketing.email.form');
    Route::post('marketing/email/send', [MarketingController::class, 'sendEmail'])->middleware('permission:marketing.manage','package:premium')->name('marketing.email.send');
    Route::resource('marketing/coupons', MarketingController::class)
        ->only(['index','create','store','destroy'])
        ->middleware('permission:marketing.manage','package:premium');

   Route::get('subscription', [\App\Http\Controllers\Owner\SubscriptionController::class, 'index'])
    ->middleware('permission:subscription.view')
    ->name('subscription.index');

    Route::post('subscription/request', [\App\Http\Controllers\Owner\SubscriptionController::class, 'requestPackage'])
        ->middleware('permission:subscription.view')
        ->name('subscription.request');

    Route::post('subscription/notify-payment', [\App\Http\Controllers\Owner\SubscriptionController::class, 'notifyPayment'])
        ->middleware('permission:subscription.view')
        ->name('subscription.notify');
});



// -- PWA --
Route::get('/offline', [PwaController::class, 'offline'])->name('pwa.offline');
Route::get('/manifest.json', [PwaController::class, 'manifest'])->name('pwa.manifest');

// -- AUTH --
require __DIR__ . '/auth.php';
